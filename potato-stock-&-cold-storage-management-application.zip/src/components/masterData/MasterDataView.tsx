import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { PotatoVariety, SeedClass, SizeGrade, UserRole } from '../../types';
import {
  Layers,
  Sprout,
  Tag,
  Ruler,
  Users,
  Building,
  Plus,
  Trash2,
  Edit2,
  Save,
  Check,
  ShieldCheck,
  Upload,
  Camera,
} from 'lucide-react';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { sortData } from '../../utils/sortUtils';

interface MasterDataViewProps {
  defaultTab?: 'varieties' | 'classes' | 'grades' | 'users' | 'company';
}

export const MasterDataView: React.FC<MasterDataViewProps> = ({ defaultTab = 'varieties' }) => {
  const {
    varieties,
    seedClasses,
    grades,
    users,
    currentUser,
    companySettings,
    addVariety,
    updateVariety,
    deleteVariety,
    addClass,
    updateClass,
    deleteClass,
    addGrade,
    updateGrade,
    deleteGrade,
    addUser,
    updateUser,
    deleteUser,
    updateCompanySettings,
    hasPermission,
    addToast,
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<
    'varieties' | 'classes' | 'grades' | 'users' | 'company'
  >(defaultTab);

  useEffect(() => {
    if (defaultTab) {
      setActiveSubTab(defaultTab);
    }
  }, [defaultTab]);

  // Variety State
  const [varietyName, setVarietyName] = useState('');
  const [varietyType, setVarietyType] = useState<'Table' | 'Processing' | 'Seed' | 'Dual'>('Table');
  const [editingVarietyId, setEditingVarietyId] = useState<string | null>(null);

  // Class State
  const [className, setClassName] = useState('');
  const [classCode, setClassCode] = useState('');
  const [editingClassId, setEditingClassId] = useState<string | null>(null);

  // Grade State
  const [gradeName, setGradeName] = useState('');
  const [gradeSizeRange, setGradeSizeRange] = useState('');
  const [editingGradeId, setEditingGradeId] = useState<string | null>(null);

  // User State
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userRole, setUserRole] = useState<UserRole>('operator');

  // Sorting & Pagination States
  const [varietySortKey, setVarietySortKey] = useState<string>('name');
  const [varietySortDir, setVarietySortDir] = useState<'asc' | 'desc'>('asc');
  const [varietyPage, setVarietyPage] = useState<number>(1);
  const [varietyPageSize, setVarietyPageSize] = useState<number>(10);

  const [classSortKey, setClassSortKey] = useState<string>('name');
  const [classSortDir, setClassSortDir] = useState<'asc' | 'desc'>('asc');
  const [classPage, setClassPage] = useState<number>(1);
  const [classPageSize, setClassPageSize] = useState<number>(10);

  const [gradeSortKey, setGradeSortKey] = useState<string>('name');
  const [gradeSortDir, setGradeSortDir] = useState<'asc' | 'desc'>('asc');
  const [gradePage, setGradePage] = useState<number>(1);
  const [gradePageSize, setGradePageSize] = useState<number>(10);

  const [userSortKey, setUserSortKey] = useState<string>('fullName');
  const [userSortDir, setUserSortDir] = useState<'asc' | 'desc'>('asc');
  const [userPage, setUserPage] = useState<number>(1);
  const [userPageSize, setUserPageSize] = useState<number>(10);

  // Derived Sorted and Paginated Data
  const sortedVarieties = useMemo(() => {
    return sortData(varieties, varietySortKey, varietySortDir);
  }, [varieties, varietySortKey, varietySortDir]);

  const paginatedVarieties = useMemo(() => {
    const start = (varietyPage - 1) * varietyPageSize;
    return sortedVarieties.slice(start, start + varietyPageSize);
  }, [sortedVarieties, varietyPage, varietyPageSize]);

  const sortedClasses = useMemo(() => {
    return sortData(seedClasses, classSortKey, classSortDir);
  }, [seedClasses, classSortKey, classSortDir]);

  const paginatedClasses = useMemo(() => {
    const start = (classPage - 1) * classPageSize;
    return sortedClasses.slice(start, start + classPageSize);
  }, [sortedClasses, classPage, classPageSize]);

  const sortedGrades = useMemo(() => {
    return sortData(grades, gradeSortKey, gradeSortDir);
  }, [grades, gradeSortKey, gradeSortDir]);

  const paginatedGrades = useMemo(() => {
    const start = (gradePage - 1) * gradePageSize;
    return sortedGrades.slice(start, start + gradePageSize);
  }, [sortedGrades, gradePage, gradePageSize]);

  const sortedUsers = useMemo(() => {
    return sortData(
      users.map((u) => ({ ...u, fullName: u.fullName || u.name })),
      userSortKey,
      userSortDir
    );
  }, [users, userSortKey, userSortDir]);

  const paginatedUsers = useMemo(() => {
    const start = (userPage - 1) * userPageSize;
    return sortedUsers.slice(start, start + userPageSize);
  }, [sortedUsers, userPage, userPageSize]);

  // Company Settings State
  const [compName, setCompName] = useState(companySettings.companyName || companySettings.name || '');
  const [compSubtitle, setCompSubtitle] = useState(companySettings.companyTagline || companySettings.subtitle || '');
  const [compAddress, setCompAddress] = useState(companySettings.address || '');
  const [compPhone, setCompPhone] = useState(companySettings.phone || '');
  const [compEmail, setCompEmail] = useState(companySettings.email || '');
  const [compSeason, setCompSeason] = useState(companySettings.fiscalYear || companySettings.season || '2024-2025');
  const [compLogoUrl, setCompLogoUrl] = useState<string | undefined>(companySettings.logoUrl);
  const logoFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCompLogoUrl(companySettings.logoUrl);
  }, [companySettings.logoUrl]);

  // Handlers for Varieties
  const handleSaveVariety = (e: React.FormEvent) => {
    e.preventDefault();
    if (!varietyName.trim()) return;

    if (editingVarietyId) {
      updateVariety(editingVarietyId, { name: varietyName.trim(), type: varietyType });
      setEditingVarietyId(null);
      if (addToast) addToast('Variety updated successfully', 'success');
    } else {
      addVariety({ name: varietyName.trim(), code: varietyName.trim().slice(0, 3).toUpperCase(), type: varietyType });
      if (addToast) addToast('Variety added successfully', 'success');
    }
    setVarietyName('');
  };

  // Handlers for Classes
  const handleSaveClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!className.trim()) return;

    if (editingClassId) {
      updateClass(editingClassId, { name: className.trim(), code: classCode.trim() });
      setEditingClassId(null);
      if (addToast) addToast('Seed class updated', 'success');
    } else {
      addClass({ name: className.trim(), code: classCode.trim() || className.trim().slice(0, 2).toUpperCase() });
      if (addToast) addToast('Seed class added', 'success');
    }
    setClassName('');
    setClassCode('');
  };

  // Handlers for Grades
  const handleSaveGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gradeName.trim()) return;

    if (editingGradeId) {
      updateGrade(editingGradeId, { name: gradeName.trim(), sizeRange: gradeSizeRange.trim() });
      setEditingGradeId(null);
      if (addToast) addToast('Size grade updated', 'success');
    } else {
      addGrade({ name: gradeName.trim(), code: gradeName.trim().slice(0, 2).toUpperCase(), sizeRange: gradeSizeRange.trim() });
      if (addToast) addToast('Size grade added', 'success');
    }
    setGradeName('');
    setGradeSizeRange('');
  };

  // Handlers for Users
  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !userEmail.trim()) return;

    const rolePermissions: Record<string, any[]> = {
      admin: [
        'manage_cold_storages',
        'add_stock',
        'edit_stock',
        'delete_stock',
        'add_delivery',
        'edit_delivery',
        'delete_delivery',
        'manage_master_data',
        'view_reports',
        'export_data',
        'manage_users',
      ],
      manager: [
        'manage_cold_storages',
        'add_stock',
        'edit_stock',
        'add_delivery',
        'edit_delivery',
        'view_reports',
        'export_data',
      ],
      operator: ['add_stock', 'add_delivery', 'view_reports'],
      viewer: ['view_reports'],
    };

    addUser({
      username: userEmail.split('@')[0],
      fullName: userName.trim(),
      name: userName.trim(),
      email: userEmail.trim(),
      role: userRole,
      roleName: userRole.toUpperCase(),
      isActive: true,
      permissions: rolePermissions[userRole] || ['view_reports'],
    });
    setUserName('');
    setUserEmail('');
    if (addToast) addToast(`User ${userName} created with role ${userRole}`, 'success');
  };

  // Handlers for Company
  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanySettings({
      companyName: compName,
      name: compName,
      companyTagline: compSubtitle,
      subtitle: compSubtitle,
      address: compAddress,
      phone: compPhone,
      email: compEmail,
      fiscalYear: compSeason,
      season: compSeason,
      currency: companySettings.currency || 'BDT',
      logoUrl: compLogoUrl,
      logoText: compName,
    });
    if (addToast) addToast('Enterprise header and print parameters updated', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
          <Layers className="w-6 h-6 text-sky-600 dark:text-sky-400" />
          MASTER DATA & SYSTEM CONFIGURATION
        </h2>
        <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
          MANAGE SEED VARIETIES, CLASS TAXONOMY, SIZE GRADING METRICS, USER PERMISSIONS & PRINT HEADERS
        </p>
      </div>

      {/* Sub Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-1 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveSubTab('varieties')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer uppercase ${
            activeSubTab === 'varieties'
              ? 'border-sky-600 text-sky-600 dark:border-sky-400 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Sprout className="w-4 h-4" />
          <span>POTATO VARIETIES ({varieties.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('classes')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer uppercase ${
            activeSubTab === 'classes'
              ? 'border-sky-600 text-sky-600 dark:border-sky-400 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>SEED CLASSES ({seedClasses.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('grades')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer uppercase ${
            activeSubTab === 'grades'
              ? 'border-sky-600 text-sky-600 dark:border-sky-400 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Ruler className="w-4 h-4" />
          <span>SIZE GRADES ({grades.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('users')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer uppercase ${
            activeSubTab === 'users'
              ? 'border-sky-600 text-sky-600 dark:border-sky-400 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>USERS & ROLES ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('company')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer uppercase ${
            activeSubTab === 'company'
              ? 'border-sky-600 text-sky-600 dark:border-sky-400 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>COMPANY & PRINT CONFIG</span>
        </button>
      </div>

      {/* 1. Varieties Management */}
      {activeSubTab === 'varieties' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2 uppercase">
              <Sprout className="w-4 h-4 text-emerald-500" />
              {editingVarietyId ? 'EDIT VARIETY' : 'ADD POTATO VARIETY'}
            </h3>
            <form onSubmit={handleSaveVariety} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  VARIETY NAME <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={varietyName}
                  onChange={(e) => setVarietyName(e.target.value)}
                  placeholder="e.g. Cardinal, Asterix, Granola"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  VARIETY PURPOSE
                </label>
                <select
                  value={varietyType}
                  onChange={(e) => setVarietyType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="Table">Table Consumption</option>
                  <option value="Processing">Industrial Processing (Chips/Fries)</option>
                  <option value="Seed">Foundation Seed Production</option>
                  <option value="Dual">Dual Purpose</option>
                </select>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors cursor-pointer uppercase"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingVarietyId ? 'UPDATE VARIETY' : 'SAVE VARIETY'}</span>
                </button>
                {editingVarietyId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingVarietyId(null);
                      setVarietyName('');
                    }}
                    className="px-3 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer uppercase"
                  >
                    CANCEL
                  </button>
                )}
              </div>
            </form>
          </div>

          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase">
                  <SortableHeader label="VARIETY NAME" sortKey="name" currentSortKey={varietySortKey} currentSortDir={varietySortDir} onSort={(k) => { setVarietySortKey(k); setVarietySortDir(d => d === 'asc' ? 'desc' : 'asc'); setVarietyPage(1); }} />
                  <SortableHeader label="CATEGORY" sortKey="type" currentSortKey={varietySortKey} currentSortDir={varietySortDir} onSort={(k) => { setVarietySortKey(k); setVarietySortDir(d => d === 'asc' ? 'desc' : 'asc'); setVarietyPage(1); }} />
                  <th className="py-3 px-4 text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paginatedVarieties.map((v) => (
                  <tr key={v.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{v.name}</td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300">
                        {v.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingVarietyId(v.id);
                            setVarietyName(v.name);
                            setVarietyType((v.type as any) || 'Table');
                          }}
                          className="p-1 rounded-md text-slate-400 hover:text-sky-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteVariety(v.id)}
                          className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <TablePagination
              currentPage={varietyPage}
              totalPages={Math.ceil(sortedVarieties.length / varietyPageSize) || 1}
              pageSize={varietyPageSize}
              totalItems={sortedVarieties.length}
              onPageChange={setVarietyPage}
              onPageSizeChange={(sz) => { setVarietyPageSize(sz); setVarietyPage(1); }}
              pageSizeOptions={[5, 10, 20, 50]}
            />
          </div>
        </div>
      )}

      {/* 2. Seed Classes Management */}
      {activeSubTab === 'classes' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2 uppercase">
              <Tag className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              {editingClassId ? 'EDIT SEED CLASS' : 'ADD SEED CLASS'}
            </h3>
            <form onSubmit={handleSaveClass} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  CLASS NAME <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={className}
                  onChange={(e) => setClassName(e.target.value)}
                  placeholder="e.g. Foundation Seed, Certified Seed"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  SHORT CODE
                </label>
                <input
                  type="text"
                  value={classCode}
                  onChange={(e) => setClassCode(e.target.value)}
                  placeholder="e.g. FS, CS, BS, TLS"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 uppercase"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors cursor-pointer uppercase"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingClassId ? 'UPDATE CLASS' : 'SAVE CLASS'}</span>
                </button>
                {editingClassId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingClassId(null);
                      setClassName('');
                      setClassCode('');
                    }}
                    className="px-3 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer uppercase"
                  >
                    CANCEL
                  </button>
                )}
              </div>
            </form>
          </div>

          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase">
                  <SortableHeader label="CLASS NAME" sortKey="name" currentSortKey={classSortKey} currentSortDir={classSortDir} onSort={(k) => { setClassSortKey(k); setClassSortDir(d => d === 'asc' ? 'desc' : 'asc'); setClassPage(1); }} />
                  <SortableHeader label="CODE" sortKey="code" currentSortKey={classSortKey} currentSortDir={classSortDir} onSort={(k) => { setClassSortKey(k); setClassSortDir(d => d === 'asc' ? 'desc' : 'asc'); setClassPage(1); }} />
                  <th className="py-3 px-4 text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paginatedClasses.map((sc) => (
                  <tr key={sc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{sc.name}</td>
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                      {sc.code || '-'}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingClassId(sc.id);
                            setClassName(sc.name);
                            setClassCode(sc.code || '');
                          }}
                          className="p-1 rounded-md text-slate-400 hover:text-sky-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteClass(sc.id)}
                          className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <TablePagination
              currentPage={classPage}
              totalPages={Math.ceil(sortedClasses.length / classPageSize) || 1}
              pageSize={classPageSize}
              totalItems={sortedClasses.length}
              onPageChange={setClassPage}
              onPageSizeChange={(sz) => { setClassPageSize(sz); setClassPage(1); }}
              pageSizeOptions={[5, 10, 20, 50]}
            />
          </div>
        </div>
      )}

      {/* 3. Size Grades Management */}
      {activeSubTab === 'grades' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2 uppercase">
              <Ruler className="w-4 h-4 text-amber-500" />
              {editingGradeId ? 'EDIT SIZE GRADE' : 'ADD SIZE GRADE'}
            </h3>
            <form onSubmit={handleSaveGrade} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  GRADE DESIGNATION <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={gradeName}
                  onChange={(e) => setGradeName(e.target.value)}
                  placeholder="e.g. Grade A, Grade B, Over-sized"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  SIZE CALIBER RANGE (MM)
                </label>
                <input
                  type="text"
                  value={gradeSizeRange}
                  onChange={(e) => setGradeSizeRange(e.target.value)}
                  placeholder="e.g. 28-35 mm, 35-45 mm, 45-55 mm"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition-colors cursor-pointer uppercase"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingGradeId ? 'UPDATE GRADE' : 'SAVE GRADE'}</span>
                </button>
                {editingGradeId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingGradeId(null);
                      setGradeName('');
                      setGradeSizeRange('');
                    }}
                    className="px-3 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer uppercase"
                  >
                    CANCEL
                  </button>
                )}
              </div>
            </form>
          </div>

          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase">
                  <SortableHeader label="GRADE LABEL" sortKey="name" currentSortKey={gradeSortKey} currentSortDir={gradeSortDir} onSort={(k) => { setGradeSortKey(k); setGradeSortDir(d => d === 'asc' ? 'desc' : 'asc'); setGradePage(1); }} />
                  <SortableHeader label="CALIBER RANGE" sortKey="sizeRange" currentSortKey={gradeSortKey} currentSortDir={gradeSortDir} onSort={(k) => { setGradeSortKey(k); setGradeSortDir(d => d === 'asc' ? 'desc' : 'asc'); setGradePage(1); }} />
                  <th className="py-3 px-4 text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paginatedGrades.map((g) => (
                  <tr key={g.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{g.name}</td>
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                      {g.sizeRange || '-'}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingGradeId(g.id);
                            setGradeName(g.name);
                            setGradeSizeRange(g.sizeRange || '');
                          }}
                          className="p-1 rounded-md text-slate-400 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteGrade(g.id)}
                          className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <TablePagination
              currentPage={gradePage}
              totalPages={Math.ceil(sortedGrades.length / gradePageSize) || 1}
              pageSize={gradePageSize}
              totalItems={sortedGrades.length}
              onPageChange={setGradePage}
              onPageSizeChange={(sz) => { setGradePageSize(sz); setGradePage(1); }}
              pageSizeOptions={[5, 10, 20, 50]}
            />
          </div>
        </div>
      )}

      {/* 4. Users & Access Management */}
      {activeSubTab === 'users' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2 uppercase">
              <Users className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              ADD SYSTEM USER
            </h3>
            <form onSubmit={handleSaveUser} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  FULL NAME <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="e.g. Tariqul Islam"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  EMAIL ADDRESS <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  placeholder="tariqul@agriseed.com"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  ASSIGNED ROLE
                </label>
                <select
                  value={userRole}
                  onChange={(e) => setUserRole(e.target.value as UserRole)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 uppercase"
                >
                  <option value="admin">ADMIN (FULL CONTROL)</option>
                  <option value="manager">MANAGER (OPERATIONS & REPORTS)</option>
                  <option value="operator">OPERATOR (INBOUND / OUTBOUND ENTRY)</option>
                  <option value="viewer">VIEWER (READ ONLY)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors cursor-pointer mt-2 uppercase"
              >
                <Plus className="w-4 h-4" />
                <span>CREATE USER</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase">
                  <SortableHeader label="USER" sortKey="fullName" currentSortKey={userSortKey} currentSortDir={userSortDir} onSort={(k) => { setUserSortKey(k); setUserSortDir(d => d === 'asc' ? 'desc' : 'asc'); setUserPage(1); }} />
                  <SortableHeader label="ROLE" sortKey="role" currentSortKey={userSortKey} currentSortDir={userSortDir} onSort={(k) => { setUserSortKey(k); setUserSortDir(d => d === 'asc' ? 'desc' : 'asc'); setUserPage(1); }} />
                  <th className="py-3 px-4">PERMISSIONS</th>
                  <th className="py-3 px-4 text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paginatedUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                        {u.fullName || u.name}
                        {u.id === currentUser?.id && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-100 dark:bg-sky-900/50 text-sky-700 dark:text-sky-300 font-normal uppercase">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">{u.email}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="uppercase px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {u.roleName || u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500">
                      <span className="text-[11px] uppercase">
                        {(u.permissions?.length ?? 11) >= 11
                           ? 'FULL ADMIN ACCESS'
                          : `${u.permissions?.length ?? 5} GRANTED RIGHTS`}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      {u.id !== 'usr-1' && (
                        <button
                          onClick={() => deleteUser(u.id)}
                          className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <TablePagination
              currentPage={userPage}
              totalPages={Math.ceil(sortedUsers.length / userPageSize) || 1}
              pageSize={userPageSize}
              totalItems={sortedUsers.length}
              onPageChange={setUserPage}
              onPageSizeChange={(sz) => { setUserPageSize(sz); setUserPage(1); }}
              pageSizeOptions={[5, 10, 20, 50]}
            />
          </div>
        </div>
      )}

      {/* 5. Company Profile & Print Configuration */}
      {activeSubTab === 'company' && (
        <div className="max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <div className="flex items-center gap-2 mb-4">
            <Building className="w-5 h-5 text-sky-600 dark:text-sky-400" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Official Company Header & Print Parameters
            </h3>
          </div>

          <form onSubmit={handleSaveCompany} className="space-y-4 text-xs">
            {/* Company Logo Upload & Remove */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <label className="block font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider mb-2">
                OFFICIAL COMPANY LOGO
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-20 h-20 rounded-xl overflow-hidden bg-white border border-slate-300 dark:border-slate-600 flex items-center justify-center p-1 shadow-2xs shrink-0">
                  {compLogoUrl ? (
                    <img src={compLogoUrl} alt="Company Logo" className="w-full h-full object-contain" />
                  ) : (
                    <div className="w-full h-full rounded-lg bg-gradient-to-tr from-sky-600 to-emerald-500 flex items-center justify-center text-white">
                      <Sprout className="w-7 h-7" />
                    </div>
                  )}
                </div>

                <div className="flex-1 space-y-2 text-center sm:text-left">
                  <div className="flex items-center gap-2 justify-center sm:justify-start flex-wrap">
                    <input
                      ref={logoFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = () => {
                            setCompLogoUrl(reader.result as string);
                            if (addToast) addToast('Logo uploaded. Click "Save Header" below to apply.', 'info');
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                      className="hidden"
                    />

                    <button
                      type="button"
                      onClick={() => logoFileInputRef.current?.click()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 hover:bg-sky-100 dark:hover:bg-sky-900/60 border border-sky-200 dark:border-sky-800 transition-colors cursor-pointer uppercase shadow-2xs"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{compLogoUrl ? 'CHANGE LOGO' : 'UPLOAD LOGO'}</span>
                    </button>

                    {compLogoUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          setCompLogoUrl(undefined);
                          if (logoFileInputRef.current) logoFileInputRef.current.value = '';
                          if (addToast) addToast('Logo removed.', 'info');
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-800 transition-colors cursor-pointer uppercase shadow-2xs"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>REMOVE LOGO</span>
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    PNG, JPG, or SVG recommended. Will appear in navigation header, sidebar, and all official export sheets.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                COMPANY NAME
              </label>
              <input
                type="text"
                value={compName}
                onChange={(e) => setCompName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-semibold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                SUB-HEADING / DEPARTMENT
              </label>
              <input
                type="text"
                value={compSubtitle}
                onChange={(e) => setCompSubtitle(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                OPERATING SEASON
              </label>
              <input
                type="text"
                value={compSeason}
                onChange={(e) => setCompSeason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                CORPORATE ADDRESS
              </label>
              <input
                type="text"
                value={compAddress}
                onChange={(e) => setCompAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  CONTACT PHONE
                </label>
                <input
                  type="text"
                  value={compPhone}
                  onChange={(e) => setCompPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  OFFICIAL EMAIL
                </label>
                <input
                  type="email"
                  value={compEmail}
                  onChange={(e) => setCompEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-5 py-2 font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors cursor-pointer uppercase"
              >
                <Save className="w-4 h-4" />
                <span>SAVE HEADER & PRINT CONFIGURATION</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
