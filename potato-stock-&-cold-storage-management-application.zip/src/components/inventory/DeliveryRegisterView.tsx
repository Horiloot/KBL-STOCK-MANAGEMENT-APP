import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { DeliveryTransaction } from '../../types';
import {
  Truck,
  PlusCircle,
  Edit2,
  Trash2,
  Printer,
  FileSpreadsheet,
  Search,
  Warehouse,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { DeliveryTransactionModal } from './DeliveryTransactionModal';
import { FilterBar } from '../common/FilterBar';

export const DeliveryRegisterView: React.FC = () => {
  const {
    deliveryTransactions,
    deleteDeliveryTransaction,
    coldStorages,
    varieties,
    seedClasses,
    grades,
    filters,
    hasPermission,
    companySettings,
    addToast,
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDelivery, setEditingDelivery] = useState<DeliveryTransaction | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStorageFilter, setSelectedStorageFilter] = useState<string>(filters.coldStorageId || '');
  const [sortKey, setSortKey] = useState<string>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Filter deliveries
  const filteredList = useMemo(() => {
    return deliveryTransactions.filter((d) => {
      if (selectedStorageFilter && d.coldStorageId !== selectedStorageFilter) {
        return false;
      }

      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const variety = varieties.find((v) => v.id === d.varietyId)?.name || '';
        const storage = coldStorages.find((c) => c.id === d.coldStorageId)?.name || '';
        const client = (d.customerReceiver || d.clientReceiver || '').toLowerCase();
        const match =
          d.deliveryNo.toLowerCase().includes(q) ||
          (d.deliveryReference && d.deliveryReference.toLowerCase().includes(q)) ||
          client.includes(q) ||
          variety.toLowerCase().includes(q) ||
          storage.toLowerCase().includes(q) ||
          (d.destination && d.destination.toLowerCase().includes(q)) ||
          (d.vehicleNo && d.vehicleNo.toLowerCase().includes(q));
        if (!match) return false;
      }

      return true;
    });
  }, [deliveryTransactions, selectedStorageFilter, searchTerm, varieties, coldStorages]);

  // Sort deliveries with lookups
  const sortedList = useMemo(() => {
    return sortData(filteredList, sortKey, sortDir, {
      coldStorage: (d) => coldStorages.find((c) => c.id === d.coldStorageId)?.name || '',
      client: (d) => d.customerReceiver || d.clientReceiver || '',
      variety: (d) => varieties.find((v) => v.id === d.varietyId)?.name || '',
      classGrade: (d) => {
        const cls = seedClasses.find((c) => c.id === d.classId)?.name || '';
        const grd = grades.find((g) => g.id === d.gradeId)?.name || '';
        return `${cls} ${grd}`.trim();
      },
      transport: (d) => `${d.vehicleNo || ''} ${d.driverName || ''}`.trim(),
    });
  }, [filteredList, sortKey, sortDir, coldStorages, varieties, seedClasses, grades]);

  // Pagination slice
  const totalPages = Math.max(1, Math.ceil(sortedList.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedList = sortedList.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const totalBags = filteredList.reduce((acc, d) => acc + d.sackQuantity, 0);
  const totalKg = filteredList.reduce((acc, d) => acc + d.totalKg, 0);
  const totalMt = filteredList.reduce((acc, d) => acc + d.totalMt, 0);
  const avgKgPerBag = totalBags > 0 ? (totalKg / totalBags).toFixed(1) : '-';

  const handleEdit = (del: DeliveryTransaction) => {
    setEditingDelivery(del);
    setIsModalOpen(true);
  };

  const handleOpenAdd = () => {
    setEditingDelivery(null);
    setIsModalOpen(true);
  };

  const handleExportExcel = () => {
    const exportData = filteredList.map((d) => {
      const storage = coldStorages.find((c) => c.id === d.coldStorageId)?.name || d.coldStorageId;
      const variety = varieties.find((v) => v.id === d.varietyId)?.name || d.varietyId;
      const seedClass = seedClasses.find((c) => c.id === d.classId)?.name || d.classId;
      const grade = grades.find((g) => g.id === d.gradeId)?.name || d.gradeId;

      return {
        date: d.date,
        deliveryNo: d.deliveryNo,
        reference: d.deliveryReference || d.doNumber || '-',
        coldStorage: storage,
        client: d.customerReceiver || d.clientReceiver || '-',
        destination: d.destination || '-',
        variety,
        class: seedClass,
        grade,
        bags: d.sackQuantity,
        kgPerBag: d.kgPerBag,
        totalKg: d.totalKg,
        totalMt: d.totalMt,
        vehicleNo: d.vehicleNo || '-',
        driver: d.driverName || '-',
        remarks: d.remarks || '-',
      };
    });

    exportToExcel(
      exportData,
      [
        { header: 'Date', key: 'date', width: 12 },
        { header: 'Delivery No', key: 'deliveryNo', width: 16 },
        { header: 'Reference', key: 'reference', width: 14 },
        { header: 'Cold Storage', key: 'coldStorage', width: 24 },
        { header: 'Customer / Consignee', key: 'client', width: 24 },
        { header: 'Destination', key: 'destination', width: 18 },
        { header: 'Variety', key: 'variety', width: 16 },
        { header: 'Class', key: 'class', width: 14 },
        { header: 'Grade', key: 'grade', width: 18 },
        { header: 'Bags', key: 'bags', width: 12 },
        { header: 'KG/Bag', key: 'kgPerBag', width: 10 },
        { header: 'Total KG', key: 'totalKg', width: 14 },
        { header: 'Total MT', key: 'totalMt', width: 14 },
        { header: 'Vehicle', key: 'vehicleNo', width: 16 },
      ],
      'Stock_Out_from_Cold_Storage_2024',
      'Stock Out from Cold Storage (Delivery Dispatches)',
      companySettings,
      `Records: ${filteredList.length} | Generated: ${new Date().toLocaleDateString()}`
    );
  };

  return (
    <div className="space-y-5">
      {/* Top Banner & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <Truck className="w-6 h-6 text-amber-500" />
            STOCK OUT FROM COLD STORAGE
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            COLD STORAGE OUTBOUND DISPATCHES, CLIENT RECEIVERS, GATE PASSES, AND TRANSPORT ORDERS
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          {hasPermission('add_delivery') && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 dark:bg-amber-500 dark:hover:bg-amber-600 rounded-xl shadow-xs transition-colors cursor-pointer uppercase"
            >
              <PlusCircle className="w-4 h-4" />
              <span>ISSUE STOCK OUT GATE PASS</span>
            </button>
          )}

          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXCEL EXPORT</span>
          </button>

          <button
            onClick={() => {
              if (filteredList.length === 0) {
                if (addToast) addToast('Delivery register is empty under current filters.', 'error');
                return;
              }

              const printRows = filteredList.map((d) => {
                const storage = coldStorages.find((c) => c.id === d.coldStorageId)?.name || '-';
                const variety = varieties.find((v) => v.id === d.varietyId)?.name || '-';
                const seedClass = seedClasses.find((c) => c.id === d.classId)?.name || '-';
                const grade = grades.find((g) => g.id === d.gradeId)?.name || '-';

                return {
                  date: d.date,
                  deliveryNo: d.deliveryNo,
                  coldStorage: storage,
                  client: d.customerReceiver || d.clientReceiver || '-',
                  destination: d.destination || '-',
                  variety,
                  classGrade: `${seedClass} ${grade && grade !== '-' ? `(${grade})` : ''}`.trim(),
                  bags: d.sackQuantity.toLocaleString(),
                  kgPerBag: d.kgPerBag.toString(),
                  totalKg: d.totalKg.toLocaleString(),
                  totalMt: d.totalMt.toFixed(2),
                  transport: `${d.vehicleNo || '-'} / ${d.driverName || '-'}`.trim(),
                };
              });

              validateAndTriggerPrint({
                data: printRows,
                reportTitle: 'STOCK OUT FROM COLD STORAGE REGISTER',
                companySettings,
                expectedMinRecords: 1,
                columns: [
                  { header: 'Date', key: 'date' },
                  { header: 'Delivery Order (DO)', key: 'deliveryNo' },
                  { header: 'From Cold Storage', key: 'coldStorage' },
                  { header: 'Client / Receiver', key: 'client' },
                  { header: 'Destination', key: 'destination' },
                  { header: 'Variety', key: 'variety' },
                  { header: 'Class & Grade', key: 'classGrade' },
                  { header: 'Bags', key: 'bags', align: 'right' },
                  { header: 'Kg/Bag', key: 'kgPerBag', align: 'right' },
                  { header: 'Total Kg', key: 'totalKg', align: 'right' },
                  { header: 'Total MT', key: 'totalMt', align: 'right' },
                  { header: 'Transport', key: 'transport' },
                ],
                databaseCheck: () => ({ isConsistent: true }),
                onError: (msg) => {
                  if (addToast) addToast(msg, 'error');
                },
              });
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Global Filter Bar */}
      <FilterBar />

      {/* KPI Summary strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            DISPATCHES EXECUTED
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {filteredList.length} Orders
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            DISPATCHED SACKS / BAGS
          </span>
          <span className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-0.5 block font-mono">
            {totalBags === 0 ? '-' : totalBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            DISPATCHED WEIGHT (KG)
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalKg === 0 ? '-' : totalKg.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            DISPATCHED WEIGHT (MT)
          </span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block font-mono">
            {totalMt === 0 ? '-' : totalMt.toFixed(2)} MT
          </span>
        </div>
      </div>

      {/* Search and Secondary Filter Row */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs no-print">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by DO No, Client, Variety, Vehicle..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Warehouse className="w-4 h-4 text-slate-400 shrink-0 hidden sm:block" />
          <select
            value={selectedStorageFilter}
            onChange={(e) => setSelectedStorageFilter(e.target.value)}
            className="text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-1.5 outline-none focus:ring-2 focus:ring-amber-500 font-medium"
          >
            <option value="">All Cold Storages</option>
            {coldStorages.map((cs) => (
              <option key={cs.id} value={cs.id}>
                {cs.name} ({cs.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Tabular View */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="DATE" sortKey="date" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="DELIVERY ORDER (DO)" sortKey="deliveryNo" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="FROM COLD STORAGE" sortKey="coldStorage" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLIENT / RECEIVER" sortKey="client" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="DESTINATION" sortKey="destination" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="VARIETY" sortKey="variety" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLASS & GRADE" sortKey="classGrade" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="BAGS" sortKey="sackQuantity" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="KG/BAG" sortKey="kgPerBag" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL KG" sortKey="totalKg" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL MT" sortKey="totalMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TRANSPORT" sortKey="transport" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <th className="py-3 px-3 text-center no-print">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedList.length === 0 ? (
                <tr>
                  <td colSpan={13} className="py-8 text-center text-slate-400 italic">
                    No outbound deliveries recorded matching your filters.
                  </td>
                </tr>
              ) : (
                paginatedList.map((d) => {
                  const storage = coldStorages.find((c) => c.id === d.coldStorageId);
                  const variety = varieties.find((v) => v.id === d.varietyId);
                  const seedClass = seedClasses.find((c) => c.id === d.classId);
                  const grade = grades.find((g) => g.id === d.gradeId);

                  return (
                    <tr
                      key={d.id}
                      className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                    >
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">
                        {d.date}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-amber-600 dark:text-amber-400 whitespace-nowrap">
                        {d.deliveryNo}
                      </td>
                      <td className="py-2.5 px-3 text-slate-800 dark:text-slate-200">
                        <div className="font-semibold">{storage?.name || '-'}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{storage?.code}</div>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                        {d.customerReceiver || d.clientReceiver || '-'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                        {d.destination || '-'}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                        {variety?.name || '-'}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="text-[11px] font-medium text-slate-700 dark:text-slate-300">
                          {seedClass?.name || '-'}
                        </div>
                        <div className="text-[10px] text-slate-400">{grade?.name || '-'}</div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-amber-600 dark:text-amber-400 font-mono">
                        {d.sackQuantity === 0 ? '-' : d.sackQuantity.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500 font-mono">
                        {d.kgPerBag === 0 ? '-' : d.kgPerBag}
                      </td>
                      <td className="py-2.5 px-3 text-right font-medium text-slate-800 dark:text-slate-200 font-mono">
                        {d.totalKg === 0 ? '-' : d.totalKg.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-900 dark:text-white font-mono">
                        {d.totalMt === 0 ? '-' : d.totalMt.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-[11px] text-slate-500 dark:text-slate-400 max-w-[150px] truncate">
                        {d.vehicleNo || d.driverName ? (
                          <div>
                            <div>{d.vehicleNo || '-'}</div>
                            <div className="text-[10px] text-slate-400">{d.driverName || '-'}</div>
                          </div>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center no-print whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          {hasPermission('edit_delivery') && (
                            <button
                              onClick={() => handleEdit(d)}
                              className="p-1 rounded-md text-slate-400 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                              title="Edit delivery"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {hasPermission('delete_delivery') && (
                            <button
                              onClick={() => deleteDeliveryTransaction(d.id)}
                              className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                              title="Delete delivery"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {filteredList.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                  <td colSpan={7} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                    TOTAL DISPATCHED BALANCE:
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-600 dark:text-amber-400">
                    {totalBags === 0 ? '-' : totalBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-[11px] text-slate-500">
                    {avgKgPerBag}
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    {totalKg === 0 ? '-' : totalKg.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400">
                    {totalMt === 0 ? '-' : totalMt.toFixed(2)} MT
                  </td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Pagination */}
        {sortedList.length > 0 && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedList.length}
            pageSizeOptions={[10, 15, 25, 50, 100]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>

      {/* Delivery Transaction Modal */}
      {isModalOpen && (
        <DeliveryTransactionModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          editDelivery={editingDelivery}
        />
      )}
    </div>
  );
};
