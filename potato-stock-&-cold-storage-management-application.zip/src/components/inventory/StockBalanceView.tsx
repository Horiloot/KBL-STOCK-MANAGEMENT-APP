import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { calculateStockBalanceMatrix } from '../../utils/stockEngine';
import {
  Scale,
  FileSpreadsheet,
  Printer,
  Search,
  Warehouse,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { FilterBar } from '../common/FilterBar';

export const StockBalanceView: React.FC = () => {
  const {
    stockTransactions,
    deliveryTransactions,
    coldStorages,
    varieties,
    seedClasses,
    grades,
    filters,
    companySettings,
    addToast,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStorage, setSelectedStorage] = useState<string>(filters.coldStorageId || '');
  const [sortKey, setSortKey] = useState<string>('coldStorageName');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Calculate comprehensive balance matrix using stockEngine
  const balanceMatrix = useMemo(() => {
    return calculateStockBalanceMatrix(
      stockTransactions,
      deliveryTransactions,
      coldStorages,
      varieties,
      seedClasses,
      grades
    );
  }, [stockTransactions, deliveryTransactions, coldStorages, varieties, seedClasses, grades]);

  // Filter matrix
  const filteredMatrix = useMemo(() => {
    return balanceMatrix.filter((item) => {
      if (selectedStorage && item.coldStorageId !== selectedStorage) {
        return false;
      }

      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const match =
          item.coldStorageName.toLowerCase().includes(q) ||
          item.varietyName.toLowerCase().includes(q) ||
          item.className.toLowerCase().includes(q) ||
          item.gradeName.toLowerCase().includes(q);
        if (!match) return false;
      }

      return true;
    });
  }, [balanceMatrix, selectedStorage, searchTerm]);

  // Sort matrix
  const sortedMatrix = useMemo(() => {
    return sortData(filteredMatrix, sortKey, sortDir);
  }, [filteredMatrix, sortKey, sortDir]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(sortedMatrix.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedMatrix = sortedMatrix.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const totalInboundBags = filteredMatrix.reduce((acc, i) => acc + i.inboundBags, 0);
  const totalInboundMt = filteredMatrix.reduce((acc, i) => acc + i.inboundMt, 0);
  const totalDeliveredBags = filteredMatrix.reduce((acc, i) => acc + i.deliveredBags, 0);
  const totalDeliveredMt = filteredMatrix.reduce((acc, i) => acc + i.deliveredMt, 0);
  const totalBalanceBags = filteredMatrix.reduce((acc, i) => acc + i.balanceBags, 0);
  const totalBalanceKg = filteredMatrix.reduce((acc, i) => acc + i.balanceKg, 0);
  const totalBalanceMt = filteredMatrix.reduce((acc, i) => acc + i.balanceMt, 0);

  const handleExportExcel = () => {
    const exportData = filteredMatrix.map((item) => ({
      coldStorage: item.coldStorageName,
      variety: item.varietyName,
      class: item.className,
      grade: item.gradeName,
      inboundBags: item.inboundBags,
      inboundMt: item.inboundMt,
      deliveredBags: item.deliveredBags,
      deliveredMt: item.deliveredMt,
      balanceBags: item.balanceBags,
      balanceKg: item.balanceKg,
      balanceMt: item.balanceMt,
    }));

    exportToExcel(
      exportData,
      [
        { header: 'Cold Storage Facility', key: 'coldStorage', width: 28 },
        { header: 'Variety', key: 'variety', width: 16 },
        { header: 'Seed Class', key: 'class', width: 16 },
        { header: 'Grade', key: 'grade', width: 20 },
        { header: 'Inbound Bags', key: 'inboundBags', width: 14 },
        { header: 'Inbound MT', key: 'inboundMt', width: 14 },
        { header: 'Delivered Bags', key: 'deliveredBags', width: 14 },
        { header: 'Delivered MT', key: 'deliveredMt', width: 14 },
        { header: 'Balance Bags', key: 'balanceBags', width: 14 },
        { header: 'Balance KG', key: 'balanceKg', width: 14 },
        { header: 'Balance MT', key: 'balanceMt', width: 14 },
      ],
      'Cold_Storage_Stock_Details_Balance_2024',
      'Cold Storage Stock Details (Live Inventory Balance Matrix)',
      companySettings,
      `Records: ${filteredMatrix.length} | Generated: ${new Date().toLocaleDateString()}`
    );
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <Scale className="w-6 h-6 text-sky-600 dark:text-sky-400" />
            COLD STORAGE STOCK DETAILS
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            REAL-TIME BALANCE RECONCILIATION: INBOUND RECEIPTS MINUS OUTBOUND DISPATCHES
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXCEL EXPORT</span>
          </button>

          <button
            onClick={() => {
              if (filteredMatrix.length === 0) {
                if (addToast) addToast('Stock balance matrix is empty under current filters.', 'error');
                return;
              }

              const printRows = filteredMatrix.map((item) => ({
                coldStorage: item.coldStorageName,
                variety: item.varietyName,
                classGrade: `${item.className} (${item.gradeName})`,
                inboundBags: item.inboundBags.toLocaleString(),
                inboundMt: item.inboundMt.toFixed(2),
                deliveredBags: item.deliveredBags.toLocaleString(),
                deliveredMt: item.deliveredMt.toFixed(2),
                balanceBags: item.balanceBags.toLocaleString(),
                balanceMt: item.balanceMt.toFixed(2),
              }));

              validateAndTriggerPrint({
                data: printRows,
                reportTitle: 'COLD STORAGE STOCK DETAILS MATRIX',
                companySettings,
                expectedMinRecords: 1,
                columns: [
                  { header: 'Cold Storage', key: 'coldStorage' },
                  { header: 'Variety', key: 'variety' },
                  { header: 'Class & Grade', key: 'classGrade' },
                  { header: 'Inbound (Bags)', key: 'inboundBags', align: 'right' },
                  { header: 'Inbound (MT)', key: 'inboundMt', align: 'right' },
                  { header: 'Dispatched (Bags)', key: 'deliveredBags', align: 'right' },
                  { header: 'Dispatched (MT)', key: 'deliveredMt', align: 'right' },
                  { header: 'Balance (Bags)', key: 'balanceBags', align: 'right' },
                  { header: 'Balance (MT)', key: 'balanceMt', align: 'right' },
                ],
                databaseCheck: () => ({ isConsistent: true }),
                onError: (msg) => {
                  if (addToast) addToast(msg, 'error');
                },
              });
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <FilterBar />

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL INBOUND BAGS
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalInboundBags === 0 ? '-' : totalInboundBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            STOCK OUT DISPATCHED
          </span>
          <span className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-0.5 block font-mono">
            {totalDeliveredBags === 0 ? '-' : totalDeliveredBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            VAULT REMAINING BAGS
          </span>
          <span className="text-xl font-bold text-sky-600 dark:text-sky-400 mt-0.5 block font-mono">
            {totalBalanceBags === 0 ? '-' : totalBalanceBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            NET METRIC TONS (MT)
          </span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block font-mono">
            {totalBalanceMt === 0 ? '-' : totalBalanceMt.toFixed(2)} MT
          </span>
        </div>
      </div>

      {/* Search and Secondary Filter Row */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs no-print">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Variety, Storage, Grade..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Warehouse className="w-4 h-4 text-slate-400 shrink-0 hidden sm:block" />
          <select
            value={selectedStorage}
            onChange={(e) => setSelectedStorage(e.target.value)}
            className="text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-1.5 outline-none focus:ring-2 focus:ring-sky-500 font-medium uppercase"
          >
            <option value="">ALL COLD STORAGES</option>
            {coldStorages.map((cs) => (
              <option key={cs.id} value={cs.id}>
                {cs.name} ({cs.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Tabular View */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="COLD STORAGE FACILITY" sortKey="coldStorageName" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="VARIETY" sortKey="varietyName" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLASS" sortKey="className" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="GRADE" sortKey="gradeName" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="INBOUND BAGS" sortKey="inboundBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="INBOUND MT" sortKey="inboundMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="DISPATCHED BAGS" sortKey="deliveredBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="DISPATCHED MT" sortKey="deliveredMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="BALANCE BAGS" sortKey="balanceBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="BALANCE MT" sortKey="balanceMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedMatrix.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-400 italic">
                    No active stock lots found matching your filter criteria.
                  </td>
                </tr>
              ) : (
                paginatedMatrix.map((item, idx) => (
                  <tr
                    key={idx}
                    className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {item.coldStorageName}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                      {item.varietyName}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {item.className}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                      {item.gradeName}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-700 dark:text-slate-300 font-mono">
                      {item.inboundBags === 0 ? '-' : item.inboundBags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-500 font-mono">
                      {item.inboundMt === 0 ? '-' : item.inboundMt.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-amber-600 dark:text-amber-400 font-mono">
                      {item.deliveredBags === 0 ? '-' : item.deliveredBags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-500 font-mono">
                      {item.deliveredMt === 0 ? '-' : item.deliveredMt.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-sky-600 dark:text-sky-400 font-mono bg-sky-50/30 dark:bg-sky-950/10">
                      {item.balanceBags === 0 ? '-' : item.balanceBags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400 font-mono bg-sky-50/30 dark:bg-sky-950/10">
                      {item.balanceMt === 0 ? '-' : item.balanceMt.toFixed(2)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {filteredMatrix.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                  <td colSpan={4} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                    TOTAL ENTERPRISE VAULT POSITION:
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-800 dark:text-slate-200">
                    {totalInboundBags === 0 ? '-' : totalInboundBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-500">
                    {totalInboundMt === 0 ? '-' : totalInboundMt.toFixed(2)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-600 dark:text-amber-400">
                    {totalDeliveredBags === 0 ? '-' : totalDeliveredBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-500">
                    {totalDeliveredMt === 0 ? '-' : totalDeliveredMt.toFixed(2)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sky-600 dark:text-sky-400 bg-sky-100/50 dark:bg-sky-900/30 text-sm">
                    {totalBalanceBags === 0 ? '-' : totalBalanceBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400 bg-sky-100/50 dark:bg-sky-900/30 text-sm">
                    {totalBalanceMt === 0 ? '-' : totalBalanceMt.toFixed(2)} MT
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Pagination */}
        {sortedMatrix.length > 0 && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedMatrix.length}
            pageSizeOptions={[10, 15, 25, 50, 100]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>
    </div>
  );
};
