import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { StockTransaction } from '../../types';
import {
  Boxes,
  PlusCircle,
  Edit2,
  Trash2,
  Printer,
  FileSpreadsheet,
  Search,
  Warehouse,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { StockTransactionModal } from './StockTransactionModal';
import { FilterBar } from '../common/FilterBar';
import { ColdStorageEmptyState } from '../coldStorage/ColdStorageEmptyState';

export const StockRegisterView: React.FC = () => {
  const {
    stockTransactions,
    deleteStockTransaction,
    coldStorages,
    varieties,
    seedClasses,
    grades,
    filters,
    hasPermission,
    companySettings,
    setActiveTab,
    addToast,
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<StockTransaction | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStorageFilter, setSelectedStorageFilter] = useState<string>(filters.coldStorageId || '');
  const [sortKey, setSortKey] = useState<string>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Filter Transactions
  const filteredList = useMemo(() => {
    return stockTransactions.filter((s) => {
      // Cold storage filter
      if (selectedStorageFilter && s.coldStorageId !== selectedStorageFilter) {
        return false;
      }

      // Search filter
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const variety = varieties.find((v) => v.id === s.varietyId)?.name || '';
        const storage = coldStorages.find((c) => c.id === s.coldStorageId)?.name || '';
        const match =
          s.kblChallanNo.toLowerCase().includes(q) ||
          s.srNo.toLowerCase().includes(q) ||
          variety.toLowerCase().includes(q) ||
          storage.toLowerCase().includes(q) ||
          (s.truckNo && s.truckNo.toLowerCase().includes(q)) ||
          (s.driverName && s.driverName.toLowerCase().includes(q)) ||
          (s.growerFarmerName && s.growerFarmerName.toLowerCase().includes(q));
        if (!match) return false;
      }

      return true;
    });
  }, [stockTransactions, selectedStorageFilter, searchTerm, varieties, coldStorages]);

  // Sort transactions with lookup resolvers
  const sortedList = useMemo(() => {
    return sortData(filteredList, sortKey, sortDir, {
      coldStorage: (s) => coldStorages.find((c) => c.id === s.coldStorageId)?.name || '',
      variety: (s) => varieties.find((v) => v.id === s.varietyId)?.name || '',
      class: (s) => seedClasses.find((c) => c.id === s.classId)?.name || '',
      grade: (s) => grades.find((g) => g.id === s.gradeId)?.name || '',
      logistics: (s) => `${s.truckNo || ''} ${s.driverName || ''}`.trim(),
    });
  }, [filteredList, sortKey, sortDir, coldStorages, varieties, seedClasses, grades]);

  // Pagination slice
  const totalPages = Math.max(1, Math.ceil(sortedList.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedList = sortedList.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const totalBags = filteredList.reduce((acc, s) => acc + s.sackQuantity, 0);
  const totalKg = filteredList.reduce((acc, s) => acc + s.totalKg, 0);
  const totalMt = filteredList.reduce((acc, s) => acc + s.totalMt, 0);
  const avgKgPerBag = totalBags > 0 ? (totalKg / totalBags).toFixed(1) : '-';

  const handleEdit = (trx: StockTransaction) => {
    setEditingTransaction(trx);
    setIsModalOpen(true);
  };

  const handleOpenAdd = () => {
    setEditingTransaction(null);
    setIsModalOpen(true);
  };

  const handleExportExcel = () => {
    const exportData = filteredList.map((s) => {
      const storage = coldStorages.find((c) => c.id === s.coldStorageId)?.name || s.coldStorageId;
      const variety = varieties.find((v) => v.id === s.varietyId)?.name || s.varietyId;
      const seedClass = seedClasses.find((c) => c.id === s.classId)?.name || s.classId;
      const grade = grades.find((g) => g.id === s.gradeId)?.name || s.gradeId;

      return {
        date: s.date,
        challan: s.kblChallanNo,
        sr: s.srNo,
        coldStorage: storage,
        variety,
        class: seedClass,
        grade,
        bags: s.sackQuantity,
        kgPerBag: s.kgPerBag,
        totalKg: s.totalKg,
        totalMt: s.totalMt,
        truckNo: s.truckNo || '-',
        driver: s.driverName || '-',
        grower: s.growerFarmerName || '-',
        remarks: s.remarks || '-',
      };
    });

    exportToExcel(
      exportData,
      [
        { header: 'Date', key: 'date', width: 12 },
        { header: 'KBL Challan No', key: 'challan', width: 16 },
        { header: 'SR No', key: 'sr', width: 12 },
        { header: 'Cold Storage', key: 'coldStorage', width: 26 },
        { header: 'Variety', key: 'variety', width: 16 },
        { header: 'Seed Class', key: 'class', width: 14 },
        { header: 'Grade', key: 'grade', width: 18 },
        { header: 'Bags', key: 'bags', width: 12 },
        { header: 'KG/Bag', key: 'kgPerBag', width: 10 },
        { header: 'Total KG', key: 'totalKg', width: 14 },
        { header: 'Total MT', key: 'totalMt', width: 14 },
        { header: 'Truck No', key: 'truckNo', width: 16 },
        { header: 'Driver', key: 'driver', width: 16 },
        { header: 'Grower/Farmer', key: 'grower', width: 20 },
      ],
      'Potato_Send_to_Cold_Storage_Details_2024',
      'Potato Send to Cold Storage Details (Inbound Log)',
      companySettings,
      `Records: ${filteredList.length} | Generated: ${new Date().toLocaleDateString()}`
    );
  };

  return (
    <div className="space-y-5">
      {/* Top Banner & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <Boxes className="w-6 h-6 text-sky-600 dark:text-sky-400" />
            POTATO SEND TO COLD STORAGE DETAILS
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            COMPLETE INBOUND RECEIPTS LOG, KBL CHALLANS, VERIFICATION, AND COLD STORAGE ALLOTMENTS
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          {hasPermission('add_stock') && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-600 rounded-xl shadow-xs transition-colors cursor-pointer uppercase"
            >
              <PlusCircle className="w-4 h-4" />
              <span>SEND TO COLD STORAGE</span>
            </button>
          )}

          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXCEL EXPORT</span>
          </button>

          <button
            onClick={() => {
              if (filteredList.length === 0) {
                if (addToast) addToast('Inbound register is empty under current filters.', 'error');
                return;
              }

              const printRows = filteredList.map((s) => {
                const storage = coldStorages.find((c) => c.id === s.coldStorageId)?.name || '-';
                const variety = varieties.find((v) => v.id === s.varietyId)?.name || '-';
                const seedClass = seedClasses.find((c) => c.id === s.classId)?.name || '-';
                const grade = grades.find((g) => g.id === s.gradeId)?.name || '-';

                return {
                  date: s.date,
                  challan: s.kblChallanNo,
                  sr: s.srNo,
                  coldStorage: storage,
                  variety,
                  classGrade: `${seedClass} ${grade && grade !== '-' ? `(${grade})` : ''}`.trim(),
                  bags: s.sackQuantity.toLocaleString(),
                  kgPerBag: s.kgPerBag.toString(),
                  totalKg: s.totalKg.toLocaleString(),
                  totalMt: s.totalMt.toFixed(2),
                  logistics: `${s.truckNo || '-'} / ${s.driverName || '-'}`.trim(),
                };
              });

              validateAndTriggerPrint({
                data: printRows,
                reportTitle: 'POTATO SEND TO COLD STORAGE INBOUND REGISTER',
                companySettings,
                expectedMinRecords: 1,
                columns: [
                  { header: 'Date', key: 'date' },
                  { header: 'KBL Challan', key: 'challan' },
                  { header: 'SR No', key: 'sr' },
                  { header: 'Cold Storage', key: 'coldStorage' },
                  { header: 'Variety', key: 'variety' },
                  { header: 'Class & Grade', key: 'classGrade' },
                  { header: 'Bags', key: 'bags', align: 'right' },
                  { header: 'Kg/Bag', key: 'kgPerBag', align: 'right' },
                  { header: 'Total Kg', key: 'totalKg', align: 'right' },
                  { header: 'Total MT', key: 'totalMt', align: 'right' },
                  { header: 'Logistics', key: 'logistics' },
                ],
                databaseCheck: () => ({ isConsistent: true }),
                onError: (msg) => {
                  if (addToast) addToast(msg, 'error');
                },
              });
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Global Filter Bar */}
      <FilterBar />

      {/* KPI Summary strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Total Inbound Lots
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {filteredList.length} Lots
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Total Sacks / Bags
          </span>
          <span className="text-xl font-bold text-sky-600 dark:text-sky-400 mt-0.5 block font-mono">
            {totalBags === 0 ? '-' : totalBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Net Weight (KG)
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalKg === 0 ? '-' : totalKg.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            NET METRIC TONS (MT)
          </span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block font-mono">
            {totalMt === 0 ? '-' : totalMt.toFixed(2)} MT
          </span>
        </div>
      </div>

      {/* Search and Secondary Filter Row */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs no-print">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Challan, SR, Variety, Truck or Driver..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Warehouse className="w-4 h-4 text-slate-400 shrink-0 hidden sm:block" />
          <select
            value={selectedStorageFilter}
            onChange={(e) => setSelectedStorageFilter(e.target.value)}
            className="text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-1.5 outline-none focus:ring-2 focus:ring-sky-500 font-medium"
          >
            <option value="">All Cold Storages</option>
            {coldStorages.map((cs) => (
              <option key={cs.id} value={cs.id}>
                {cs.name} ({cs.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Tabular View */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="DATE" sortKey="date" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="KBL CHALLAN NO" sortKey="kblChallanNo" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="SR NO" sortKey="srNo" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="COLD STORAGE" sortKey="coldStorage" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="VARIETY" sortKey="variety" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLASS" sortKey="class" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="GRADE" sortKey="grade" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="BAGS" sortKey="sackQuantity" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="KG/BAG" sortKey="kgPerBag" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL KG" sortKey="totalKg" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL MT" sortKey="totalMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="LOGISTICS" sortKey="logistics" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <th className="py-3 px-3 text-center no-print">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedList.length === 0 ? (
                <tr>
                  <td colSpan={13} className="py-8 text-center text-slate-400 italic">
                    {coldStorages.length === 0 ? (
                      <ColdStorageEmptyState onAddStorage={() => setActiveTab('cold-storage')} />
                    ) : (
                      'No inbound stock receipts found matching your filters.'
                    )}
                  </td>
                </tr>
              ) : (
                paginatedList.map((s) => {
                  const storage = coldStorages.find((c) => c.id === s.coldStorageId);
                  const variety = varieties.find((v) => v.id === s.varietyId);
                  const seedClass = seedClasses.find((c) => c.id === s.classId);
                  const grade = grades.find((g) => g.id === s.gradeId);

                  return (
                    <tr
                      key={s.id}
                      className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                    >
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">
                        {s.date}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-sky-600 dark:text-sky-400 whitespace-nowrap">
                        {s.kblChallanNo}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-semibold text-slate-800 dark:text-slate-200 whitespace-nowrap">
                        {s.srNo}
                      </td>
                      <td className="py-2.5 px-3 text-slate-800 dark:text-slate-200">
                        <div className="font-semibold">{storage?.name || '-'}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{storage?.code}</div>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                        {variety?.name || '-'}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50 whitespace-nowrap">
                          {seedClass?.name || '-'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {grade?.name || '-'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-900 dark:text-white font-mono">
                        {s.sackQuantity === 0 ? '-' : s.sackQuantity.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500 font-mono">
                        {s.kgPerBag === 0 ? '-' : s.kgPerBag}
                      </td>
                      <td className="py-2.5 px-3 text-right font-medium text-slate-800 dark:text-slate-200 font-mono">
                        {s.totalKg === 0 ? '-' : s.totalKg.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-sky-600 dark:text-sky-400 font-mono">
                        {s.totalMt === 0 ? '-' : s.totalMt.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-[11px] text-slate-500 dark:text-slate-400 max-w-[150px] truncate">
                        {s.truckNo || s.driverName ? (
                          <div>
                            <div>{s.truckNo || '-'}</div>
                            <div className="text-[10px] text-slate-400">{s.driverName || '-'}</div>
                          </div>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center no-print whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          {hasPermission('edit_stock') && (
                            <button
                              onClick={() => handleEdit(s)}
                              className="p-1 rounded-md text-slate-400 hover:text-sky-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                              title="Edit transaction"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {hasPermission('delete_stock') && (
                            <button
                              onClick={() => deleteStockTransaction(s.id)}
                              className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                              title="Delete transaction"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {filteredList.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                  <td colSpan={7} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                    TOTAL INBOUND BALANCE:
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sky-600 dark:text-sky-400">
                    {totalBags === 0 ? '-' : totalBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-[11px] text-slate-500">
                    {avgKgPerBag}
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    {totalKg === 0 ? '-' : totalKg.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400">
                    {totalMt === 0 ? '-' : totalMt.toFixed(2)} MT
                  </td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Pagination */}
        {sortedList.length > 0 && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedList.length}
            pageSizeOptions={[10, 15, 25, 50, 100]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>

      {/* Stock Transaction Modal */}
      {isModalOpen && (
        <StockTransactionModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          editTransaction={editingTransaction}
        />
      )}
    </div>
  );
};
