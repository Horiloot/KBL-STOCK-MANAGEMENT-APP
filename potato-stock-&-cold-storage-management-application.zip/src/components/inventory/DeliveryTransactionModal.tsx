import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { DeliveryTransaction } from '../../types';
import {
  Truck,
  Calendar,
  Warehouse,
  Sprout,
  Save,
  User,
  Weight,
  AlertTriangle,
} from 'lucide-react';
import { deliveryTransactionSchema } from '../../utils/validationSchemas';

interface DeliveryTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  editDelivery?: DeliveryTransaction | null;
}

export const DeliveryTransactionModal: React.FC<DeliveryTransactionModalProps> = ({
  isOpen,
  onClose,
  editDelivery,
}) => {
  const {
    coldStorages,
    varieties,
    seedClasses,
    grades,
    stockTransactions,
    deliveryTransactions,
    addDeliveryTransaction,
    updateDeliveryTransaction,
    addToast,
  } = useApp();

  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [deliveryNo, setDeliveryNo] = useState('');
  const [coldStorageId, setColdStorageId] = useState(coldStorages[0]?.id || '');
  const [varietyId, setVarietyId] = useState(varieties[0]?.id || '');
  const [classId, setClassId] = useState(seedClasses[0]?.id || '');
  const [gradeId, setGradeId] = useState(grades[0]?.id || '');
  const [customerReceiver, setCustomerReceiver] = useState('');
  const [deliveryReference, setDeliveryReference] = useState('');
  const [destination, setDestination] = useState('');
  const [vehicleNo, setVehicleNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [sackQuantity, setSackQuantity] = useState<number>(50);
  const [kgPerBag, setKgPerBag] = useState<number>(50);
  const [remarks, setRemarks] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Compute available stock in selected cold storage & variety
  const stockLots = stockTransactions.filter(
    (s) =>
      s.coldStorageId === coldStorageId &&
      s.varietyId === varietyId &&
      s.classId === classId &&
      s.gradeId === gradeId
  );
  const totalInboundBags = stockLots.reduce((acc, s) => acc + s.sackQuantity, 0);

  const prevDeliveries = deliveryTransactions.filter(
    (d) =>
      d.coldStorageId === coldStorageId &&
      d.varietyId === varietyId &&
      d.classId === classId &&
      d.gradeId === gradeId &&
      (!editDelivery || d.id !== editDelivery.id)
  );
  const totalDeliveredBags = prevDeliveries.reduce((acc, d) => acc + d.sackQuantity, 0);
  const availableBags = Math.max(0, totalInboundBags - totalDeliveredBags);

  useEffect(() => {
    if (editDelivery) {
      setDate(editDelivery.date);
      setDeliveryNo(editDelivery.deliveryNo);
      setColdStorageId(editDelivery.coldStorageId);
      setVarietyId(editDelivery.varietyId);
      setClassId(editDelivery.classId);
      setGradeId(editDelivery.gradeId);
      setCustomerReceiver(editDelivery.customerReceiver || editDelivery.clientReceiver || '');
      setDeliveryReference(editDelivery.deliveryReference || editDelivery.doNumber || '');
      setDestination(editDelivery.destination || '');
      setVehicleNo(editDelivery.vehicleNo || '');
      setDriverName(editDelivery.driverName || '');
      setDriverPhone(editDelivery.driverPhone || '');
      setSackQuantity(editDelivery.sackQuantity);
      setKgPerBag(editDelivery.kgPerBag);
      setRemarks(editDelivery.remarks || '');
    } else {
      setDate(new Date().toISOString().split('T')[0]);
      setDeliveryNo(`DO-${Math.floor(Math.random() * 900 + 100)}`);
      setColdStorageId(coldStorages[0]?.id || '');
      setVarietyId(varieties[0]?.id || '');
      setClassId(seedClasses[0]?.id || '');
      setGradeId(grades[0]?.id || '');
      setCustomerReceiver('');
      setDeliveryReference(`REF-${Math.floor(Math.random() * 9000 + 1000)}`);
      setDestination('');
      setVehicleNo('');
      setDriverName('');
      setDriverPhone('');
      setSackQuantity(50);
      setKgPerBag(50);
      setRemarks('');
    }
    setErrors({});
  }, [editDelivery, isOpen, coldStorages, varieties, seedClasses, grades]);

  const totalKg = sackQuantity * kgPerBag;
  const totalMt = totalKg / 1000;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (sackQuantity > availableBags) {
      setErrors({
        sackQuantity: `Requested ${sackQuantity} bags exceeds available balance (${availableBags} bags) in this storage lot.`,
      });
      return;
    }

    const payload = {
      date,
      deliveryNo: deliveryNo.trim(),
      doNumber: deliveryReference.trim() || undefined,
      coldStorageId,
      varietyId,
      classId,
      gradeId,
      customerReceiver: customerReceiver.trim(),
      clientReceiver: customerReceiver.trim(),
      deliveryReference: deliveryReference.trim() || undefined,
      destination: destination.trim() || undefined,
      vehicleNo: vehicleNo.trim() || undefined,
      driverName: driverName.trim() || undefined,
      driverPhone: driverPhone.trim() || undefined,
      sackQuantity: Number(sackQuantity),
      kgPerBag: Number(kgPerBag),
      totalKg,
      totalMt,
      status: 'approved' as const,
      remarks: remarks.trim() || undefined,
    };

    const result = deliveryTransactionSchema.safeParse(payload);
    if (!result.success) {
      const errMap: Record<string, string> = {};
      result.error.issues.forEach((err: any) => {
        if (err.path[0]) {
          errMap[err.path[0].toString()] = err.message;
        }
      });
      setErrors(errMap);
      return;
    }

    if (editDelivery) {
      updateDeliveryTransaction(editDelivery.id, payload);
      if (addToast) addToast(`Updated Delivery Order ${payload.deliveryNo}`, 'success');
    } else {
      addDeliveryTransaction(payload);
      if (addToast) addToast(`Issued Gate Pass & Delivery Order ${payload.deliveryNo}`, 'success');
    }

    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editDelivery ? 'Edit Delivery Order' : 'Issue Stock Out & Delivery Challan'}
      subtitle="Release seed stock from cold storage chamber to client farmer or distribution partner"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {/* Row 1: Date & Delivery No */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Delivery Date <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              />
            </div>
            {errors.date && <p className="text-rose-500 text-[10px] mt-0.5">{errors.date}</p>}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Delivery Order (DO No) <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={deliveryNo}
              onChange={(e) => setDeliveryNo(e.target.value)}
              placeholder="e.g. DO-101"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-mono font-semibold"
            />
            {errors.deliveryNo && (
              <p className="text-rose-500 text-[10px] mt-0.5">{errors.deliveryNo}</p>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Delivery Ref / SO No
            </label>
            <input
              type="text"
              value={deliveryReference}
              onChange={(e) => setDeliveryReference(e.target.value)}
              placeholder="e.g. REF-2024-01"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-mono"
            />
          </div>
        </div>

        {/* Row 2: Origin Cold Storage & Variety Selection */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              From Cold Storage Facility <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Warehouse className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <select
                value={coldStorageId}
                onChange={(e) => setColdStorageId(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                {coldStorages.map((cs) => (
                  <option key={cs.id} value={cs.id}>
                    {cs.name} ({cs.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Potato Variety <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Sprout className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <select
                value={varietyId}
                onChange={(e) => setVarietyId(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                {varieties.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} ({v.type})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Row 3: Class & Grade + Live Stock Indicator */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Seed Class <span className="text-rose-500">*</span>
            </label>
            <select
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
            >
              {seedClasses.map((sc) => (
                <option key={sc.id} value={sc.id}>
                  {sc.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Size Grade <span className="text-rose-500">*</span>
            </label>
            <select
              value={gradeId}
              onChange={(e) => setGradeId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
            >
              {grades.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name} ({g.sizeRange})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Live Available Stock Notice Banner */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-500 animate-pulse" />
            <span className="text-slate-700 dark:text-slate-300 font-semibold">
              Live Vault Balance for this Specification:
            </span>
          </div>
          <span className="text-sm font-bold text-sky-700 dark:text-sky-300">
            {availableBags === 0 ? '-' : `${availableBags.toLocaleString()} Bags Available`}
          </span>
        </div>

        {/* Row 4: Client & Destination */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Customer / Consignee Receiver <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={customerReceiver}
                onChange={(e) => setCustomerReceiver(e.target.value)}
                placeholder="e.g. Apex Agri Seed Network"
                required
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              />
            </div>
            {errors.customerReceiver && (
              <p className="text-rose-500 text-[10px] mt-0.5">{errors.customerReceiver}</p>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Destination City / Farm Center
            </label>
            <input
              type="text"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="e.g. Rangpur Central Hub"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
        </div>

        {/* Row 5: Bags & Quantities */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-3">
            <Weight className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <h4 className="font-bold text-slate-900 dark:text-white">
              Dispatch Quantity & Weight
            </h4>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block font-semibold text-slate-600 dark:text-slate-400 text-[11px] mb-1">
                Quantity (Bags) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                max={availableBags > 0 ? availableBags : undefined}
                value={sackQuantity}
                onChange={(e) => setSackQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                required
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-600 dark:text-slate-400 text-[11px] mb-1">
                KG per Bag <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                step="0.5"
                value={kgPerBag}
                onChange={(e) => setKgPerBag(Math.max(1, parseFloat(e.target.value) || 0))}
                required
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Total Net Weight</span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {totalKg.toLocaleString()} KG
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Metric Tons</span>
              <span className="text-sm font-bold text-amber-600 dark:text-amber-400 mt-0.5">
                {totalMt.toFixed(2)} MT
              </span>
            </div>
          </div>

          {errors.sackQuantity && (
            <div className="mt-2.5 p-2 rounded-lg bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 flex items-center gap-1.5 text-[11px]">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{errors.sackQuantity}</span>
            </div>
          )}
        </div>

        {/* Row 6: Transport & Driver Details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Vehicle / Truck No
            </label>
            <input
              type="text"
              value={vehicleNo}
              onChange={(e) => setVehicleNo(e.target.value)}
              placeholder="e.g. Bogura-Ta-11-8902"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Driver Name
            </label>
            <input
              type="text"
              value={driverName}
              onChange={(e) => setDriverName(e.target.value)}
              placeholder="e.g. Kamal Uddin"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Driver Phone
            </label>
            <input
              type="text"
              value={driverPhone}
              onChange={(e) => setDriverPhone(e.target.value)}
              placeholder="+880 1819-XXXXXX"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
        </div>

        {/* Remarks */}
        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Dispatch Remarks & Gate Notes
          </label>
          <input
            type="text"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="e.g. Inspected at Cold Storage Gate 1, all seals verified"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        {/* Modal Actions */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium rounded-xl text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold rounded-xl text-white bg-amber-600 hover:bg-amber-700 shadow-xs transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{editDelivery ? 'Update Gate Pass' : 'Issue Gate Pass & Dispatch'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
