import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { StockTransaction } from '../../types';
import {
  Boxes,
  Calendar,
  Warehouse,
  Sprout,
  Save,
  CheckCircle2,
  FileText,
  Weight,
} from 'lucide-react';
import { stockTransactionSchema } from '../../utils/validationSchemas';

interface StockTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  editTransaction?: StockTransaction | null;
}

export const StockTransactionModal: React.FC<StockTransactionModalProps> = ({
  isOpen,
  onClose,
  editTransaction,
}) => {
  const {
    coldStorages,
    varieties,
    seedClasses,
    grades,
    productionBlocks,
    potatoTypes,
    addStockTransaction,
    updateStockTransaction,
    addToast,
  } = useApp();

  // Form fields
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [kblChallanNo, setKblChallanNo] = useState('');
  const [srNo, setSrNo] = useState('');
  const [coldStorageId, setColdStorageId] = useState(coldStorages[0]?.id || '');
  const [varietyId, setVarietyId] = useState(varieties[0]?.id || '');
  const [classId, setClassId] = useState(seedClasses[0]?.id || '');
  const [gradeId, setGradeId] = useState(grades[0]?.id || '');
  const [blockId, setBlockId] = useState(productionBlocks[0]?.id || '');
  const [typeId, setTypeId] = useState(potatoTypes[0]?.id || '');
  const [sackQuantity, setSackQuantity] = useState<number>(100);
  const [kgPerBag, setKgPerBag] = useState<number>(50);
  const [truckNo, setTruckNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverContact, setDriverContact] = useState('');
  const [growerFarmerName, setGrowerFarmerName] = useState('');
  const [remarks, setRemarks] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editTransaction) {
      setDate(editTransaction.date);
      setKblChallanNo(editTransaction.kblChallanNo);
      setSrNo(editTransaction.srNo);
      setColdStorageId(editTransaction.coldStorageId);
      setVarietyId(editTransaction.varietyId);
      setClassId(editTransaction.classId);
      setGradeId(editTransaction.gradeId);
      setBlockId(editTransaction.blockId || editTransaction.productionBlockId || productionBlocks[0]?.id || '');
      setTypeId(editTransaction.typeId || editTransaction.potatoTypeId || potatoTypes[0]?.id || '');
      setSackQuantity(editTransaction.sackQuantity);
      setKgPerBag(editTransaction.kgPerBag);
      setTruckNo(editTransaction.truckNo || '');
      setDriverName(editTransaction.driverName || '');
      setDriverContact(editTransaction.driverContact || '');
      setGrowerFarmerName(editTransaction.growerFarmerName || '');
      setRemarks(editTransaction.remarks || '');
    } else {
      setDate(new Date().toISOString().split('T')[0]);
      setKblChallanNo(`KBL-CH-${Math.floor(Math.random() * 900 + 100)}`);
      setSrNo(`SR-${Math.floor(Math.random() * 90 + 10)}`);
      setColdStorageId(coldStorages[0]?.id || '');
      setVarietyId(varieties[0]?.id || '');
      setClassId(seedClasses[0]?.id || '');
      setGradeId(grades[0]?.id || '');
      setBlockId(productionBlocks[0]?.id || '');
      setTypeId(potatoTypes[0]?.id || '');
      setSackQuantity(100);
      setKgPerBag(50);
      setTruckNo('');
      setDriverName('');
      setDriverContact('');
      setGrowerFarmerName('');
      setRemarks('');
    }
    setErrors({});
  }, [editTransaction, isOpen, coldStorages, varieties, seedClasses, grades, productionBlocks, potatoTypes]);

  const totalKg = sackQuantity * kgPerBag;
  const totalMt = totalKg / 1000;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      date,
      kblChallanNo: kblChallanNo.trim(),
      srNo: srNo.trim(),
      coldStorageId,
      varietyId,
      classId,
      gradeId,
      productionBlockId: blockId,
      blockId,
      potatoTypeId: typeId,
      typeId,
      sackQuantity: Number(sackQuantity),
      kgPerBag: Number(kgPerBag),
      totalKg,
      totalMt,
      truckNo: truckNo.trim() || undefined,
      driverName: driverName.trim() || undefined,
      driverContact: driverContact.trim() || undefined,
      growerFarmerName: growerFarmerName.trim() || undefined,
      status: 'approved' as const,
      remarks: remarks.trim() || undefined,
    };

    // Zod validation
    const result = stockTransactionSchema.safeParse(payload);
    if (!result.success) {
      const errMap: Record<string, string> = {};
      result.error.issues.forEach((err: any) => {
        if (err.path[0]) {
          errMap[err.path[0].toString()] = err.message;
        }
      });
      setErrors(errMap);
      return;
    }

    if (editTransaction) {
      updateStockTransaction(editTransaction.id, payload);
      if (addToast) addToast(`Updated Challan ${payload.kblChallanNo}`, 'success');
    } else {
      addStockTransaction(payload);
      if (addToast) addToast(`Registered Inbound Stock Challan ${payload.kblChallanNo}`, 'success');
    }

    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editTransaction ? 'Edit Cold Storage Stock Lot' : 'Potato Send to Cold Storage Entry'}
      subtitle="Register inbound potato seed stock receipt, KBL challan, and cold storage allotment"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {/* Row 1: Date & Challans */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Receipt Date <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              />
            </div>
            {errors.date && <p className="text-rose-500 text-[10px] mt-0.5">{errors.date}</p>}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              KBL Challan No <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <FileText className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={kblChallanNo}
                onChange={(e) => setKblChallanNo(e.target.value)}
                placeholder="e.g. KBL-CH-101"
                required
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-mono font-semibold"
              />
            </div>
            {errors.kblChallanNo && (
              <p className="text-rose-500 text-[10px] mt-0.5">{errors.kblChallanNo}</p>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              SR No (Serial Receipt) <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={srNo}
              onChange={(e) => setSrNo(e.target.value)}
              placeholder="e.g. SR-01"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-mono font-semibold"
            />
            {errors.srNo && <p className="text-rose-500 text-[10px] mt-0.5">{errors.srNo}</p>}
          </div>
        </div>

        {/* Row 2: Facility & Seed Classification */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Target Cold Storage Facility <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Warehouse className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <select
                value={coldStorageId}
                onChange={(e) => setColdStorageId(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                {coldStorages.map((cs) => (
                  <option key={cs.id} value={cs.id}>
                    {cs.name} ({cs.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Potato Variety <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Sprout className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <select
                value={varietyId}
                onChange={(e) => setVarietyId(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                {varieties.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} ({v.type})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Row 3: Class, Grade, Production Block */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Seed Class <span className="text-rose-500">*</span>
            </label>
            <select
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
            >
              {seedClasses.map((sc) => (
                <option key={sc.id} value={sc.id}>
                  {sc.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Size Grade <span className="text-rose-500">*</span>
            </label>
            <select
              value={gradeId}
              onChange={(e) => setGradeId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
            >
              {grades.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name} ({g.sizeRange})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Production Block
            </label>
            <select
              value={blockId}
              onChange={(e) => setBlockId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500 font-medium"
            >
              {productionBlocks.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Row 4: Bags & Weight Metrics with Live Auto-computation */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-3">
            <Weight className="w-4 h-4 text-sky-600 dark:text-sky-400" />
            <h4 className="font-bold text-slate-900 dark:text-white">
              Weight & Quantity Parameters
            </h4>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block font-semibold text-slate-600 dark:text-slate-400 text-[11px] mb-1">
                Sack Quantity (Bags) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                value={sackQuantity}
                onChange={(e) => setSackQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                required
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-600 dark:text-slate-400 text-[11px] mb-1">
                KG per Bag <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                step="0.5"
                value={kgPerBag}
                onChange={(e) => setKgPerBag(Math.max(1, parseFloat(e.target.value) || 0))}
                required
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Total Net Weight</span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {totalKg.toLocaleString()} KG
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Metric Tons</span>
              <span className="text-sm font-bold text-sky-600 dark:text-sky-400 mt-0.5">
                {totalMt.toFixed(2)} MT
              </span>
            </div>
          </div>
        </div>

        {/* Row 5: Logistics & Farm Origin */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Truck / Transport No
            </label>
            <input
              type="text"
              value={truckNo}
              onChange={(e) => setTruckNo(e.target.value)}
              placeholder="e.g. Dhaka Metro-Ta-11-2034"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Driver Name & Contact
            </label>
            <input
              type="text"
              value={driverName}
              onChange={(e) => setDriverName(e.target.value)}
              placeholder="e.g. Rafiqul Islam (+88017...)"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Grower / Farmer Name
            </label>
            <input
              type="text"
              value={growerFarmerName}
              onChange={(e) => setGrowerFarmerName(e.target.value)}
              placeholder="e.g. Dinajpur Agro Farm #4"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
        </div>

        {/* Remarks */}
        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Challan Remarks & Gate Pass Notes
          </label>
          <input
            type="text"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="e.g. Received in good condition, unloaded at Chamber 2"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        {/* Form Actions */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium rounded-xl text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold rounded-xl text-white bg-sky-600 hover:bg-sky-700 shadow-xs transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{editTransaction ? 'Update Stock Entry' : 'Save & Post to Cold Storage'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
