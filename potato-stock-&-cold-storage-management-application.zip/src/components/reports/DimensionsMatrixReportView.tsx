import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { calculateStockBalanceMatrix } from '../../utils/stockEngine';
import {
  Grid3X3,
  FileSpreadsheet,
  Printer,
  Search,
  Eye,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { PrintPreviewModal } from '../common/PrintPreviewModal';

export const DimensionsMatrixReportView: React.FC = () => {
  const {
    stockTransactions,
    deliveryTransactions,
    coldStorages,
    varieties,
    seedClasses,
    grades,
    companySettings,
    addToast,
  } = useApp();

  const [dimensionFilter, setDimensionFilter] = useState<'variety' | 'class' | 'grade'>('variety');
  const [searchTerm, setSearchTerm] = useState('');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const [sortKey, setSortKey] = useState<string>('coldStorageName');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  const matrix = useMemo(() => {
    return calculateStockBalanceMatrix(
      stockTransactions,
      deliveryTransactions,
      coldStorages,
      varieties,
      seedClasses,
      grades
    ).map((item, idx) => ({
      ...item,
      id: `${item.coldStorageId}-${item.varietyId}-${item.classId}-${item.gradeId}-${idx}`,
    }));
  }, [stockTransactions, deliveryTransactions, coldStorages, varieties, seedClasses, grades]);

  const filteredMatrix = useMemo(() => {
    return matrix.filter((item) => {
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const match =
          item.coldStorageName.toLowerCase().includes(q) ||
          item.varietyName.toLowerCase().includes(q) ||
          item.className.toLowerCase().includes(q) ||
          item.gradeName.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [matrix, searchTerm]);

  const sortedMatrix = useMemo(() => {
    return sortData(filteredMatrix, sortKey, sortDir);
  }, [filteredMatrix, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sortedMatrix.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedMatrix = sortedMatrix.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const totalInboundBags = filteredMatrix.reduce((acc, i) => acc + i.inboundBags, 0);
  const totalInboundMt = filteredMatrix.reduce((acc, i) => acc + i.inboundMt, 0);
  const totalDeliveredBags = filteredMatrix.reduce((acc, i) => acc + i.deliveredBags, 0);
  const totalDeliveredMt = filteredMatrix.reduce((acc, i) => acc + i.deliveredMt, 0);
  const totalBalanceBags = filteredMatrix.reduce((acc, i) => acc + i.balanceBags, 0);
  const totalBalanceMt = filteredMatrix.reduce((acc, i) => acc + i.balanceMt, 0);

  const exportColumns = [
    { header: 'Cold Storage Facility', key: 'coldStorageName', width: 28 },
    { header: 'Potato Variety', key: 'varietyName', width: 18 },
    { header: 'Seed Class', key: 'className', width: 16 },
    { header: 'Grade', key: 'gradeName', width: 18 },
    { header: 'Inbound Bags', key: 'inboundBags', width: 14 },
    { header: 'Inbound MT', key: 'inboundMt', width: 14 },
    { header: 'Dispatched Bags', key: 'deliveredBags', width: 14 },
    { header: 'Dispatched MT', key: 'deliveredMt', width: 14 },
    { header: 'Vault Balance (Bags)', key: 'balanceBags', width: 16 },
    { header: 'Vault Balance (MT)', key: 'balanceMt', width: 16 },
  ];

  const handleExcel = () => {
    exportToExcel(
      filteredMatrix,
      exportColumns,
      'MultiDimensional_Matrix_Report_2024',
      'Multi-Dimensional Potato Seed Stock Matrix Report',
      companySettings,
      `Dimension: ${dimensionFilter.toUpperCase()} | Total Rows: ${filteredMatrix.length}`
    );
  };

  const handlePrint = () => {
    if (filteredMatrix.length === 0) {
      if (addToast) addToast('Dimensions matrix dataset has no matching entries.', 'error');
      return;
    }

    const printData = filteredMatrix.map((item) => ({
      coldStorageName: item.coldStorageName,
      varietyName: item.varietyName,
      className: item.className,
      gradeName: item.gradeName,
      inboundBags: item.inboundBags.toLocaleString(),
      inboundMt: item.inboundMt.toFixed(2),
      deliveredBags: item.deliveredBags.toLocaleString(),
      deliveredMt: item.deliveredMt.toFixed(2),
      balanceBags: item.balanceBags.toLocaleString(),
      balanceMt: item.balanceMt.toFixed(2),
    }));

    validateAndTriggerPrint({
      data: printData,
      reportTitle: 'MULTI-DIMENSIONAL POTATO SEED STOCK MATRIX REPORT',
      companySettings,
      expectedMinRecords: 1,
      columns: [
        { header: 'Cold Storage', key: 'coldStorageName' },
        { header: 'Variety', key: 'varietyName' },
        { header: 'Seed Class', key: 'className' },
        { header: 'Grade', key: 'gradeName' },
        { header: 'Inbound Bags', key: 'inboundBags', align: 'right' },
        { header: 'Inbound MT', key: 'inboundMt', align: 'right' },
        { header: 'Dispatched Bags', key: 'deliveredBags', align: 'right' },
        { header: 'Dispatched MT', key: 'deliveredMt', align: 'right' },
        { header: 'Balance Bags', key: 'balanceBags', align: 'right' },
        { header: 'Balance MT', key: 'balanceMt', align: 'right' },
      ],
      databaseCheck: () => ({ isConsistent: true }),
      onError: (msg) => {
        if (addToast) addToast(msg, 'error');
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <Grid3X3 className="w-6 h-6 text-sky-600 dark:text-sky-400" />
            MULTI-DIMENSIONAL STOCK MATRIX REPORT
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            4-DIMENSIONAL CROSS TABULATION: STORAGE FACILITY × VARIETY × SEED CLASS × SIZE GRADE
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => setIsPreviewOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Eye className="w-4 h-4 text-sky-500" />
            <span>DOCUMENT PREVIEW</span>
          </button>

          <button
            onClick={handleExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXPORT EXCEL</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Control Strip */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs no-print">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search across any dimension..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 uppercase">PIVOT VIEW:</span>
          <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-0.5">
            <button
              onClick={() => setDimensionFilter('variety')}
              className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer uppercase ${
                dimensionFilter === 'variety'
                  ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              BY VARIETY
            </button>
            <button
              onClick={() => setDimensionFilter('class')}
              className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer uppercase ${
                dimensionFilter === 'class'
                  ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              BY SEED CLASS
            </button>
            <button
              onClick={() => setDimensionFilter('grade')}
              className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer uppercase ${
                dimensionFilter === 'grade'
                  ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              BY SIZE GRADE
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            MATRIX RECORDS
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {filteredMatrix.length} Rows
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL INBOUND
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalInboundBags.toLocaleString()} Bags
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL DISPATCHED
          </span>
          <span className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-0.5 block font-mono">
            {totalDeliveredBags.toLocaleString()} Bags
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            VAULT NET BALANCE
          </span>
          <span className="text-xl font-bold text-sky-600 dark:text-sky-400 mt-0.5 block font-mono">
            {totalBalanceBags.toLocaleString()} Bags ({totalBalanceMt.toFixed(2)} MT)
          </span>
        </div>
      </div>

      {/* Cross Tabulation Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="COLD STORAGE" sortKey="coldStorageName" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="VARIETY" sortKey="varietyName" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLASS" sortKey="className" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="GRADE" sortKey="gradeName" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="INBOUND (BAGS)" sortKey="inboundBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="INBOUND (MT)" sortKey="inboundMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="DISPATCHED (BAGS)" sortKey="deliveredBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="DISPATCHED (MT)" sortKey="deliveredMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="BALANCE (BAGS)" sortKey="balanceBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="BALANCE (MT)" sortKey="balanceMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedMatrix.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-400 italic">
                    No matrix records found matching search filters.
                  </td>
                </tr>
              ) : (
                paginatedMatrix.map((item) => (
                  <tr
                    key={item.id}
                    className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {item.coldStorageName}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                      {item.varietyName}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {item.className}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{item.gradeName}</td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-700 dark:text-slate-300 font-mono">
                      {item.inboundBags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-500 font-mono">
                      {item.inboundMt.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-amber-600 dark:text-amber-400 font-mono">
                      {item.deliveredBags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-500 font-mono">
                      {item.deliveredMt.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-sky-600 dark:text-sky-400 font-mono bg-sky-50/30 dark:bg-sky-950/10">
                      {item.balanceBags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400 font-mono bg-sky-50/30 dark:bg-sky-950/10">
                      {item.balanceMt.toFixed(2)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {filteredMatrix.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                  <td colSpan={4} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                    TOTAL MATRIX BALANCE:
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    {totalInboundBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-500">
                    {totalInboundMt.toFixed(2)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-600 dark:text-amber-400">
                    {totalDeliveredBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-500">
                    {totalDeliveredMt.toFixed(2)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sky-600 dark:text-sky-400 bg-sky-100/50 dark:bg-sky-900/30 text-sm">
                    {totalBalanceBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400 bg-sky-100/50 dark:bg-sky-900/30 text-sm">
                    {totalBalanceMt.toFixed(2)} MT
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Pagination */}
        {sortedMatrix.length > 0 && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedMatrix.length}
            pageSizeOptions={[10, 15, 25, 50, 100]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>

      {/* Print Preview Modal */}
      {isPreviewOpen && (
        <PrintPreviewModal
          isOpen={isPreviewOpen}
          onClose={() => setIsPreviewOpen(false)}
          documentTitle="Multi-Dimensional Potato Seed Stock Matrix Report"
          subtitle={`Total Combinations: ${filteredMatrix.length} | Generated: ${new Date().toLocaleDateString()}`}
          columns={exportColumns}
          data={filteredMatrix}
          summaryItems={[
            { label: 'Total Combinations', value: filteredMatrix.length },
            { label: 'Inbound Sacks', value: totalInboundBags.toLocaleString() },
            { label: 'Dispatched Sacks', value: totalDeliveredBags.toLocaleString() },
            { label: 'Vault Balance Sacks', value: totalBalanceBags.toLocaleString() },
            { label: 'Vault Balance MT', value: `${totalBalanceMt.toFixed(2)} MT` },
          ]}
          filename="Dimensions_Matrix_Report_2024"
        />
      )}
    </div>
  );
};
