import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BarChart3,
  FileSpreadsheet,
  Printer,
  Calendar,
  Warehouse,
  Sprout,
  Eye,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { PrintPreviewModal } from '../common/PrintPreviewModal';

export const StockReportView: React.FC = () => {
  const {
    stockTransactions,
    coldStorages,
    varieties,
    seedClasses,
    grades,
    companySettings,
    addToast,
  } = useApp();

  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState('2024-12-31');
  const [selectedStorage, setSelectedStorage] = useState('');
  const [selectedVariety, setSelectedVariety] = useState('');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const [sortKey, setSortKey] = useState<string>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Filtered dataset
  const filteredData = useMemo(() => {
    return stockTransactions.filter((s) => {
      if (s.date < startDate || s.date > endDate) return false;
      if (selectedStorage && s.coldStorageId !== selectedStorage) return false;
      if (selectedVariety && s.varietyId !== selectedVariety) return false;
      return true;
    });
  }, [stockTransactions, startDate, endDate, selectedStorage, selectedVariety]);

  const totalBags = filteredData.reduce((acc, s) => acc + s.sackQuantity, 0);
  const totalKg = filteredData.reduce((acc, s) => acc + s.totalKg, 0);
  const totalMt = filteredData.reduce((acc, s) => acc + s.totalMt, 0);
  const avgKgPerBag = totalBags > 0 ? (totalKg / totalBags).toFixed(1) : '-';

  const formattedRows = useMemo(() => {
    return filteredData.map((s) => {
      const storage = coldStorages.find((c) => c.id === s.coldStorageId)?.name || s.coldStorageId;
      const variety = varieties.find((v) => v.id === s.varietyId)?.name || s.varietyId;
      const seedClass = seedClasses.find((c) => c.id === s.classId)?.name || s.classId;
      const grade = grades.find((g) => g.id === s.gradeId)?.name || s.gradeId;

      return {
        id: s.id,
        date: s.date,
        challan: s.kblChallanNo,
        sr: s.srNo,
        storage,
        variety,
        class: seedClass,
        grade,
        bags: s.sackQuantity,
        kgPerBag: s.kgPerBag,
        totalKg: s.totalKg,
        totalMt: s.totalMt,
        truckNo: s.truckNo || '-',
        driver: s.driverName || '-',
        grower: s.growerFarmerName || '-',
      };
    });
  }, [filteredData, coldStorages, varieties, seedClasses, grades]);

  const sortedRows = useMemo(() => {
    return sortData(formattedRows, sortKey, sortDir);
  }, [formattedRows, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sortedRows.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedRows = sortedRows.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const exportColumns = [
    { header: 'Date', key: 'date', width: 12 },
    { header: 'KBL Challan No', key: 'challan', width: 16 },
    { header: 'SR No', key: 'sr', width: 12 },
    { header: 'Cold Storage', key: 'storage', width: 26 },
    { header: 'Variety', key: 'variety', width: 16 },
    { header: 'Class', key: 'class', width: 14 },
    { header: 'Grade', key: 'grade', width: 18 },
    { header: 'Bags', key: 'bags', width: 12 },
    { header: 'KG/Bag', key: 'kgPerBag', width: 10 },
    { header: 'Total KG', key: 'totalKg', width: 14 },
    { header: 'Total MT', key: 'totalMt', width: 14 },
    { header: 'Truck No', key: 'truckNo', width: 16 },
    { header: 'Driver', key: 'driver', width: 16 },
    { header: 'Grower/Farmer', key: 'grower', width: 20 },
  ];

  const handleExcel = () => {
    exportToExcel(
      formattedRows,
      exportColumns,
      'Official_Stock_Inbound_Report_2024',
      'Potato Seed Inbound Stock Report',
      companySettings,
      `Date Range: ${startDate} to ${endDate}`
    );
  };

  const handlePrint = () => {
    if (formattedRows.length === 0) {
      if (addToast) addToast('Stock report contains no matching records.', 'error');
      return;
    }

    const printData = formattedRows.map((r) => ({
      date: r.date,
      challan: r.challan,
      sr: r.sr,
      storage: r.storage,
      variety: r.variety,
      classGrade: `${r.class} / ${r.grade}`,
      bags: r.bags.toLocaleString(),
      kgPerBag: r.kgPerBag,
      totalKg: r.totalKg.toLocaleString(),
      totalMt: r.totalMt.toFixed(2),
      logistics: r.truckNo,
    }));

    validateAndTriggerPrint({
      data: printData,
      reportTitle: 'POTATO SEED INBOUND STOCK REPORT',
      companySettings,
      expectedMinRecords: 1,
      columns: [
        { header: 'Date', key: 'date' },
        { header: 'Challan No', key: 'challan' },
        { header: 'SR No', key: 'sr' },
        { header: 'Cold Storage', key: 'storage' },
        { header: 'Variety', key: 'variety' },
        { header: 'Class / Grade', key: 'classGrade' },
        { header: 'Bags', key: 'bags', align: 'right' },
        { header: 'KG/Bag', key: 'kgPerBag', align: 'right' },
        { header: 'Total KG', key: 'totalKg', align: 'right' },
        { header: 'Total MT', key: 'totalMt', align: 'right' },
        { header: 'Logistics', key: 'logistics' },
      ],
      databaseCheck: () => ({ isConsistent: true }),
      onError: (msg) => {
        if (addToast) addToast(msg, 'error');
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <BarChart3 className="w-6 h-6 text-sky-600 dark:text-sky-400" />
            POTATO SEED STOCK INBOUND REPORT (EXCEL FORMAT)
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            COMPLETE RECONCILIATION OF ALL INCOMING SEED STOCK LOTS, LOT CERTIFICATES, AND GATE AUDIT METRICS
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => setIsPreviewOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Eye className="w-4 h-4 text-sky-500" />
            <span>DOCUMENT PREVIEW</span>
          </button>

          <button
            onClick={handleExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXPORT EXCEL</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Filter Ribbon */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs no-print">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              End Date
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Cold Storage
            </label>
            <select
              value={selectedStorage}
              onChange={(e) => {
                setSelectedStorage(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            >
              <option value="">All Facilities</option>
              {coldStorages.map((cs) => (
                <option key={cs.id} value={cs.id}>
                  {cs.name} ({cs.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Potato Variety
            </label>
            <select
              value={selectedVariety}
              onChange={(e) => {
                setSelectedVariety(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
            >
              <option value="">All Varieties</option>
              {varieties.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            MATCHING LOTS
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {filteredData.length} Lots
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL SACKS / BAGS
          </span>
          <span className="text-xl font-bold text-sky-600 dark:text-sky-400 mt-0.5 block font-mono">
            {totalBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL NET KG
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalKg.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL METRIC TONS (MT)
          </span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block font-mono">
            {totalMt.toFixed(2)} MT
          </span>
        </div>
      </div>

      {/* Table Data */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="DATE" sortKey="date" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="KBL CHALLAN NO" sortKey="challan" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="SR NO" sortKey="sr" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="COLD STORAGE" sortKey="storage" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="VARIETY" sortKey="variety" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLASS" sortKey="class" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="GRADE" sortKey="grade" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="BAGS" sortKey="bags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="KG/BAG" sortKey="kgPerBag" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL KG" sortKey="totalKg" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL MT" sortKey="totalMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="LOGISTICS" sortKey="truckNo" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedRows.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-8 text-center text-slate-400 italic">
                    No inbound records found matching the specified report filters.
                  </td>
                </tr>
              ) : (
                paginatedRows.map((row) => (
                  <tr
                    key={row.id}
                    className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {row.date}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-sky-600 dark:text-sky-400">
                      {row.challan}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-800 dark:text-slate-200">
                      {row.sr}
                    </td>
                    <td className="py-2.5 px-3 text-slate-800 dark:text-slate-200 font-semibold">
                      {row.storage}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                      {row.variety}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {row.class}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{row.grade}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-900 dark:text-white font-mono">
                      {row.bags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-500 font-mono">{row.kgPerBag}</td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-800 dark:text-slate-200 font-mono">
                      {row.totalKg.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-sky-600 dark:text-sky-400 font-mono">
                      {row.totalMt.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-[11px] text-slate-500 dark:text-slate-400">
                      {row.truckNo}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {formattedRows.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                  <td colSpan={7} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                    TOTAL INBOUND:
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sky-600 dark:text-sky-400">
                    {totalBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-[11px] text-slate-500">
                    {avgKgPerBag}
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    {totalKg.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400">
                    {totalMt.toFixed(2)} MT
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Pagination */}
        {sortedRows.length > 0 && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedRows.length}
            pageSizeOptions={[10, 15, 25, 50, 100]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>

      {/* Document Print Preview Modal */}
      {isPreviewOpen && (
        <PrintPreviewModal
          isOpen={isPreviewOpen}
          onClose={() => setIsPreviewOpen(false)}
          documentTitle="Potato Seed Inbound Stock Report (Excel Register)"
          subtitle={`Report Period: ${startDate} to ${endDate} | Total Lots: ${formattedRows.length}`}
          columns={exportColumns}
          data={formattedRows}
          summaryItems={[
            { label: 'Total Inbound Lots', value: formattedRows.length },
            { label: 'Total Sacks / Bags', value: totalBags.toLocaleString() },
            { label: 'Net Weight (KG)', value: totalKg.toLocaleString() },
            { label: 'Net Metric Tons', value: `${totalMt.toFixed(2)} MT` },
          ]}
          filename="Stock_Inbound_Report_2024"
        />
      )}
    </div>
  );
};
