import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Warehouse,
  FileSpreadsheet,
  Printer,
  Eye,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { PrintPreviewModal } from '../common/PrintPreviewModal';

export const ColdStorageReportView: React.FC = () => {
  const {
    coldStorages,
    stockTransactions,
    deliveryTransactions,
    companySettings,
    addToast,
  } = useApp();

  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [sortKey, setSortKey] = useState<string>('name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Compute facility utilization summaries
  const facilityReports = useMemo(() => {
    return coldStorages.map((cs) => {
      const inboundList = stockTransactions.filter((s) => s.coldStorageId === cs.id);
      const deliveryList = deliveryTransactions.filter((d) => d.coldStorageId === cs.id);

      const inboundBags = inboundList.reduce((acc, s) => acc + s.sackQuantity, 0);
      const inboundKg = inboundList.reduce((acc, s) => acc + s.totalKg, 0);
      const inboundMt = inboundList.reduce((acc, s) => acc + s.totalMt, 0);

      const deliveredBags = deliveryList.reduce((acc, d) => acc + d.sackQuantity, 0);
      const deliveredKg = deliveryList.reduce((acc, d) => acc + d.totalKg, 0);
      const deliveredMt = deliveryList.reduce((acc, d) => acc + d.totalMt, 0);

      const balanceBags = Math.max(0, inboundBags - deliveredBags);
      const balanceKg = Math.max(0, inboundKg - deliveredKg);
      const balanceMt = Math.max(0, inboundMt - deliveredMt);

      const occupancyRate = cs.capacity > 0 ? (balanceBags / cs.capacity) * 100 : 0;
      const estimatedRent = balanceBags * cs.rentPerBag;

      return {
        id: cs.id,
        name: cs.name,
        code: cs.code,
        location: cs.location,
        capacity: cs.capacity,
        rentPerBag: cs.rentPerBag,
        inboundBags,
        inboundMt,
        deliveredBags,
        deliveredMt,
        balanceBags,
        balanceKg,
        balanceMt,
        occupancyRate,
        estimatedRent,
      };
    });
  }, [coldStorages, stockTransactions, deliveryTransactions]);

  const sortedReports = useMemo(() => {
    return sortData(facilityReports, sortKey, sortDir);
  }, [facilityReports, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sortedReports.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedReports = sortedReports.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const totalCap = facilityReports.reduce((acc, f) => acc + f.capacity, 0);
  const totalIn = facilityReports.reduce((acc, f) => acc + f.inboundBags, 0);
  const totalOut = facilityReports.reduce((acc, f) => acc + f.deliveredBags, 0);
  const totalVault = facilityReports.reduce((acc, f) => acc + f.balanceBags, 0);
  const totalVaultMt = facilityReports.reduce((acc, f) => acc + f.balanceMt, 0);
  const totalEstRent = facilityReports.reduce((acc, f) => acc + f.estimatedRent, 0);
  const overallOccupancy = totalCap > 0 ? (totalVault / totalCap) * 100 : 0;

  const exportColumns = [
    { header: 'Cold Storage Facility', key: 'name', width: 28 },
    { header: 'Code', key: 'code', width: 12 },
    { header: 'Location', key: 'location', width: 22 },
    { header: 'Capacity (Bags)', key: 'capacity', width: 16 },
    { header: 'Rent Rate (৳/Bag)', key: 'rentPerBag', width: 18 },
    { header: 'Inbound (Bags)', key: 'inboundBags', width: 16 },
    { header: 'Delivered (Bags)', key: 'deliveredBags', width: 16 },
    { header: 'Current Vault Stock', key: 'balanceBags', width: 18 },
    { header: 'Vault Weight (MT)', key: 'balanceMt', width: 18 },
    { header: 'Occupancy Rate (%)', key: 'occupancyRate', width: 18 },
    { header: 'Est. Season Rent (৳)', key: 'estimatedRent', width: 20 },
  ];

  const handleExcel = () => {
    const data = facilityReports.map((f) => ({
      ...f,
      balanceMt: Number(f.balanceMt.toFixed(2)),
      occupancyRate: `${f.occupancyRate.toFixed(1)}%`,
      estimatedRent: Math.round(f.estimatedRent),
    }));

    exportToExcel(
      data,
      exportColumns,
      'Facility_Capacity_Utilization_Report_2024',
      'Cold Storage Facilities Utilization & Stock Distribution Report',
      companySettings,
      `Enterprise Facilities: ${facilityReports.length} | Overall Occupancy: ${overallOccupancy.toFixed(1)}%`
    );
  };

  const handlePrint = () => {
    if (facilityReports.length === 0) {
      if (addToast) addToast('Facility report dataset has no cold storage records.', 'error');
      return;
    }

    const printData = facilityReports.map((f) => ({
      name: `${f.name} (${f.code})`,
      location: f.location,
      capacity: f.capacity.toLocaleString(),
      rentPerBag: `৳${f.rentPerBag}`,
      inboundBags: f.inboundBags.toLocaleString(),
      deliveredBags: f.deliveredBags.toLocaleString(),
      balanceBags: f.balanceBags.toLocaleString(),
      balanceMt: `${f.balanceMt.toFixed(2)} MT`,
      occupancy: `${f.occupancyRate.toFixed(1)}%`,
      rent: `৳${Math.round(f.estimatedRent).toLocaleString()}`,
    }));

    validateAndTriggerPrint({
      data: printData,
      reportTitle: 'COLD STORAGE FACILITIES UTILIZATION & STOCK DISTRIBUTION REPORT',
      companySettings,
      expectedMinRecords: 1,
      columns: [
        { header: 'Facility (Code)', key: 'name' },
        { header: 'Location', key: 'location' },
        { header: 'Capacity', key: 'capacity', align: 'right' },
        { header: 'Rate/Bag', key: 'rentPerBag', align: 'right' },
        { header: 'Inbound', key: 'inboundBags', align: 'right' },
        { header: 'Delivered', key: 'deliveredBags', align: 'right' },
        { header: 'Stock Bags', key: 'balanceBags', align: 'right' },
        { header: 'Stock MT', key: 'balanceMt', align: 'right' },
        { header: 'Occupancy', key: 'occupancy', align: 'right' },
        { header: 'Est. Rent', key: 'rent', align: 'right' },
      ],
      databaseCheck: () => ({ isConsistent: true }),
      onError: (msg) => {
        if (addToast) addToast(msg, 'error');
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <Warehouse className="w-6 h-6 text-sky-600 dark:text-sky-400" />
            COLD STORAGE FACILITY UTILIZATION & SUMMARY REPORT
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            CONTRACTED COLD STORAGE CAPACITIES, INVENTORY DISTRIBUTION, OCCUPANCY % AND RENT PROJECTIONS
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => setIsPreviewOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Eye className="w-4 h-4 text-sky-500" />
            <span>DOCUMENT PREVIEW</span>
          </button>

          <button
            onClick={handleExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXPORT EXCEL</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL CONTRACT CAPACITY
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalCap.toLocaleString()} Bags
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            VAULT REMAINING STOCK
          </span>
          <span className="text-xl font-bold text-sky-600 dark:text-sky-400 mt-0.5 block font-mono">
            {totalVault.toLocaleString()} Bags
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            OCCUPANCY RATE
          </span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block font-mono">
            {overallOccupancy.toFixed(1)}%
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            PROJECTED TOTAL RENT
          </span>
          <span className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-0.5 block font-mono">
            ৳{Math.round(totalEstRent).toLocaleString()}
          </span>
        </div>
      </div>

      {/* Facility Utilization Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="COLD STORAGE FACILITY" sortKey="name" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="LOCATION" sortKey="location" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CAPACITY (BAGS)" sortKey="capacity" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="RENT RATE" sortKey="rentPerBag" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="INBOUND BAGS" sortKey="inboundBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="DISPATCHED BAGS" sortKey="deliveredBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="CURRENT STOCK" sortKey="balanceBags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="STOCK (MT)" sortKey="balanceMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="OCCUPANCY BAR" sortKey="occupancyRate" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="center" />
                <SortableHeader label="EST. RENT" sortKey="estimatedRent" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedReports.map((f) => (
                <tr
                  key={f.id}
                  className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                >
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-slate-900 dark:text-white">{f.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{f.code}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{f.location}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-700 dark:text-slate-300">
                    {f.capacity.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-500">
                    ৳{f.rentPerBag}/bag
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-700 dark:text-slate-300">
                    {f.inboundBags.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-amber-600 dark:text-amber-400">
                    {f.deliveredBags.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-sky-600 dark:text-sky-400 bg-sky-50/30 dark:bg-sky-950/10">
                    {f.balanceBags.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 bg-sky-50/30 dark:bg-sky-950/10">
                    {f.balanceMt.toFixed(2)} MT
                  </td>
                  <td className="py-2.5 px-3 text-center min-w-[120px]">
                    <div className="flex items-center gap-2">
                      <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            f.occupancyRate > 90
                              ? 'bg-rose-500'
                              : f.occupancyRate > 70
                              ? 'bg-amber-500'
                              : 'bg-emerald-500'
                          }`}
                          style={{ width: `${Math.min(100, f.occupancyRate)}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-mono font-bold text-slate-700 dark:text-slate-300 w-10 text-right">
                        {f.occupancyRate.toFixed(0)}%
                      </span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                    ৳{Math.round(f.estimatedRent).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                <td colSpan={2} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                  ENTERPRISE TOTAL:
                </td>
                <td className="py-3 px-3 text-right font-mono">
                  {totalCap.toLocaleString()}
                </td>
                <td></td>
                <td className="py-3 px-3 text-right font-mono">
                  {totalIn.toLocaleString()}
                </td>
                <td className="py-3 px-3 text-right font-mono text-amber-600 dark:text-amber-400">
                  {totalOut.toLocaleString()}
                </td>
                <td className="py-3 px-3 text-right font-mono text-sky-600 dark:text-sky-400 bg-sky-100/50 dark:bg-sky-900/30 text-sm">
                  {totalVault.toLocaleString()}
                </td>
                <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400 bg-sky-100/50 dark:bg-sky-900/30 text-sm">
                  {totalVaultMt.toFixed(2)} MT
                </td>
                <td className="py-3 px-3 text-center font-mono text-emerald-600 dark:text-emerald-400">
                  {overallOccupancy.toFixed(1)}% Avg
                </td>
                <td className="py-3 px-3 text-right font-mono text-amber-600 dark:text-amber-400 text-sm">
                  ৳{Math.round(totalEstRent).toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Pagination */}
        {sortedReports.length > pageSize && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedReports.length}
            pageSizeOptions={[10, 15, 25, 50]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>

      {/* Print Preview Modal */}
      {isPreviewOpen && (
        <PrintPreviewModal
          isOpen={isPreviewOpen}
          onClose={() => setIsPreviewOpen(false)}
          documentTitle="Cold Storage Facility Utilization & Summary Report"
          subtitle={`Total Facilities: ${facilityReports.length} | Enterprise Capacity: ${totalCap.toLocaleString()} Bags`}
          columns={exportColumns}
          data={facilityReports.map((f) => ({
            ...f,
            balanceMt: `${f.balanceMt.toFixed(2)} MT`,
            occupancyRate: `${f.occupancyRate.toFixed(1)}%`,
            estimatedRent: `৳${Math.round(f.estimatedRent).toLocaleString()}`,
          }))}
          summaryItems={[
            { label: 'Total Enterprise Capacity', value: `${totalCap.toLocaleString()} Bags` },
            { label: 'Vault Stored Stock', value: `${totalVault.toLocaleString()} Bags` },
            { label: 'Overall Occupancy', value: `${overallOccupancy.toFixed(1)}%` },
            { label: 'Projected Total Rent', value: `৳${Math.round(totalEstRent).toLocaleString()}` },
          ]}
          filename="Facility_Utilization_Report_2024"
        />
      )}
    </div>
  );
};
