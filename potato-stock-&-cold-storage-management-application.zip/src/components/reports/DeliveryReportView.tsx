import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingDown,
  FileSpreadsheet,
  Printer,
  Calendar,
  Eye,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { PrintPreviewModal } from '../common/PrintPreviewModal';

export const DeliveryReportView: React.FC = () => {
  const {
    deliveryTransactions,
    coldStorages,
    varieties,
    seedClasses,
    grades,
    companySettings,
    addToast,
  } = useApp();

  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState('2024-12-31');
  const [selectedStorage, setSelectedStorage] = useState('');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const [sortKey, setSortKey] = useState<string>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Filtered deliveries
  const filteredData = useMemo(() => {
    return deliveryTransactions.filter((d) => {
      if (d.date < startDate || d.date > endDate) return false;
      if (selectedStorage && d.coldStorageId !== selectedStorage) return false;
      return true;
    });
  }, [deliveryTransactions, startDate, endDate, selectedStorage]);

  const totalBags = filteredData.reduce((acc, d) => acc + d.sackQuantity, 0);
  const totalKg = filteredData.reduce((acc, d) => acc + d.totalKg, 0);
  const totalMt = filteredData.reduce((acc, d) => acc + d.totalMt, 0);

  const formattedRows = useMemo(() => {
    return filteredData.map((d) => {
      const storage = coldStorages.find((c) => c.id === d.coldStorageId)?.name || d.coldStorageId;
      const variety = varieties.find((v) => v.id === d.varietyId)?.name || d.varietyId;
      const seedClass = seedClasses.find((c) => c.id === d.classId)?.name || d.classId;
      const grade = grades.find((g) => g.id === d.gradeId)?.name || d.gradeId;

      return {
        id: d.id,
        date: d.date,
        deliveryNo: d.deliveryNo,
        reference: d.deliveryReference || d.doNumber || '-',
        storage,
        client: d.customerReceiver || d.clientReceiver || '-',
        destination: d.destination || '-',
        variety,
        class: seedClass,
        grade,
        bags: d.sackQuantity,
        kgPerBag: d.kgPerBag,
        totalKg: d.totalKg,
        totalMt: d.totalMt,
        vehicle: d.vehicleNo || '-',
        driver: d.driverName || '-',
      };
    });
  }, [filteredData, coldStorages, varieties, seedClasses, grades]);

  const sortedRows = useMemo(() => {
    return sortData(formattedRows, sortKey, sortDir);
  }, [formattedRows, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sortedRows.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedRows = sortedRows.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const exportColumns = [
    { header: 'Date', key: 'date', width: 12 },
    { header: 'Delivery No (DO)', key: 'deliveryNo', width: 16 },
    { header: 'Reference', key: 'reference', width: 14 },
    { header: 'From Cold Storage', key: 'storage', width: 24 },
    { header: 'Customer / Receiver', key: 'client', width: 24 },
    { header: 'Destination', key: 'destination', width: 18 },
    { header: 'Variety', key: 'variety', width: 16 },
    { header: 'Class', key: 'class', width: 14 },
    { header: 'Grade', key: 'grade', width: 18 },
    { header: 'Bags', key: 'bags', width: 12 },
    { header: 'KG/Bag', key: 'kgPerBag', width: 10 },
    { header: 'Total KG', key: 'totalKg', width: 14 },
    { header: 'Total MT', key: 'totalMt', width: 14 },
    { header: 'Vehicle No', key: 'vehicle', width: 16 },
  ];

  const handleExcel = () => {
    exportToExcel(
      formattedRows,
      exportColumns,
      'Delivery_Dispatches_Report_2024',
      'Stock Out from Cold Storage Report',
      companySettings,
      `Date Range: ${startDate} to ${endDate}`
    );
  };

  const handlePrint = () => {
    if (formattedRows.length === 0) {
      if (addToast) addToast('Delivery report dataset is empty.', 'error');
      return;
    }

    const printData = formattedRows.map((r) => ({
      date: r.date,
      deliveryNo: r.deliveryNo,
      storage: r.storage,
      client: r.client,
      destination: r.destination,
      variety: r.variety,
      classGrade: `${r.class} / ${r.grade}`,
      bags: r.bags.toLocaleString(),
      totalKg: r.totalKg.toLocaleString(),
      totalMt: r.totalMt.toFixed(2),
      vehicle: r.vehicle,
    }));

    validateAndTriggerPrint({
      data: printData,
      reportTitle: 'STOCK OUT FROM COLD STORAGE REPORT',
      companySettings,
      expectedMinRecords: 1,
      columns: [
        { header: 'Date', key: 'date' },
        { header: 'DO No', key: 'deliveryNo' },
        { header: 'From Storage', key: 'storage' },
        { header: 'Customer / Receiver', key: 'client' },
        { header: 'Destination', key: 'destination' },
        { header: 'Variety', key: 'variety' },
        { header: 'Class / Grade', key: 'classGrade' },
        { header: 'Bags', key: 'bags', align: 'right' },
        { header: 'Total KG', key: 'totalKg', align: 'right' },
        { header: 'Total MT', key: 'totalMt', align: 'right' },
        { header: 'Vehicle', key: 'vehicle' },
      ],
      databaseCheck: () => ({ isConsistent: true }),
      onError: (msg) => {
        if (addToast) addToast(msg, 'error');
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <TrendingDown className="w-6 h-6 text-amber-500" />
            STOCK OUT FROM COLD STORAGE REPORT (DELIVERIES)
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            DISPATCH RECORDS, CUSTOMER DISTRIBUTION LOGS, VEHICLE GATE PASSES, AND RELEASED SEED TONNAGE
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => setIsPreviewOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Eye className="w-4 h-4 text-sky-500" />
            <span>DOCUMENT PREVIEW</span>
          </button>

          <button
            onClick={handleExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXPORT EXCEL</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs no-print">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              End Date
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              From Cold Storage
            </label>
            <select
              value={selectedStorage}
              onChange={(e) => {
                setSelectedStorage(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="">All Facilities</option>
              {coldStorages.map((cs) => (
                <option key={cs.id} value={cs.id}>
                  {cs.name} ({cs.code})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            DISPATCHES EXECUTED
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {filteredData.length} Orders
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL SACKS / BAGS
          </span>
          <span className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-0.5 block font-mono">
            {totalBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL NET WEIGHT
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalKg.toLocaleString()} KG
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            METRIC TONS DISPATCHED
          </span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block font-mono">
            {totalMt.toFixed(2)} MT
          </span>
        </div>
      </div>

      {/* Tabular Records */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="DATE" sortKey="date" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="DO NO" sortKey="deliveryNo" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="FROM STORAGE" sortKey="storage" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CUSTOMER / CONSIGNEE" sortKey="client" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="DESTINATION" sortKey="destination" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="VARIETY" sortKey="variety" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLASS" sortKey="class" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="GRADE" sortKey="grade" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="BAGS" sortKey="bags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL KG" sortKey="totalKg" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL MT" sortKey="totalMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TRANSPORT" sortKey="vehicle" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedRows.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-8 text-center text-slate-400 italic">
                    No delivery records found matching specified filters.
                  </td>
                </tr>
              ) : (
                paginatedRows.map((r) => (
                  <tr
                    key={r.id}
                    className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {r.date}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-amber-600 dark:text-amber-400">
                      {r.deliveryNo}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {r.storage}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                      {r.client}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                      {r.destination}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                      {r.variety}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{r.class}</td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{r.grade}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-amber-600 dark:text-amber-400 font-mono">
                      {r.bags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-800 dark:text-slate-200 font-mono">
                      {r.totalKg.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-900 dark:text-white font-mono">
                      {r.totalMt.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-[11px] text-slate-500 dark:text-slate-400">
                      {r.vehicle}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {formattedRows.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                  <td colSpan={8} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                    TOTAL DISPATCHED:
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-600 dark:text-amber-400">
                    {totalBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    {totalKg.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400">
                    {totalMt.toFixed(2)} MT
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Pagination */}
        {sortedRows.length > 0 && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedRows.length}
            pageSizeOptions={[10, 15, 25, 50, 100]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>

      {/* Print Preview Modal */}
      {isPreviewOpen && (
        <PrintPreviewModal
          isOpen={isPreviewOpen}
          onClose={() => setIsPreviewOpen(false)}
          documentTitle="Stock Out from Cold Storage Report (Deliveries)"
          subtitle={`Report Period: ${startDate} to ${endDate} | Total Orders: ${formattedRows.length}`}
          columns={exportColumns}
          data={formattedRows}
          summaryItems={[
            { label: 'Dispatches Executed', value: formattedRows.length },
            { label: 'Total Sacks / Bags', value: totalBags.toLocaleString() },
            { label: 'Total Net KG', value: totalKg.toLocaleString() },
            { label: 'Total Metric Tons', value: `${totalMt.toFixed(2)} MT` },
          ]}
          filename="Delivery_Report_2024"
        />
      )}
    </div>
  );
};
