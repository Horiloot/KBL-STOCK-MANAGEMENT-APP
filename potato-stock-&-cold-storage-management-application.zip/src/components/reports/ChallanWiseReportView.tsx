import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileCode,
  FileSpreadsheet,
  Printer,
  Search,
  Eye,
} from 'lucide-react';
import { exportToExcel, validateAndTriggerPrint } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { SortableHeader } from '../common/SortableHeader';
import { TablePagination } from '../common/TablePagination';
import { PrintPreviewModal } from '../common/PrintPreviewModal';

export const ChallanWiseReportView: React.FC = () => {
  const {
    stockTransactions,
    coldStorages,
    varieties,
    seedClasses,
    grades,
    companySettings,
    addToast,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const [sortKey, setSortKey] = useState<string>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Group inbound lots by KBL Challan No
  const challanReportList = useMemo(() => {
    const challanMap: Record<
      string,
      {
        kblChallanNo: string;
        date: string;
        coldStorageId: string;
        srNos: Set<string>;
        varietyIds: Set<string>;
        classIds: Set<string>;
        gradeIds: Set<string>;
        totalBags: number;
        totalKg: number;
        totalMt: number;
        truckNo?: string;
        driverName?: string;
        growerFarmerName?: string;
      }
    > = {};

    stockTransactions.forEach((s) => {
      if (!challanMap[s.kblChallanNo]) {
        challanMap[s.kblChallanNo] = {
          kblChallanNo: s.kblChallanNo,
          date: s.date,
          coldStorageId: s.coldStorageId,
          srNos: new Set(),
          varietyIds: new Set(),
          classIds: new Set(),
          gradeIds: new Set(),
          totalBags: 0,
          totalKg: 0,
          totalMt: 0,
          truckNo: s.truckNo,
          driverName: s.driverName,
          growerFarmerName: s.growerFarmerName,
        };
      }

      const item = challanMap[s.kblChallanNo];
      item.srNos.add(s.srNo);
      item.varietyIds.add(s.varietyId);
      item.classIds.add(s.classId);
      item.gradeIds.add(s.gradeId);
      item.totalBags += s.sackQuantity;
      item.totalKg += s.totalKg;
      item.totalMt += s.totalMt;
    });

    return Object.values(challanMap).map((item) => {
      const storage = coldStorages.find((c) => c.id === item.coldStorageId)?.name || item.coldStorageId;
      const varietiesList = Array.from(item.varietyIds)
        .map((vid) => varieties.find((v) => v.id === vid)?.name || vid)
        .join(', ');
      const classesList = Array.from(item.classIds)
        .map((cid) => seedClasses.find((c) => c.id === cid)?.name || cid)
        .join(', ');
      const gradesList = Array.from(item.gradeIds)
        .map((gid) => grades.find((g) => g.id === gid)?.name || gid)
        .join(', ');

      return {
        id: item.kblChallanNo,
        challanNo: item.kblChallanNo,
        date: item.date,
        storage,
        srs: Array.from(item.srNos).join(', '),
        varieties: varietiesList,
        classes: classesList,
        grades: gradesList,
        bags: item.totalBags,
        totalKg: item.totalKg,
        totalMt: item.totalMt,
        truckNo: item.truckNo || '-',
        driverName: item.driverName || '-',
        growerFarmerName: item.growerFarmerName || '-',
      };
    });
  }, [stockTransactions, coldStorages, varieties, seedClasses, grades]);

  const filteredChallans = useMemo(() => {
    return challanReportList.filter((c) => {
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const match =
          c.challanNo.toLowerCase().includes(q) ||
          c.srs.toLowerCase().includes(q) ||
          c.storage.toLowerCase().includes(q) ||
          c.varieties.toLowerCase().includes(q) ||
          c.growerFarmerName.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [challanReportList, searchTerm]);

  const sortedChallans = useMemo(() => {
    return sortData(filteredChallans, sortKey, sortDir);
  }, [filteredChallans, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sortedChallans.length / pageSize));
  const effectivePage = Math.min(Math.max(1, currentPage), totalPages);
  const paginatedChallans = sortedChallans.slice((effectivePage - 1) * pageSize, effectivePage * pageSize);

  const totalChallanCount = filteredChallans.length;
  const totalChallanBags = filteredChallans.reduce((acc, c) => acc + c.bags, 0);
  const totalChallanKg = filteredChallans.reduce((acc, c) => acc + c.totalKg, 0);
  const totalChallanMt = filteredChallans.reduce((acc, c) => acc + c.totalMt, 0);

  const exportColumns = [
    { header: 'KBL Challan No', key: 'challanNo', width: 16 },
    { header: 'Date', key: 'date', width: 12 },
    { header: 'Cold Storage', key: 'storage', width: 24 },
    { header: 'SR Receipts', key: 'srs', width: 18 },
    { header: 'Seed Varieties', key: 'varieties', width: 20 },
    { header: 'Classes', key: 'classes', width: 16 },
    { header: 'Grades', key: 'grades', width: 16 },
    { header: 'Total Bags', key: 'bags', width: 14 },
    { header: 'Total KG', key: 'totalKg', width: 14 },
    { header: 'Total MT', key: 'totalMt', width: 14 },
    { header: 'Truck No', key: 'truckNo', width: 16 },
    { header: 'Grower / Farmer', key: 'growerFarmerName', width: 22 },
  ];

  const handleExcel = () => {
    exportToExcel(
      filteredChallans,
      exportColumns,
      'Challan_Wise_Summary_Report_2024',
      'KBL Challan-Wise Seed Stock Summary Report',
      companySettings,
      `Records: ${filteredChallans.length} | Generated: ${new Date().toLocaleDateString()}`
    );
  };

  const handlePrint = () => {
    if (filteredChallans.length === 0) {
      if (addToast) addToast('Challan-wise report dataset has no records.', 'error');
      return;
    }

    const printData = filteredChallans.map((r) => ({
      challanNo: r.challanNo,
      date: r.date,
      storage: r.storage,
      srs: r.srs,
      varieties: r.varieties,
      classGrade: `${r.classes} / ${r.grades}`,
      bags: r.bags.toLocaleString(),
      totalKg: r.totalKg.toLocaleString(),
      totalMt: r.totalMt.toFixed(2),
      logistics: r.truckNo,
    }));

    validateAndTriggerPrint({
      data: printData,
      reportTitle: 'KBL CHALLAN-WISE SEED STOCK SUMMARY REPORT',
      companySettings,
      expectedMinRecords: 1,
      columns: [
        { header: 'Challan No', key: 'challanNo' },
        { header: 'Date', key: 'date' },
        { header: 'Cold Storage', key: 'storage' },
        { header: 'SR Receipts', key: 'srs' },
        { header: 'Seed Varieties', key: 'varieties' },
        { header: 'Class / Grade', key: 'classGrade' },
        { header: 'Total Bags', key: 'bags', align: 'right' },
        { header: 'Total KG', key: 'totalKg', align: 'right' },
        { header: 'Total MT', key: 'totalMt', align: 'right' },
        { header: 'Logistics', key: 'logistics' },
      ],
      databaseCheck: () => ({ isConsistent: true }),
      onError: (msg) => {
        if (addToast) addToast(msg, 'error');
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2 uppercase">
            <FileCode className="w-6 h-6 text-sky-600 dark:text-sky-400" />
            CHALLAN-WISE STOCK INBOUND REPORT
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 uppercase">
            DISPATCH RECORDS GROUPED BY INTERNAL CORPORATE KBL CHALLAN NUMBERS
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => setIsPreviewOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Eye className="w-4 h-4 text-sky-500" />
            <span>DOCUMENT PREVIEW</span>
          </button>

          <button
            onClick={handleExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>EXPORT EXCEL</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer uppercase"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Search & KPIs */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs no-print">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Challan No, SR, Storage, Variety..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        <div className="text-xs text-slate-500">
          Showing <strong className="text-slate-800 dark:text-slate-200">{filteredChallans.length}</strong> Challans
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            UNIQUE CHALLANS
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalChallanCount} Challans
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            TOTAL SACKS / BAGS
          </span>
          <span className="text-xl font-bold text-sky-600 dark:text-sky-400 mt-0.5 block font-mono">
            {totalChallanBags.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            NET WEIGHT (KG)
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
            {totalChallanKg.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            METRIC TONS (MT)
          </span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block font-mono">
            {totalChallanMt.toFixed(2)} MT
          </span>
        </div>
      </div>

      {/* Table Data */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-semibold uppercase text-[11px] tracking-wider select-none">
                <SortableHeader label="KBL CHALLAN NO" sortKey="challanNo" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="DATE" sortKey="date" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="COLD STORAGE" sortKey="storage" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="SR NUMBER(S)" sortKey="srs" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="POTATO VARIETY" sortKey="varieties" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="CLASS & GRADE" sortKey="classes" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
                <SortableHeader label="TOTAL BAGS" sortKey="bags" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL KG" sortKey="totalKg" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="TOTAL MT" sortKey="totalMt" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} align="right" />
                <SortableHeader label="LOGISTICS" sortKey="truckNo" currentSortKey={sortKey} currentSortDir={sortDir} onSort={handleSort} />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedChallans.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-400 italic">
                    No Challan records found matching search filters.
                  </td>
                </tr>
              ) : (
                paginatedChallans.map((row) => (
                  <tr
                    key={row.id}
                    className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-2.5 px-3 font-mono font-bold text-sky-600 dark:text-sky-400">
                      {row.challanNo}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {row.date}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {row.storage}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-600 dark:text-slate-300">
                      {row.srs}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                      {row.varieties}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                      <div>{row.classes}</div>
                      <div className="text-[10px] text-slate-400">{row.grades}</div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-900 dark:text-white font-mono">
                      {row.bags.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-800 dark:text-slate-200 font-mono">
                      {row.totalKg.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                      {row.totalMt.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300 text-[11px]">
                      <div>{row.truckNo}</div>
                      <div className="text-[10px] text-slate-400">{row.driverName}</div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {filteredChallans.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white uppercase">
                  <td colSpan={6} className="py-3 px-3 text-right uppercase text-[11px] tracking-wider">
                    TOTAL CHALLAN AGGREGATE:
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sky-600 dark:text-sky-400">
                    {totalChallanBags.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    {totalChallanKg.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400">
                    {totalChallanMt.toFixed(2)} MT
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Pagination */}
        {sortedChallans.length > 0 && (
          <TablePagination
            currentPage={effectivePage}
            totalPages={totalPages}
            pageSize={pageSize}
            totalItems={sortedChallans.length}
            pageSizeOptions={[10, 15, 25, 50, 100]}
            onPageChange={setCurrentPage}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setCurrentPage(1);
            }}
          />
        )}
      </div>

      {/* Print Preview Modal */}
      {isPreviewOpen && (
        <PrintPreviewModal
          isOpen={isPreviewOpen}
          onClose={() => setIsPreviewOpen(false)}
          documentTitle="KBL Challan-Wise Seed Stock Summary Report"
          subtitle={`Total Challans: ${filteredChallans.length} | Generated: ${new Date().toLocaleDateString()}`}
          columns={exportColumns}
          data={filteredChallans}
          summaryItems={[
            { label: 'Total Challans Processed', value: filteredChallans.length },
            { label: 'Total Sacks / Bags', value: totalChallanBags.toLocaleString() },
            { label: 'Total Net Weight (KG)', value: totalChallanKg.toLocaleString() },
            { label: 'Total Metric Tons', value: `${totalChallanMt.toFixed(2)} MT` },
          ]}
          filename="Challan_Wise_Summary_Report_2024"
        />
      )}
    </div>
  );
};
