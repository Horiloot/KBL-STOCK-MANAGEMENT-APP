import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Plus,
  X,
  Zap,
  Boxes,
  Truck,
  ArrowDownToLine,
  ArrowUpFromLine,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const QuickActionsFloatingMenu: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const {
    setIsStockModalOpen,
    setIsDeliveryModalOpen,
    hasPermission,
    addToast,
  } = useApp();

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  const handleOpenStockEntry = () => {
    if (!hasPermission('add_stock')) {
      addToast('You do not have permission to record new stock entries.', 'warning');
      return;
    }
    setIsStockModalOpen(true);
    setIsOpen(false);
  };

  const handleOpenDelivery = () => {
    if (!hasPermission('add_delivery')) {
      addToast('You do not have permission to issue new deliveries.', 'warning');
      return;
    }
    setIsDeliveryModalOpen(true);
    setIsOpen(false);
  };

  return (
    <div
      ref={menuRef}
      id="quick-actions-container"
      className="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 z-40 select-none no-print"
    >
      {/* Floating Speed-Dial Actions Popover */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="quick-actions-menu-panel"
            initial={{ opacity: 0, scale: 0.88, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.88, y: 12 }}
            transition={{ type: 'spring', damping: 24, stiffness: 320 }}
            className="absolute bottom-16 right-0 mb-2 w-72 sm:w-80 rounded-2xl bg-white dark:bg-slate-850 border border-slate-200/90 dark:border-slate-750 shadow-2xl overflow-hidden p-2 backdrop-blur-md"
          >
            {/* Header banner */}
            <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-black text-slate-800 dark:text-slate-100 tracking-wider uppercase">
                <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>QUICK ACTIONS</span>
              </div>
              <span className="text-[10px] font-bold text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/80 px-2 py-0.5 rounded-full border border-sky-200/70 dark:border-sky-800 uppercase">
                FAST INPUT
              </span>
            </div>

            {/* Menu options list */}
            <div className="p-1 space-y-1 mt-1">
              {/* Option 1: New Stock Entry */}
              <button
                type="button"
                id="quick-action-new-stock"
                onClick={handleOpenStockEntry}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl text-left transition-all hover:bg-sky-50/80 dark:hover:bg-slate-800 group border border-transparent hover:border-sky-200/60 dark:hover:border-sky-900/60 cursor-pointer shadow-2xs"
              >
                <div className="w-10 h-10 rounded-xl bg-sky-100 dark:bg-sky-950/80 text-sky-600 dark:text-sky-300 flex items-center justify-center shrink-0 group-hover:scale-105 group-hover:bg-sky-600 group-hover:text-white transition-all shadow-xs">
                  <ArrowDownToLine className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wide group-hover:text-sky-700 dark:group-hover:text-sky-300 transition-colors">
                      NEW STOCK ENTRY
                    </span>
                    <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-100/70 dark:bg-emerald-950/60 px-1.5 py-0.2 rounded uppercase">
                      INBOUND
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    Send potato seed to cold storage
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-sky-600 group-hover:translate-x-0.5 transition-all shrink-0" />
              </button>

              {/* Option 2: New Delivery */}
              <button
                type="button"
                id="quick-action-new-delivery"
                onClick={handleOpenDelivery}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl text-left transition-all hover:bg-amber-50/80 dark:hover:bg-slate-800 group border border-transparent hover:border-amber-200/60 dark:hover:border-amber-900/60 cursor-pointer shadow-2xs"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-300 flex items-center justify-center shrink-0 group-hover:scale-105 group-hover:bg-amber-600 group-hover:text-white transition-all shadow-xs">
                  <ArrowUpFromLine className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wide group-hover:text-amber-700 dark:group-hover:text-amber-300 transition-colors">
                      NEW DELIVERY
                    </span>
                    <span className="text-[10px] font-semibold text-amber-700 dark:text-amber-300 bg-amber-100/70 dark:bg-amber-950/60 px-1.5 py-0.2 rounded uppercase">
                      OUTBOUND
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    Stock out gate pass & delivery dispatch
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-amber-600 group-hover:translate-x-0.5 transition-all shrink-0" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Floating Trigger Button */}
      <button
        type="button"
        id="quick-actions-trigger-button"
        onClick={() => setIsOpen((prev) => !prev)}
        aria-expanded={isOpen}
        aria-haspopup="true"
        aria-label="Quick Actions Menu"
        title={isOpen ? 'Close Quick Actions' : 'Open Quick Actions Menu'}
        className={`group relative flex items-center gap-2 px-4 py-3 sm:px-4.5 sm:py-3.5 rounded-full shadow-xl transition-all duration-200 cursor-pointer focus:outline-none focus:ring-4 focus:ring-sky-500/30 ${
          isOpen
            ? 'bg-slate-900 dark:bg-slate-750 text-white ring-2 ring-slate-700 scale-95'
            : 'bg-gradient-to-r from-sky-600 to-sky-700 hover:from-sky-500 hover:to-sky-600 text-white shadow-sky-600/30 hover:shadow-sky-600/40 hover:scale-105 active:scale-95'
        }`}
      >
        {/* Animated icon indicator */}
        <div className="relative w-5 h-5 flex items-center justify-center">
          <motion.div
            animate={{ rotate: isOpen ? 90 : 0 }}
            transition={{ duration: 0.2 }}
            className="flex items-center justify-center"
          >
            {isOpen ? (
              <X className="w-5 h-5 text-white" />
            ) : (
              <Zap className="w-5 h-5 text-amber-300 fill-amber-300" />
            )}
          </motion.div>
        </div>

        {/* Text label */}
        <span className="text-xs sm:text-sm font-extrabold tracking-wider uppercase pr-0.5">
          {isOpen ? 'CLOSE' : 'QUICK ACTIONS'}
        </span>

        {/* Subtle status pulse indicator when closed */}
        {!isOpen && (
          <span className="relative flex h-2 w-2 ml-0.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
          </span>
        )}
      </button>
    </div>
  );
};
