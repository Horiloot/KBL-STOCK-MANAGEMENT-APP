import React, { useMemo, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TableDensity } from '../../types';
import { Building2, Plus, Download, FileText, Printer, ChevronDown, Package, X, Search, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { exportToExcel, exportToPdf, validateAndTriggerPrint, ExportColumn } from '../../utils/exportUtils';
import { sortData } from '../../utils/sortUtils';
import { TablePagination } from '../common/TablePagination';
import { ColdStorageEmptyState } from '../coldStorage/ColdStorageEmptyState';
import { Modal } from '../common/Modal';

interface ColdStorageFacilityTableProps {
  onExportExcel?: () => void;
  onExportPdf?: () => void;
  onPrint?: () => void;
  density?: TableDensity;
}

export const ColdStorageFacilityTable: React.FC<ColdStorageFacilityTableProps> = ({
  onExportExcel,
  onExportPdf,
  onPrint,
  density = 'comfortable',
}) => {
  const {
    coldStorages,
    stockTransactions,
    deliveryTransactions,
    varieties,
    seedClasses,
    grades,
    addColdStorage,
    addToast,
    companySettings,
  } = useApp();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [highlightedFacilityId, setHighlightedFacilityId] = useState<string | null>(null);
  const [expandedFacilityIds, setExpandedFacilityIds] = useState<string[]>([]);
  const [facilitySearchMap, setFacilitySearchMap] = useState<Record<string, string>>({});

  const handleExportFacilityExcel = (facilityName: string, items: any[]) => {
    const exportData = items.map((item) => ({
      variety: item.varietyName,
      class: item.className,
      grade: item.gradeName,
      received: item.received,
      delivered: item.delivered,
      remaining: item.remaining,
      totalMt: item.totalMt,
      srNumbers: item.srList.join(', '),
    }));

    exportToExcel(
      exportData,
      [
        { header: 'Variety', key: 'variety', width: 22 },
        { header: 'Class', key: 'class', width: 16 },
        { header: 'Grade', key: 'grade', width: 14 },
        { header: 'Received Bags', key: 'received', width: 16 },
        { header: 'Delivered Bags', key: 'delivered', width: 16 },
        { header: 'Remaining Bags', key: 'remaining', width: 16 },
        { header: 'Total MT', key: 'totalMt', width: 14 },
        { header: 'SR Numbers', key: 'srNumbers', width: 30 },
      ],
      `${facilityName.replace(/\s+/g, '_')}_Item_Breakdown`,
      `Cold Storage Breakdown - ${facilityName}`,
      companySettings
    );
    addToast(`${facilityName} breakdown exported to Excel!`, 'success');
  };

  const handleExportFacilityPdf = (facilityName: string, items: any[]) => {
    const exportData = items.map((item) => ({
      variety: item.varietyName,
      class: item.className,
      grade: item.gradeName,
      received: item.received.toLocaleString(),
      delivered: item.delivered.toLocaleString(),
      remaining: item.remaining.toLocaleString(),
      totalMt: item.totalMt.toFixed(2),
    }));

    exportToPdf(
      exportData,
      [
        { header: 'Variety', key: 'variety' },
        { header: 'Class', key: 'class' },
        { header: 'Grade', key: 'grade' },
        { header: 'Received Bags', key: 'received' },
        { header: 'Delivered Bags', key: 'delivered' },
        { header: 'Remaining Bags', key: 'remaining' },
        { header: 'Total MT', key: 'totalMt' },
      ],
      `${facilityName.replace(/\s+/g, '_')}_Item_Breakdown`,
      `Cold Storage Breakdown - ${facilityName}`,
      companySettings
    );
    addToast(`${facilityName} breakdown exported to PDF!`, 'success');
  };

  const [facilitySortKey, setFacilitySortKey] = useState<string>('name');
  const [facilitySortDir, setFacilitySortDir] = useState<'asc' | 'desc'>('asc');
  const [breakdownSortMap, setBreakdownSortMap] = useState<Record<string, { key: string; dir: 'asc' | 'desc' }>>({});
  const [breakdownPageMap, setBreakdownPageMap] = useState<Record<string, { page: number; pageSize: number }>>({});

  const handleFacilitySort = (key: string) => {
    if (facilitySortKey === key) {
      setFacilitySortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setFacilitySortKey(key);
      setFacilitySortDir('asc');
    }
  };

  const handleBreakdownSort = (facilityId: string, key: string) => {
    setBreakdownSortMap((prev) => {
      const cur = prev[facilityId] || { key: 'remaining', dir: 'desc' };
      const nextDir = cur.key === key && cur.dir === 'asc' ? 'desc' : 'asc';
      return { ...prev, [facilityId]: { key, dir: nextDir } };
    });
  };

  const handlePrintFacility = (facilityName: string, items: any[]) => {
    if (!items || items.length === 0) {
      addToast('No item breakdown records to print for this facility.', 'warning');
      return;
    }

    const columns: ExportColumn[] = [
      { header: 'VARIETY', key: 'variety', width: 22 },
      { header: 'CLASS', key: 'class', width: 16 },
      { header: 'GRADE', key: 'grade', width: 14 },
      { header: 'RECEIVED (BAGS)', key: 'received', width: 16, isNumeric: true },
      { header: 'DELIVERED (BAGS)', key: 'delivered', width: 16, isNumeric: true },
      { header: 'REMAINING (BAGS)', key: 'remaining', width: 16, isNumeric: true },
      { header: 'TOTAL MT', key: 'totalMt', width: 14, isNumeric: true },
      { header: 'SR NUMBERS', key: 'srNumbers', width: 26 },
    ];

    const printData = items.map((item) => ({
      variety: item.varietyName,
      class: item.className,
      grade: item.gradeName,
      received: item.received,
      delivered: item.delivered,
      remaining: item.remaining,
      totalMt: item.totalMt,
      srNumbers: item.srList.join(', ') || '-',
    }));

    validateAndTriggerPrint({
      data: printData,
      columns,
      reportTitle: `ITEM-WISE STOCK BREAKDOWN — ${facilityName.toUpperCase()}`,
      companySettings,
      subtitle: `Cold Storage Facility: ${facilityName} | Total Records: ${items.length}`,
      expectedMinRecords: 1,
      onError: (err) => {
        addToast(err, 'error');
      },
    });
  };

  const toggleExpandFacility = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setExpandedFacilityIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Form state for quick add storage
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [district, setDistrict] = useState('');
  const [capacity, setCapacity] = useState<number>(100000);
  const [rentPerBag, setRentPerBag] = useState<number>(280);
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const handleOpenAddModal = () => {
    setCode(`CS-${coldStorages.length + 1}`);
    setName('');
    setLocation('');
    setDistrict('');
    setCapacity(100000);
    setRentPerBag(280);
    setContactPerson('');
    setPhone('');
    setFormError(null);
    setIsAddModalOpen(true);
  };

  const handleSaveStorage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim() || !location.trim()) {
      setFormError('Facility Code, Name, and Location are required.');
      return;
    }

    addColdStorage({
      code: code.trim().toUpperCase(),
      name: name.trim(),
      location: location.trim(),
      district: district.trim() || undefined,
      capacity: Number(capacity) || 0,
      rentPerBag: Number(rentPerBag) || 0,
      contactPerson: contactPerson.trim() || undefined,
      phone: phone.trim() || undefined,
      status: 'active',
      isActive: true,
    });

    addToast(`Storage facility "${name.trim()}" added successfully!`, 'success');
    setIsAddModalOpen(false);
  };

  // Calculate live facility metrics directly from raw transactions
  // This automatically recalculates whenever stock or delivery changes
  const facilityData = useMemo(() => {
    return coldStorages.map((cs) => {
      const received = stockTransactions
        .filter((s) => s.coldStorageId === cs.id)
        .reduce((sum, s) => sum + s.sackQuantity, 0);

      const delivered = deliveryTransactions
        .filter((d) => d.coldStorageId === cs.id)
        .reduce((sum, d) => sum + d.sackQuantity, 0);

      const remaining = received - delivered;

      const occupancy =
        cs.capacity && cs.capacity > 0 ? (remaining / cs.capacity) * 100 : null;

      return {
        id: cs.id,
        code: cs.code,
        name: cs.name,
        location: cs.location || '-',
        capacity: cs.capacity || 0,
        received,
        delivered,
        remaining,
        occupancy,
      };
    });
  }, [coldStorages, stockTransactions, deliveryTransactions]);

  // Sort facility data
  const sortedFacilityData = useMemo(() => {
    return sortData(facilityData, facilitySortKey, facilitySortDir);
  }, [facilityData, facilitySortKey, facilitySortDir]);

  // Overall totals across all cold storages
  const totals = useMemo(() => {
    const totalCapacity = facilityData.reduce((sum, f) => sum + f.capacity, 0);
    const totalReceived = facilityData.reduce((sum, f) => sum + f.received, 0);
    const totalDelivered = facilityData.reduce((sum, f) => sum + f.delivered, 0);
    const totalRemaining = totalReceived - totalDelivered;
    const overallOccupancy =
      totalCapacity > 0 ? (totalRemaining / totalCapacity) * 100 : null;

    return {
      totalCapacity,
      totalReceived,
      totalDelivered,
      totalRemaining,
      overallOccupancy,
    };
  }, [facilityData]);

  const getOccupancyColor = (pct: number | null) => {
    if (pct === null) return 'text-slate-400 bg-slate-100 dark:bg-slate-800';
    if (pct > 90) return 'text-rose-700 bg-rose-50 dark:text-rose-300 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900';
    if (pct > 75) return 'text-amber-700 bg-amber-50 dark:text-amber-300 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900';
    return 'text-emerald-700 bg-emerald-50 dark:text-emerald-300 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900';
  };

  // Distinct subtle light / pastel color theme per cold storage row with smooth hover background shift
  const COLD_STORAGE_ROW_PALETTE = [
    {
      bg: 'bg-sky-50/40 dark:bg-sky-950/20',
      hover: 'hover:bg-sky-100/75 dark:hover:bg-sky-900/50 hover:shadow-xs',
      highlight: 'bg-sky-100/90 dark:bg-sky-950/80 ring-1 ring-inset ring-sky-300 dark:ring-sky-700',
      borderLeft: 'border-l-[3px] border-l-sky-500',
      accentIndicator: 'bg-sky-500',
      badge: 'bg-sky-100 text-sky-800 dark:bg-sky-900/70 dark:text-sky-300 border border-sky-200 dark:border-sky-800',
      remainingText: 'text-sky-700 dark:text-sky-300',
    },
    {
      bg: 'bg-emerald-50/40 dark:bg-emerald-950/20',
      hover: 'hover:bg-emerald-100/75 dark:hover:bg-emerald-900/50 hover:shadow-xs',
      highlight: 'bg-emerald-100/90 dark:bg-emerald-950/80 ring-1 ring-inset ring-emerald-300 dark:ring-emerald-700',
      borderLeft: 'border-l-[3px] border-l-emerald-500',
      accentIndicator: 'bg-emerald-500',
      badge: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
      remainingText: 'text-emerald-700 dark:text-emerald-300',
    },
    {
      bg: 'bg-amber-50/40 dark:bg-amber-950/20',
      hover: 'hover:bg-amber-100/75 dark:hover:bg-amber-900/50 hover:shadow-xs',
      highlight: 'bg-amber-100/90 dark:bg-amber-950/80 ring-1 ring-inset ring-amber-300 dark:ring-amber-700',
      borderLeft: 'border-l-[3px] border-l-amber-500',
      accentIndicator: 'bg-amber-500',
      badge: 'bg-amber-100 text-amber-800 dark:bg-amber-900/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
      remainingText: 'text-amber-700 dark:text-amber-300',
    },
    {
      bg: 'bg-purple-50/40 dark:bg-purple-950/20',
      hover: 'hover:bg-purple-100/75 dark:hover:bg-purple-900/50 hover:shadow-xs',
      highlight: 'bg-purple-100/90 dark:bg-purple-950/80 ring-1 ring-inset ring-purple-300 dark:ring-purple-700',
      borderLeft: 'border-l-[3px] border-l-purple-500',
      accentIndicator: 'bg-purple-500',
      badge: 'bg-purple-100 text-purple-800 dark:bg-purple-900/70 dark:text-purple-300 border border-purple-200 dark:border-purple-800',
      remainingText: 'text-purple-700 dark:text-purple-300',
    },
    {
      bg: 'bg-rose-50/40 dark:bg-rose-950/20',
      hover: 'hover:bg-rose-100/75 dark:hover:bg-rose-900/50 hover:shadow-xs',
      highlight: 'bg-rose-100/90 dark:bg-rose-950/80 ring-1 ring-inset ring-rose-300 dark:ring-rose-700',
      borderLeft: 'border-l-[3px] border-l-rose-500',
      accentIndicator: 'bg-rose-500',
      badge: 'bg-rose-100 text-rose-800 dark:bg-rose-900/70 dark:text-rose-300 border border-rose-200 dark:border-rose-800',
      remainingText: 'text-rose-700 dark:text-rose-300',
    },
    {
      bg: 'bg-teal-50/40 dark:bg-teal-950/20',
      hover: 'hover:bg-teal-100/75 dark:hover:bg-teal-900/50 hover:shadow-xs',
      highlight: 'bg-teal-100/90 dark:bg-teal-950/80 ring-1 ring-inset ring-teal-300 dark:ring-teal-700',
      borderLeft: 'border-l-[3px] border-l-teal-500',
      accentIndicator: 'bg-teal-500',
      badge: 'bg-teal-100 text-teal-800 dark:bg-teal-900/70 dark:text-teal-300 border border-teal-200 dark:border-teal-800',
      remainingText: 'text-teal-700 dark:text-teal-300',
    },
    {
      bg: 'bg-indigo-50/40 dark:bg-indigo-950/20',
      hover: 'hover:bg-indigo-100/75 dark:hover:bg-indigo-900/50 hover:shadow-xs',
      highlight: 'bg-indigo-100/90 dark:bg-indigo-950/80 ring-1 ring-inset ring-indigo-300 dark:ring-indigo-700',
      borderLeft: 'border-l-[3px] border-l-indigo-500',
      accentIndicator: 'bg-indigo-500',
      badge: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/70 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800',
      remainingText: 'text-indigo-700 dark:text-indigo-300',
    },
    {
      bg: 'bg-cyan-50/40 dark:bg-cyan-950/20',
      hover: 'hover:bg-cyan-100/75 dark:hover:bg-cyan-900/50 hover:shadow-xs',
      highlight: 'bg-cyan-100/90 dark:bg-cyan-950/80 ring-1 ring-inset ring-cyan-300 dark:ring-cyan-700',
      borderLeft: 'border-l-[3px] border-l-cyan-500',
      accentIndicator: 'bg-cyan-500',
      badge: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/70 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800',
      remainingText: 'text-cyan-700 dark:text-cyan-300',
    },
  ];

  // Helper to extract detailed item-wise breakdown for an expanded cold storage
  const getFacilityItemBreakdown = (facilityId: string) => {
    const facilityStocks = stockTransactions.filter(
      (s) => s.coldStorageId === facilityId && s.status === 'approved'
    );
    const facilityDeliveries = deliveryTransactions.filter(
      (d) => d.coldStorageId === facilityId && (d.status === 'approved' || d.status === 'completed')
    );

    const itemsMap: Record<
      string,
      {
        key: string;
        varietyId: string;
        varietyName: string;
        className: string;
        gradeName: string;
        received: number;
        delivered: number;
        kgPerBag: number;
        srNumbers: Set<string>;
      }
    > = {};

    facilityStocks.forEach((s) => {
      const key = `${s.varietyId}_${s.classId || 'default'}_${s.gradeId || 'default'}`;
      const v = varieties.find((item) => item.id === s.varietyId);
      const cls = seedClasses.find((item) => item.id === s.classId);
      const grd = grades.find((item) => item.id === s.gradeId);

      if (!itemsMap[key]) {
        itemsMap[key] = {
          key,
          varietyId: s.varietyId,
          varietyName: v?.name || 'Unknown Variety',
          className: cls?.name || 'Standard',
          gradeName: grd?.name || '-',
          received: 0,
          delivered: 0,
          kgPerBag: s.kgPerBag || 50,
          srNumbers: new Set<string>(),
        };
      }

      itemsMap[key].received += s.sackQuantity;
      if (s.srNo) {
        itemsMap[key].srNumbers.add(s.srNo);
      }
    });

    facilityDeliveries.forEach((d) => {
      const key = `${d.varietyId}_${d.classId || 'default'}_${d.gradeId || 'default'}`;
      if (itemsMap[key]) {
        itemsMap[key].delivered += d.sackQuantity;
      } else {
        const fallbackKey = Object.keys(itemsMap).find((k) => itemsMap[k].varietyId === d.varietyId);
        if (fallbackKey) {
          itemsMap[fallbackKey].delivered += d.sackQuantity;
        }
      }
    });

    return Object.values(itemsMap)
      .map((item) => {
        const remaining = Math.max(0, item.received - item.delivered);
        const totalMt = Number(((remaining * item.kgPerBag) / 1000).toFixed(2));
        return {
          ...item,
          remaining,
          totalMt,
          srList: Array.from(item.srNumbers),
        };
      })
      .sort((a, b) => b.remaining - a.remaining);
  };

  const thPadding = density === 'compact' ? 'py-1 px-2.5 text-[10.5px]' : density === 'comfortable' ? 'py-2.5 px-3.5 text-xs sm:text-sm' : 'py-1.5 px-3 text-[11px]';
  const tdPadding = density === 'compact' ? 'py-1 px-2.5 text-[11px]' : density === 'comfortable' ? 'py-2.5 px-3.5 text-xs sm:text-sm' : 'py-1.5 px-3 text-xs';
  const badgePadding = density === 'compact' ? 'text-[11px] px-2 py-0.5' : density === 'comfortable' ? 'text-xs sm:text-sm px-3 py-1.5' : 'text-xs px-2.5 py-1';
  const totalPadding = density === 'compact' ? 'py-1 px-2.5 text-xs' : density === 'comfortable' ? 'py-3 px-3.5 text-sm' : 'py-2 px-3 text-xs';
  const innerThPadding = density === 'compact' ? 'py-1 px-2 text-[10px]' : density === 'comfortable' ? 'py-2 px-3 text-xs' : 'py-1.5 px-3 text-[10.5px]';
  const innerTdPadding = density === 'compact' ? 'py-1 px-2 text-[10.5px]' : density === 'comfortable' ? 'py-2 px-3 text-xs' : 'py-1.5 px-3 text-xs';

  return (
    <div className="bg-white dark:bg-slate-900 border border-sky-200/90 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden print:overflow-visible print:border-none print:shadow-none">
      {/* Section Header - Eye-catching themed background */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 px-3 sm:px-4 py-2 sm:py-2.5 border-b border-sky-200/80 dark:border-sky-900/60 bg-gradient-to-r from-sky-100/90 via-sky-50/80 to-blue-50/70 dark:from-slate-850 dark:via-sky-950/40 dark:to-slate-900 print:bg-transparent print:border-b-2 print:border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded-md bg-sky-600 text-white shadow-xs print:hidden">
            <Building2 className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-black text-sky-950 dark:text-white uppercase tracking-wider">
              COLD STORAGE WISE SUMMARY
            </h3>
          </div>
        </div>

        {/* Right side: Excel, PDF, Print action buttons */}
        {(onExportExcel || onExportPdf || onPrint) && (
          <div className="flex items-center gap-1 sm:gap-1.5 no-print">
            {onExportExcel && (
              <button
                type="button"
                onClick={onExportExcel}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 dark:text-emerald-200 bg-white/90 hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-emerald-950/50 rounded-lg border border-emerald-300 dark:border-emerald-800/80 transition-colors shadow-2xs cursor-pointer uppercase"
                title="EXPORT COLD STORAGE SUMMARY TO EXCEL"
              >
                <Download className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                <span>EXCEL</span>
              </button>
            )}

            {onExportPdf && (
              <button
                type="button"
                onClick={onExportPdf}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-rose-800 dark:text-rose-200 bg-white/90 hover:bg-rose-50 dark:bg-slate-800 dark:hover:bg-rose-950/50 rounded-lg border border-rose-300 dark:border-rose-800/80 transition-colors shadow-2xs cursor-pointer uppercase"
                title="EXPORT COLD STORAGE SUMMARY TO PDF"
              >
                <FileText className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                <span>PDF</span>
              </button>
            )}

            {onPrint && (
              <button
                type="button"
                onClick={onPrint}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-slate-700 dark:text-slate-200 bg-white/90 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 rounded-lg border border-slate-300 dark:border-slate-700 transition-colors shadow-2xs cursor-pointer uppercase"
                title="PRINT COLD STORAGE SUMMARY"
              >
                <Printer className="w-3 h-3 text-slate-600 dark:text-slate-300" />
                <span>PRINT</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Content: Empty state or data table */}
      {facilityData.length === 0 ? (
        <ColdStorageEmptyState onAddStorage={handleOpenAddModal} />
      ) : (
        <div className="overflow-x-auto print:overflow-visible">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-800 text-slate-100 dark:bg-slate-850 dark:text-white font-bold border-b-2 border-slate-900 dark:border-slate-700 print:bg-slate-100 print:text-black select-none">
              <tr className="h-8.5">
                <th
                  onClick={() => handleFacilitySort('name')}
                  className={`${thPadding} font-semibold uppercase tracking-wider text-slate-100 dark:text-white cursor-pointer hover:bg-slate-700/60 dark:hover:bg-slate-800 transition-colors group`}
                  title="Sort by Cold Storage Name"
                >
                  <div className="flex items-center gap-1.5">
                    <span>COLD STORAGE NAME</span>
                    <span className="inline-flex items-center justify-center p-0.5 rounded">
                      {facilitySortKey === 'name' ? (
                        facilitySortDir === 'asc' ? (
                          <ArrowUp className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        ) : (
                          <ArrowDown className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        )
                      ) : (
                        <ArrowUpDown className="w-3 h-3 text-slate-400/70 group-hover:text-sky-300" />
                      )}
                    </span>
                  </div>
                </th>
                <th
                  onClick={() => handleFacilitySort('received')}
                  className={`${thPadding} text-right font-semibold uppercase tracking-wider text-slate-100 dark:text-white cursor-pointer hover:bg-slate-700/60 dark:hover:bg-slate-800 transition-colors group`}
                  title="Sort by Total Received Bags"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>RECEIVED</span>
                    <span className="inline-flex items-center justify-center p-0.5 rounded">
                      {facilitySortKey === 'received' ? (
                        facilitySortDir === 'asc' ? (
                          <ArrowUp className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        ) : (
                          <ArrowDown className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        )
                      ) : (
                        <ArrowUpDown className="w-3 h-3 text-slate-400/70 group-hover:text-sky-300" />
                      )}
                    </span>
                  </div>
                </th>
                <th
                  onClick={() => handleFacilitySort('delivered')}
                  className={`${thPadding} text-right font-semibold uppercase tracking-wider text-slate-100 dark:text-white cursor-pointer hover:bg-slate-700/60 dark:hover:bg-slate-800 transition-colors group`}
                  title="Sort by Total Delivered Bags"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>DELIVERED</span>
                    <span className="inline-flex items-center justify-center p-0.5 rounded">
                      {facilitySortKey === 'delivered' ? (
                        facilitySortDir === 'asc' ? (
                          <ArrowUp className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        ) : (
                          <ArrowDown className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        )
                      ) : (
                        <ArrowUpDown className="w-3 h-3 text-slate-400/70 group-hover:text-sky-300" />
                      )}
                    </span>
                  </div>
                </th>
                <th
                  onClick={() => handleFacilitySort('remaining')}
                  className={`${thPadding} text-right font-semibold uppercase tracking-wider text-slate-100 dark:text-white cursor-pointer hover:bg-slate-700/60 dark:hover:bg-slate-800 transition-colors group`}
                  title="Sort by Remaining Stock Bags"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>REMAINING STOCK</span>
                    <span className="inline-flex items-center justify-center p-0.5 rounded">
                      {facilitySortKey === 'remaining' ? (
                        facilitySortDir === 'asc' ? (
                          <ArrowUp className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        ) : (
                          <ArrowDown className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        )
                      ) : (
                        <ArrowUpDown className="w-3 h-3 text-slate-400/70 group-hover:text-sky-300" />
                      )}
                    </span>
                  </div>
                </th>
                <th
                  onClick={() => handleFacilitySort('occupancy')}
                  className={`${thPadding} text-center font-semibold uppercase tracking-wider text-slate-100 dark:text-white cursor-pointer hover:bg-slate-700/60 dark:hover:bg-slate-800 transition-colors group`}
                  title="Sort by Occupancy Rate"
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>OCCUPANCY</span>
                    <span className="inline-flex items-center justify-center p-0.5 rounded">
                      {facilitySortKey === 'occupancy' ? (
                        facilitySortDir === 'asc' ? (
                          <ArrowUp className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        ) : (
                          <ArrowDown className="w-3.5 h-3.5 text-sky-400 bg-sky-950/60 p-0.5 rounded" />
                        )
                      ) : (
                        <ArrowUpDown className="w-3 h-3 text-slate-400/70 group-hover:text-sky-300" />
                      )}
                    </span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/60 dark:divide-slate-800">
              {sortedFacilityData.map((f, idx) => {
                const isHighlighted = highlightedFacilityId === f.id;
                const isExpanded = expandedFacilityIds.includes(f.id);
                const palette = COLD_STORAGE_ROW_PALETTE[idx % COLD_STORAGE_ROW_PALETTE.length];
                return (
                  <React.Fragment key={f.id}>
                    <tr
                      onClick={() => setHighlightedFacilityId(isHighlighted ? null : f.id)}
                      title="Click to highlight; click arrow or name to view item details"
                      className={`group relative cursor-pointer transition-colors duration-200 ease-in-out select-none ${palette.borderLeft} ${
                        isHighlighted
                          ? palette.highlight
                          : `${palette.bg} ${palette.hover}`
                      } print:hover:bg-transparent`}
                    >
                      <td className={`relative ${tdPadding} font-semibold text-slate-900 dark:text-white transition-colors`}>
                        {/* Active / Hover Row Indicator Bar */}
                        <div
                          className={`absolute left-0 top-0 bottom-0 w-1 transition-all duration-200 rounded-r ${
                            isHighlighted
                              ? `${palette.accentIndicator} opacity-100`
                              : `${palette.accentIndicator} opacity-0 group-hover:opacity-100`
                          } print:hidden`}
                        />
                        <div className="flex items-center gap-1.5 pl-0.5">
                          {/* Visual Expand/Collapse Icon Button */}
                          <button
                            type="button"
                            onClick={(e) => toggleExpandFacility(f.id, e)}
                            className={`p-1 rounded-md transition-all duration-150 cursor-pointer flex-shrink-0 ${
                              isExpanded
                                ? 'bg-sky-200/90 dark:bg-sky-900/80 text-sky-800 dark:text-sky-200 shadow-2xs'
                                : 'hover:bg-slate-200/70 dark:hover:bg-slate-700/60 text-slate-500 dark:text-slate-400'
                            }`}
                            title={isExpanded ? 'Collapse items view' : 'Expand detailed items view'}
                            aria-label={isExpanded ? 'Collapse items view' : 'Expand detailed items view'}
                          >
                            <ChevronDown
                              className={`w-3.5 h-3.5 transition-transform duration-200 ${
                                isExpanded ? 'transform rotate-180 text-sky-700 dark:text-sky-300' : ''
                              }`}
                            />
                          </button>
                          <span
                            onClick={(e) => toggleExpandFacility(f.id, e)}
                            className={`inline-block font-semibold rounded-md transition-all shadow-2xs group-hover:shadow-xs group-hover:translate-x-0.5 cursor-pointer ${badgePadding} ${palette.badge}`}
                          >
                            {f.name}
                          </span>
                        </div>
                      </td>
                      <td className={`${tdPadding} text-right font-medium text-slate-700 dark:text-slate-200`}>
                        {f.received > 0 ? f.received.toLocaleString() : '-'}
                      </td>
                      <td className={`${tdPadding} text-right font-medium text-slate-700 dark:text-slate-200`}>
                        {f.delivered > 0 ? f.delivered.toLocaleString() : '-'}
                      </td>
                      <td className={`${tdPadding} text-right font-bold ${palette.remainingText}`}>
                        <span className="inline-block group-hover:scale-105 transition-transform duration-150 origin-right">
                          {f.remaining > 0 ? f.remaining.toLocaleString() : '-'}
                        </span>
                      </td>
                      <td className={`${tdPadding} text-center`}>
                        {f.occupancy !== null ? (
                          <div className="inline-flex items-center justify-center gap-1">
                            <span
                              className={`inline-block px-2 py-0.2 rounded-full text-[10.5px] font-bold group-hover:ring-1 transition-all duration-150 ${getOccupancyColor(
                                f.occupancy
                              )}`}
                            >
                              {f.occupancy.toFixed(1)}%
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                    </tr>

                    {/* Detailed Item-Wise Breakdown Accordion Row */}
                    {isExpanded && (
                      <tr key={`${f.id}-expanded`} className="bg-slate-50/95 dark:bg-slate-900/95 border-b-2 border-sky-400/80 dark:border-sky-600/80">
                        <td colSpan={5} className="p-2 sm:p-3">
                          <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200/90 dark:border-slate-750 shadow-xs p-3 sm:p-4 text-left">
                            {(() => {
                              const items = getFacilityItemBreakdown(f.id);
                              const searchQuery = (facilitySearchMap[f.id] || '').trim().toLowerCase();
                              const displayedItems = searchQuery
                                ? items.filter(
                                    (it) =>
                                      it.varietyName.toLowerCase().includes(searchQuery) ||
                                      it.className.toLowerCase().includes(searchQuery) ||
                                      it.gradeName.toLowerCase().includes(searchQuery) ||
                                      it.srList.some((sr) => sr.toLowerCase().includes(searchQuery))
                                  )
                                : items;

                              return (
                                <>
                                  {/* Drawer / Sub-header with right-aligned search box and buttons */}
                                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-slate-200/80 dark:border-slate-750">
                                    <div className="flex items-center gap-2">
                                      <div className="p-1 rounded-md bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300">
                                        <Package className="w-3.5 h-3.5" />
                                      </div>
                                      <div>
                                        <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                                          ITEM-WISE STOCK BREAKDOWN — <span className="text-sky-700 dark:text-sky-400">{f.name}</span>
                                        </h4>
                                      </div>
                                    </div>

                                    {/* Right-aligned search box and icon-only export/print/close buttons */}
                                    <div className="flex items-center gap-1.5 ml-auto">
                                      {/* Search Box WITHOUT placeholder */}
                                      <div className="relative w-36 sm:w-48">
                                        <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none" />
                                        <input
                                          type="text"
                                          value={facilitySearchMap[f.id] || ''}
                                          onChange={(e) =>
                                            setFacilitySearchMap((prev) => ({ ...prev, [f.id]: e.target.value }))
                                          }
                                          placeholder=""
                                          className="w-full pl-7 pr-6 py-1 text-xs rounded-lg border border-slate-200 dark:border-slate-750 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-sky-500 shadow-2xs"
                                          aria-label="Search facility stock"
                                        />
                                        {facilitySearchMap[f.id] && (
                                          <button
                                            type="button"
                                            onClick={() =>
                                              setFacilitySearchMap((prev) => ({ ...prev, [f.id]: '' }))
                                            }
                                            className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer"
                                            title="CLEAR SEARCH"
                                            aria-label="CLEAR SEARCH"
                                          >
                                            <X className="w-3 h-3" />
                                          </button>
                                        )}
                                      </div>

                                      {/* Excel export button - icon only */}
                                      <button
                                        type="button"
                                        onClick={() => handleExportFacilityExcel(f.name, displayedItems)}
                                        className="p-1.5 rounded-lg text-emerald-700 dark:text-emerald-300 bg-white hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800/80 shadow-2xs transition-colors cursor-pointer"
                                        title="EXPORT TO EXCEL"
                                        aria-label="EXPORT TO EXCEL"
                                      >
                                        <Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                                      </button>

                                      {/* PDF export button - icon only */}
                                      <button
                                        type="button"
                                        onClick={() => handleExportFacilityPdf(f.name, displayedItems)}
                                        className="p-1.5 rounded-lg text-rose-700 dark:text-rose-300 bg-white hover:bg-rose-50 dark:bg-slate-800 dark:hover:bg-rose-950/60 border border-rose-300 dark:border-rose-800/80 shadow-2xs transition-colors cursor-pointer"
                                        title="EXPORT TO PDF"
                                        aria-label="EXPORT TO PDF"
                                      >
                                        <FileText className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                                      </button>

                                      {/* Print button - icon only */}
                                      <button
                                        type="button"
                                        onClick={() => handlePrintFacility(f.name, displayedItems)}
                                        className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 bg-white hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-300 dark:border-slate-700 shadow-2xs transition-colors cursor-pointer"
                                        title="PRINT"
                                        aria-label="PRINT"
                                      >
                                        <Printer className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400" />
                                      </button>

                                      {/* Close Button */}
                                      <button
                                        type="button"
                                        onClick={(e) => toggleExpandFacility(f.id, e)}
                                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                                        title="COLLAPSE ITEMS VIEW"
                                        aria-label="COLLAPSE ITEMS VIEW"
                                      >
                                        <X className="w-4 h-4" />
                                      </button>
                                    </div>
                                  </div>

                                  {/* Items Table */}
                                  {displayedItems.length === 0 ? (
                                    <div className="py-4 text-center text-xs text-slate-500 dark:text-slate-400 font-medium uppercase">
                                      {items.length === 0
                                        ? `NO ACTIVE POTATO SEED ITEMS CURRENTLY STORED IN ${f.name.toUpperCase()}.`
                                        : 'NO ITEMS FOUND MATCHING SEARCH QUERY.'}
                                    </div>
                                   ) : (
                                    (() => {
                                      const sortConfig = breakdownSortMap[f.id] || { key: 'remaining', dir: 'desc' };
                                      const sortedItems = sortData(displayedItems, sortConfig.key, sortConfig.dir);

                                      // Pagination for breakdown items
                                      const pageConfig = breakdownPageMap[f.id] || { page: 1, pageSize: 15 };
                                      const totalBreakdownPages = Math.ceil(sortedItems.length / pageConfig.pageSize) || 1;
                                      const currentBreakdownPage = Math.min(pageConfig.page, totalBreakdownPages);
                                      const paginatedItems = sortedItems.slice(
                                        (currentBreakdownPage - 1) * pageConfig.pageSize,
                                        currentBreakdownPage * pageConfig.pageSize
                                      );

                                      const totalItemsRemaining = displayedItems.reduce((sum, item) => sum + item.remaining, 0);
                                      const totalItemsDelivered = displayedItems.reduce((sum, item) => sum + item.delivered, 0);
                                      const totalItemsReceived = displayedItems.reduce((sum, item) => sum + item.received, 0);
                                      const totalItemsMt = displayedItems.reduce((sum, item) => sum + item.totalMt, 0);

                                      const renderBreakdownSortIcon = (key: string) => {
                                        if (sortConfig.key !== key) {
                                          return <ArrowUpDown className="w-3 h-3 text-slate-400/60 group-hover:text-sky-600 dark:group-hover:text-sky-300" />;
                                        }
                                        return sortConfig.dir === 'asc' ? (
                                          <ArrowUp className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 bg-sky-100 dark:bg-sky-900/60 p-0.5 rounded" />
                                        ) : (
                                          <ArrowDown className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 bg-sky-100 dark:bg-sky-900/60 p-0.5 rounded" />
                                        );
                                      };

                                      return (
                                        <div className="overflow-x-auto border border-slate-200 dark:border-slate-750 rounded-lg">
                                          <table className="w-full text-xs text-left">
                                            <thead className="bg-slate-100/90 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700 text-[11px] select-none">
                                              <tr className="h-8">
                                                <th
                                                  onClick={() => handleBreakdownSort(f.id, 'varietyName')}
                                                  className={`${innerThPadding} uppercase tracking-wider cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/60 transition-colors group`}
                                                >
                                                  <div className="flex items-center gap-1.5">
                                                    <span>POTATO VARIETY</span>
                                                    {renderBreakdownSortIcon('varietyName')}
                                                  </div>
                                                </th>
                                                <th
                                                  onClick={() => handleBreakdownSort(f.id, 'className')}
                                                  className={`${innerThPadding} uppercase tracking-wider cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/60 transition-colors group`}
                                                >
                                                  <div className="flex items-center gap-1.5">
                                                    <span>CLASS & GRADE</span>
                                                    {renderBreakdownSortIcon('className')}
                                                  </div>
                                                </th>
                                                <th
                                                  onClick={() => handleBreakdownSort(f.id, 'received')}
                                                  className={`${innerThPadding} text-right uppercase tracking-wider cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/60 transition-colors group`}
                                                >
                                                  <div className="flex items-center justify-end gap-1.5">
                                                    <span>RECEIVED</span>
                                                    {renderBreakdownSortIcon('received')}
                                                  </div>
                                                </th>
                                                <th
                                                  onClick={() => handleBreakdownSort(f.id, 'delivered')}
                                                  className={`${innerThPadding} text-right uppercase tracking-wider cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/60 transition-colors group`}
                                                >
                                                  <div className="flex items-center justify-end gap-1.5">
                                                    <span>DELIVERED</span>
                                                    {renderBreakdownSortIcon('delivered')}
                                                  </div>
                                                </th>
                                                <th
                                                  onClick={() => handleBreakdownSort(f.id, 'remaining')}
                                                  className={`${innerThPadding} text-right uppercase tracking-wider cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/60 transition-colors group`}
                                                >
                                                  <div className="flex items-center justify-end gap-1.5">
                                                    <span>REMAINING STOCK</span>
                                                    {renderBreakdownSortIcon('remaining')}
                                                  </div>
                                                </th>
                                                <th
                                                  onClick={() => handleBreakdownSort(f.id, 'totalMt')}
                                                  className={`${innerThPadding} text-right uppercase tracking-wider cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/60 transition-colors group`}
                                                >
                                                  <div className="flex items-center justify-end gap-1.5">
                                                    <span>TOTAL MT</span>
                                                    {renderBreakdownSortIcon('totalMt')}
                                                  </div>
                                                </th>
                                                <th className={`${innerThPadding} uppercase tracking-wider`}>
                                                  SR NUMBERS
                                                </th>
                                              </tr>
                                            </thead>
                                            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-[11.5px]">
                                              {paginatedItems.map((item) => (
                                                <tr key={item.key} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                                                  <td className={`${innerTdPadding} font-semibold text-slate-900 dark:text-white`}>
                                                    <span className="inline-flex items-center px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-750 font-bold">
                                                      {item.varietyName}
                                                    </span>
                                                  </td>
                                                  <td className={`${innerTdPadding} text-slate-600 dark:text-slate-300`}>
                                                    <div className="flex items-center gap-1.5">
                                                      <span className="font-medium text-slate-800 dark:text-slate-200">{item.className}</span>
                                                      {item.gradeName && item.gradeName !== '-' && (
                                                        <>
                                                          <span className="text-slate-400">·</span>
                                                          <span className="text-slate-600 dark:text-slate-400">{item.gradeName}</span>
                                                        </>
                                                      )}
                                                    </div>
                                                  </td>
                                                  <td className={`${innerTdPadding} text-right font-medium text-slate-700 dark:text-slate-300`}>
                                                    {item.received > 0 ? item.received.toLocaleString() : '-'}
                                                  </td>
                                                  <td className={`${innerTdPadding} text-right font-medium text-slate-700 dark:text-slate-300`}>
                                                    {item.delivered > 0 ? item.delivered.toLocaleString() : '-'}
                                                  </td>
                                                  <td className={`${innerTdPadding} text-right font-bold text-sky-700 dark:text-sky-300`}>
                                                    {item.remaining > 0 ? item.remaining.toLocaleString() : '-'}
                                                  </td>
                                                  <td className={`${innerTdPadding} text-right font-bold text-emerald-600 dark:text-emerald-400`}>
                                                    {item.totalMt > 0 ? item.totalMt.toFixed(2) : '-'}
                                                  </td>
                                                  <td className={`${innerTdPadding}`}>
                                                    <div className="flex flex-wrap items-center gap-1">
                                                      {item.srList.length > 0 ? (
                                                        item.srList.map((sr) => (
                                                          <span
                                                            key={sr}
                                                            className="inline-flex items-center text-[10.5px] font-mono font-medium px-1.5 py-0.2 rounded bg-sky-50 text-sky-700 dark:bg-sky-950/80 dark:text-sky-300 border border-sky-200/70 dark:border-sky-800"
                                                          >
                                                            {sr}
                                                          </span>
                                                        ))
                                                      ) : (
                                                        <span className="text-slate-400">-</span>
                                                      )}
                                                    </div>
                                                  </td>
                                                </tr>
                                              ))}
                                            </tbody>
                                            <tfoot className="bg-slate-100/90 dark:bg-slate-800 font-bold border-t-2 border-slate-300 dark:border-slate-750 text-[11px] text-slate-900 dark:text-white">
                                              <tr>
                                                <td colSpan={2} className={`${innerTdPadding} uppercase tracking-wider`}>
                                                  FACILITY SUBTOTAL ({displayedItems.length} ITEMS)
                                                </td>
                                                <td className={`${innerTdPadding} text-right font-bold`}>
                                                  {totalItemsReceived > 0 ? totalItemsReceived.toLocaleString() : '-'}
                                                </td>
                                                <td className={`${innerTdPadding} text-right font-bold`}>
                                                  {totalItemsDelivered > 0 ? totalItemsDelivered.toLocaleString() : '-'}
                                                </td>
                                                <td className={`${innerTdPadding} text-right font-black text-sky-700 dark:text-sky-300`}>
                                                  {totalItemsRemaining > 0 ? totalItemsRemaining.toLocaleString() : '-'}
                                                </td>
                                                <td className={`${innerTdPadding} text-right font-black text-emerald-600 dark:text-emerald-400`}>
                                                  {totalItemsMt > 0 ? totalItemsMt.toFixed(2) : '-'}
                                                </td>
                                                <td className={`${innerTdPadding}`}></td>
                                              </tr>
                                            </tfoot>
                                          </table>

                                          {/* Pagination for Breakdown Items */}
                                          {sortedItems.length > 10 && (
                                            <TablePagination
                                              currentPage={currentBreakdownPage}
                                              totalPages={totalBreakdownPages}
                                              pageSize={pageConfig.pageSize}
                                              totalItems={sortedItems.length}
                                              pageSizeOptions={[10, 25, 50]}
                                              onPageChange={(p) =>
                                                setBreakdownPageMap((prev) => ({
                                                  ...prev,
                                                  [f.id]: { page: p, pageSize: pageConfig.pageSize },
                                                }))
                                              }
                                              onPageSizeChange={(ps) =>
                                                setBreakdownPageMap((prev) => ({
                                                  ...prev,
                                                  [f.id]: { page: 1, pageSize: ps },
                                                }))
                                              }
                                            />
                                          )}
                                        </div>
                                      );
                                    })()
                                  )}
                                </>
                              );
                            })()}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-100 dark:bg-slate-800/90 font-bold border-t-2 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white print:bg-slate-100 print:text-black text-xs">
              <tr>
                <td className={`${totalPadding} uppercase tracking-wider`}>
                  TOTAL
                </td>
                <td className={`${totalPadding} text-right`}>
                  {totals.totalReceived > 0 ? totals.totalReceived.toLocaleString() : '-'}
                </td>
                <td className={`${totalPadding} text-right`}>
                  {totals.totalDelivered > 0 ? totals.totalDelivered.toLocaleString() : '-'}
                </td>
                <td className={`${totalPadding} text-right text-sky-700 dark:text-sky-300 font-black`}>
                  {totals.totalRemaining > 0 ? totals.totalRemaining.toLocaleString() : '-'}
                </td>
                <td className={`${totalPadding} text-center`}>
                  {totals.overallOccupancy !== null ? (
                    <span
                      className={`inline-block px-2 py-0.2 rounded-full text-[10.5px] font-bold ${getOccupancyColor(
                        totals.overallOccupancy
                      )}`}
                    >
                      {totals.overallOccupancy.toFixed(1)}%
                    </span>
                  ) : (
                    <span className="text-slate-400">-</span>
                  )}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      {/* Quick Add Cold Storage Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="ADD COLD STORAGE FACILITY"
        subtitle="Register a new storage facility to track capacity and inventory"
        maxWidth="lg"
      >
        <form onSubmit={handleSaveStorage} className="space-y-4">
          {formError && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs rounded-xl">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                FACILITY CODE *
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. CS-4 or VORSHA"
                required
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white uppercase font-mono focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                CAPACITY (BAGS) *
              </label>
              <input
                type="number"
                min="0"
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                placeholder="100000"
                required
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
              FACILITY NAME *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Diamond Cold Storage Ltd."
              required
              className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                LOCATION / ADDRESS *
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Sadar Road, Rangpur"
                required
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                DISTRICT
              </label>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="e.g. Rangpur"
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                RENT PER BAG (BDT)
              </label>
              <input
                type="number"
                min="0"
                value={rentPerBag}
                onChange={(e) => setRentPerBag(Number(e.target.value))}
                placeholder="280"
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                CONTACT PERSON
              </label>
              <input
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="e.g. Md. Kabir Hossain"
                className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer uppercase"
            >
              CANCEL
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors cursor-pointer uppercase"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>ADD FACILITY</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
