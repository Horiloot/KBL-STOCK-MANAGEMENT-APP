import { z, ZodError } from 'zod';

export const stockEntrySchema = z.object({
  coldStorageId: z.string().min(1, 'Cold Storage facility is required'),
  date: z.string().min(1, 'Date is required'),
  entryNo: z.string().optional(),
  kblChallanNo: z.string().min(1, 'KBL Challan number is required'),
  srNo: z.string().min(1, 'SR Number is required'),
  varietyId: z.string().min(1, 'Variety is required'),
  classId: z.string().min(1, 'Seed Class is required'),
  gradeId: z.string().min(1, 'Grade is required'),
  productionBlockId: z.string().optional(),
  potatoTypeId: z.string().optional(),
  sackQuantity: z.number().positive('Sack Quantity must be greater than zero'),
  kgPerBag: z.number().positive('KG Per Bag must be greater than zero'),
  remarks: z.string().optional(),
});

export const stockTransactionSchema = stockEntrySchema;

export const deliveryEntrySchema = z.object({
  date: z.string().min(1, 'Date is required'),
  deliveryNo: z.string().min(1, 'Delivery number is required'),
  deliveryReference: z.string().optional(),
  customerReceiver: z.string().min(1, 'Receiver / Client name is required'),
  vehicleNo: z.string().optional(),
  driverName: z.string().optional(),
  coldStorageId: z.string().min(1, 'Cold Storage facility is required'),
  varietyId: z.string().min(1, 'Variety is required'),
  classId: z.string().min(1, 'Seed Class is required'),
  gradeId: z.string().min(1, 'Grade is required'),
  productionBlockId: z.string().optional(),
  potatoTypeId: z.string().optional(),
  sackQuantity: z.number().positive('Dispatch bags must be greater than zero'),
  kgPerBag: z.number().positive('KG Per Bag must be positive'),
  remarks: z.string().optional(),
});

export const deliveryTransactionSchema = deliveryEntrySchema;

export function extractZodFieldErrors(error: ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  if (!error || !error.issues) return errors;

  for (const issue of error.issues) {
    const fieldName = issue.path[0];
    if (fieldName && typeof fieldName === 'string' && !errors[fieldName]) {
      errors[fieldName] = issue.message;
    }
  }
  return errors;
}
