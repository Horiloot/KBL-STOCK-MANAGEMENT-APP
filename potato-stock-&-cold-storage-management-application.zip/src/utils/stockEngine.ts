import {
  StockTransaction,
  DeliveryTransaction,
  ColdStorage,
  Variety,
  SeedClass,
  Grade,
  PotatoType,
  RentPayment,
  FilterState,
} from '../types';

export interface MatrixColumn {
  key: string;
  label: string;
}

export type MatrixRowType = 'standard' | 'subtotal' | 'single' | 'grandtotal' | 'gap';

export interface MatrixRow {
  id: string;
  label: string;
  type: MatrixRowType;
  values: Record<string, number>;
  total: number;
}

export interface LiveStockMatrixResult {
  columns: MatrixColumn[];
  rows: MatrixRow[];
  grandTotal: number;
}

export function getVarietyKey(varietyName: string, varietyCode: string): string {
  const name = (varietyName || '').toUpperCase();
  const code = (varietyCode || '').toUpperCase();
  if (code === 'AST' || name.includes('ASTERIX')) return 'ASTERIX';
  if (code === 'DIA' || name.includes('DIAMANT')) return 'DIAMANT';
  if (code === 'GRA' || name.includes('GRANOLA')) return 'GRANOLA';
  if (code === 'SUN' || name.includes('SUN-SHINE') || name.includes('SUNSHINE')) return 'SUN-SHINE';
  return 'OTHER';
}

export function calculateLiveStockMatrix(
  stockTransactions: StockTransaction[],
  deliveryTransactions: DeliveryTransaction[],
  varieties: Variety[],
  seedClasses: SeedClass[],
  grades: Grade[],
  potatoTypes: PotatoType[],
  filters?: FilterState
): LiveStockMatrixResult {
  const columns: MatrixColumn[] = [
    { key: 'ASTERIX', label: 'Asterix' },
    { key: 'DIAMANT', label: 'Diamant' },
    { key: 'GRANOLA', label: 'Granola' },
    { key: 'SUN-SHINE', label: 'Sun-Shine' },
  ];

  // Filter transactions
  const filteredStock = stockTransactions.filter((s) => {
    if (filters?.coldStorageId && s.coldStorageId !== filters.coldStorageId) return false;
    return s.status === 'approved' || !s.status;
  });

  const filteredDelivery = deliveryTransactions.filter((d) => {
    if (filters?.coldStorageId && d.coldStorageId !== filters.coldStorageId) return false;
    return true;
  });

  // Helper to calculate remaining bags for matching criteria
  const getNetBalance = (
    predicate: (clsCode: string, clsName: string, grdCode: string, grdName: string, typCode: string, typName: string) => boolean,
    varietyKey: string
  ): number => {
    const inbound = filteredStock
      .filter((s) => {
        const v = varieties.find((item) => item.id === s.varietyId);
        const vKey = getVarietyKey(v?.name || '', v?.code || '');
        if (vKey !== varietyKey) return false;

        const c = seedClasses.find((item) => item.id === s.classId);
        const g = grades.find((item) => item.id === s.gradeId);
        const t = potatoTypes.find((item) => item.id === s.potatoTypeId);

        return predicate(
          (c?.code || '').toUpperCase(),
          (c?.name || '').toLowerCase(),
          (g?.code || '').toUpperCase(),
          (g?.name || '').toLowerCase(),
          (t?.code || '').toUpperCase(),
          (t?.name || '').toLowerCase()
        );
      })
      .reduce((acc, s) => acc + s.sackQuantity, 0);

    const outbound = filteredDelivery
      .filter((d) => {
        const v = varieties.find((item) => item.id === d.varietyId);
        const vKey = getVarietyKey(v?.name || '', v?.code || '');
        if (vKey !== varietyKey) return false;

        const c = seedClasses.find((item) => item.id === d.classId);
        const g = grades.find((item) => item.id === d.gradeId);
        const t = potatoTypes.find((item) => item.id === d.potatoTypeId);

        return predicate(
          (c?.code || '').toUpperCase(),
          (c?.name || '').toLowerCase(),
          (g?.code || '').toUpperCase(),
          (g?.name || '').toLowerCase(),
          (t?.code || '').toUpperCase(),
          (t?.name || '').toLowerCase()
        );
      })
      .reduce((acc, d) => acc + d.sackQuantity, 0);

    return Math.max(0, inbound - outbound);
  };

  const createRow = (
    id: string,
    label: string,
    type: MatrixRowType,
    predicate: (clsCode: string, clsName: string, grdCode: string, grdName: string, typCode: string, typName: string) => boolean
  ): MatrixRow => {
    const values: Record<string, number> = {};
    let total = 0;

    columns.forEach((col) => {
      const val = getNetBalance(predicate, col.key);
      values[col.key] = val;
      total += val;
    });

    return {
      id,
      label,
      type,
      values,
      total,
    };
  };

  const createSubtotalRow = (id: string, label: string, childRows: MatrixRow[]): MatrixRow => {
    const values: Record<string, number> = {};
    let total = 0;

    columns.forEach((col) => {
      const sum = childRows.reduce((acc, r) => acc + (r.values[col.key] || 0), 0);
      values[col.key] = sum;
      total += sum;
    });

    return {
      id,
      label,
      type: 'subtotal',
      values,
      total,
    };
  };

  // Group 1: Certify
  const certifyA = createRow(
    'certify-a',
    'CERTIFY A',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'CS' || cName.includes('certif')) && (gCode === 'A' || gName === 'grade a')
  );
  const certifyB = createRow(
    'certify-b',
    'CERTIFY B',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'CS' || cName.includes('certif')) && (gCode === 'B' || gName === 'grade b')
  );
  const certifyUS = createRow(
    'certify-us',
    'CERTIFY US',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'CS' || cName.includes('certif')) &&
      (gCode === 'US' || gName.includes('under size') || gName.includes('us'))
  );
  const totalCertify = createSubtotalRow('total-certify', 'TOTAL CERTIFY', [
    certifyA,
    certifyB,
    certifyUS,
  ]);

  // Group 2: Foundation
  const foundationA = createRow(
    'foundation-a',
    'FOUNDATION A',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'FS' || (cName.includes('foundation') && !cName.includes('pre'))) &&
      (gCode === 'A' || gName === 'grade a')
  );
  const foundationB = createRow(
    'foundation-b',
    'FOUNDATION B',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'FS' || (cName.includes('foundation') && !cName.includes('pre'))) &&
      (gCode === 'B' || gName === 'grade b')
  );
  const foundationUS = createRow(
    'foundation-us',
    'FOUNDATION US',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'FS' || (cName.includes('foundation') && !cName.includes('pre'))) &&
      (gCode === 'US' || gName.includes('under size') || gName.includes('us'))
  );
  const foundationOS = createRow(
    'foundation-os',
    'FOUNDATION OS',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'FS' || (cName.includes('foundation') && !cName.includes('pre'))) &&
      (gCode === 'OS' || gName.includes('over size') || gName.includes('os'))
  );
  const totalFoundation = createSubtotalRow('total-foundation', 'TOTAL FOUNDATION', [
    foundationA,
    foundationB,
    foundationUS,
    foundationOS,
  ]);

  // Group 3: Mini Tuber (Single)
  const totalMiniTuber = createRow(
    'total-mini-tuber',
    'TOTAL MINI TUBER',
    'single',
    (cCode, cName) =>
      cCode === 'MT' || cCode === 'BRD' || cName.includes('mini tuber') || cName.includes('breeder')
  );

  // Group 4: Table Potato (Single)
  const totalTablePotato = createRow(
    'total-table-potato',
    'TOTAL TABLE POTATO (TP)',
    'single',
    (_, __, gCode, gName, tCode, tName) =>
      gCode === 'TP' || gName.includes('tp') || tCode === 'TABLE' || tName.includes('table')
  );

  // Group 5: Pre-Foundation
  const preFoundationA = createRow(
    'pre-foundation-a',
    'PRE-FOUNDATION A',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'PF' || cCode === 'PFS' || cName.includes('pre')) &&
      (gCode === 'A' || gName === 'grade a')
  );
  const preFoundationB = createRow(
    'pre-foundation-b',
    'PRE-FOUNDATION B',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'PF' || cCode === 'PFS' || cName.includes('pre')) &&
      (gCode === 'B' || gName === 'grade b')
  );
  const preFoundationUS = createRow(
    'pre-foundation-us',
    'PRE-FOUNDATION US',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'PF' || cCode === 'PFS' || cName.includes('pre')) &&
      (gCode === 'US' || gName.includes('under size') || gName.includes('us'))
  );
  const totalPreFoundation = createSubtotalRow('total-pre-foundation', 'TOTAL PRE-FOUNDATION', [
    preFoundationA,
    preFoundationB,
    preFoundationUS,
  ]);

  // Group 6: TLS
  const tlsA = createRow(
    'tls-a',
    'TLS A',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'TLS' || cName.includes('tls')) && (gCode === 'A' || gName === 'grade a')
  );
  const tlsB = createRow(
    'tls-b',
    'TLS B',
    'standard',
    (cCode, cName, gCode, gName) =>
      (cCode === 'TLS' || cName.includes('tls')) && (gCode === 'B' || gName === 'grade b')
  );
  const totalTls = createSubtotalRow('total-tls', 'TOTAL TLS', [tlsA, tlsB]);

  // Group 7: Non Traceable with SR (Single)
  const totalNonTraceable = createRow(
    'total-non-traceable',
    'TOTAL NON TRACEABLE WITH SR',
    'single',
    (cCode, cName) =>
      cCode === 'NT' || cName.includes('non traceable') || cName.includes('non-traceable')
  );

  // Grand Total calculation
  const grandTotalValues: Record<string, number> = {};
  let grandTotal = 0;

  columns.forEach((col) => {
    const colSum =
      totalCertify.values[col.key] +
      totalFoundation.values[col.key] +
      totalMiniTuber.values[col.key] +
      totalTablePotato.values[col.key] +
      totalPreFoundation.values[col.key] +
      totalTls.values[col.key] +
      totalNonTraceable.values[col.key];

    grandTotalValues[col.key] = colSum;
    grandTotal += colSum;
  });

  const grandTotalRow: MatrixRow = {
    id: 'grand-total',
    label: 'GRAND TOTAL',
    type: 'grandtotal',
    values: grandTotalValues,
    total: grandTotal,
  };

  const rows: MatrixRow[] = [
    certifyA,
    certifyB,
    certifyUS,
    totalCertify,
    { id: 'gap-1', label: '', type: 'gap', values: {}, total: 0 },
    foundationA,
    foundationB,
    foundationUS,
    foundationOS,
    totalFoundation,
    { id: 'gap-2', label: '', type: 'gap', values: {}, total: 0 },
    totalMiniTuber,
    { id: 'gap-3', label: '', type: 'gap', values: {}, total: 0 },
    totalTablePotato,
    { id: 'gap-4', label: '', type: 'gap', values: {}, total: 0 },
    preFoundationA,
    preFoundationB,
    preFoundationUS,
    totalPreFoundation,
    { id: 'gap-5', label: '', type: 'gap', values: {}, total: 0 },
    tlsA,
    tlsB,
    totalTls,
    { id: 'gap-6', label: '', type: 'gap', values: {}, total: 0 },
    totalNonTraceable,
    { id: 'gap-7', label: '', type: 'gap', values: {}, total: 0 },
    grandTotalRow,
  ];

  return {
    columns,
    rows,
    grandTotal,
  };
}

export interface RentSummaryItem {
  coldStorageId: string;
  code: string;
  coldStorageName: string;
  totalBags: number;
  deliveredBags: number;
  remainingBags: number;
  rentPerBag: number;
  storageDurationDays: number;
  totalRent: number;
  totalStorageBags: number;
  totalRentAmount: number;
  rentPaidAmount: number;
  rentDueAmount: number;
  paymentStatus: 'Paid in Full' | 'Partial' | 'Pending';
}

export type RentSummaryResult = RentSummaryItem[] & {
  items: RentSummaryItem[];
  totalRentAmount: number;
  totalPaidAmount: number;
  totalDueAmount: number;
};

export function calculateRentSummary(
  coldStorages: ColdStorage[],
  stockTransactions: StockTransaction[],
  deliveryTransactions: DeliveryTransaction[],
  paymentsOrSeasonStart?: RentPayment[] | string,
  seasonEndStr?: string
): RentSummaryResult {
  const rentPayments: RentPayment[] = Array.isArray(paymentsOrSeasonStart)
    ? paymentsOrSeasonStart
    : [];

  let durationDays = 270;
  if (typeof paymentsOrSeasonStart === 'string' && seasonEndStr) {
    try {
      const start = new Date(paymentsOrSeasonStart).getTime();
      const end = new Date(seasonEndStr).getTime();
      durationDays = Math.max(1, Math.round((end - start) / (1000 * 3600 * 24)));
    } catch {
      durationDays = 270;
    }
  }

  let overallRent = 0;
  let overallPaid = 0;
  let overallDue = 0;

  const items: RentSummaryItem[] = coldStorages.map((cs) => {
    // Total bags received into this facility
    const totalBags = stockTransactions
      .filter((s) => s.coldStorageId === cs.id)
      .reduce((sum, s) => sum + (s.sackQuantity || 0), 0);

    const deliveredBags = deliveryTransactions
      .filter((d) => d.coldStorageId === cs.id)
      .reduce((sum, d) => sum + (d.sackQuantity || 0), 0);

    const remainingBags = Math.max(0, totalBags - deliveredBags);
    const rentRate = cs.rentPerBag || 280;
    const totalRent = totalBags * rentRate;

    // Total payments made to this facility
    const rentPaidAmount = rentPayments
      .filter((p) => p.coldStorageId === cs.id)
      .reduce((sum, p) => sum + (p.amount ?? p.amountPaid ?? 0), 0);

    const rentDueAmount = Math.max(0, totalRent - rentPaidAmount);

    let paymentStatus: 'Paid in Full' | 'Partial' | 'Pending' = 'Pending';
    if (rentPaidAmount >= totalRent && totalRent > 0) {
      paymentStatus = 'Paid in Full';
    } else if (rentPaidAmount > 0) {
      paymentStatus = 'Partial';
    }

    overallRent += totalRent;
    overallPaid += rentPaidAmount;
    overallDue += rentDueAmount;

    return {
      coldStorageId: cs.id,
      code: cs.code || cs.id.slice(0, 4).toUpperCase(),
      coldStorageName: cs.name,
      totalBags,
      deliveredBags,
      remainingBags,
      rentPerBag: rentRate,
      storageDurationDays: durationDays,
      totalRent,
      totalStorageBags: totalBags,
      totalRentAmount: totalRent,
      rentPaidAmount,
      rentDueAmount,
      paymentStatus,
    };
  });

  const result = Object.assign(items, {
    items,
    totalRentAmount: overallRent,
    totalPaidAmount: overallPaid,
    totalDueAmount: overallDue,
  });

  return result as RentSummaryResult;
}

export interface OverallMetricsResult {
  totalReceivedBags: number;
  totalDeliveredBags: number;
  remainingBags: number;
  remainingKg: number;
  remainingMt: number;
  occupancyRate: number;
  totalStorages: number;
}

export function calculateOverallMetrics(
  stockTransactions: StockTransaction[],
  deliveryTransactions: DeliveryTransaction[],
  coldStorages: ColdStorage[],
  filters?: FilterState
): OverallMetricsResult {
  const filteredStock = stockTransactions.filter((s) => {
    if (filters?.coldStorageId && s.coldStorageId !== filters.coldStorageId) return false;
    return s.status === 'approved' || !s.status;
  });

  const filteredDelivery = deliveryTransactions.filter((d) => {
    if (filters?.coldStorageId && d.coldStorageId !== filters.coldStorageId) return false;
    return true;
  });

  const totalReceivedBags = filteredStock.reduce((sum, s) => sum + (s.sackQuantity || 0), 0);
  const totalDeliveredBags = filteredDelivery.reduce((sum, d) => sum + (d.sackQuantity || 0), 0);
  const remainingBags = Math.max(0, totalReceivedBags - totalDeliveredBags);

  const totalReceivedKg = filteredStock.reduce((sum, s) => sum + (s.totalKg || s.sackQuantity * 50), 0);
  const totalDeliveredKg = filteredDelivery.reduce((sum, d) => sum + (d.totalKg || d.sackQuantity * 50), 0);
  const remainingKg = Math.max(0, totalReceivedKg - totalDeliveredKg);
  const remainingMt = Number((remainingKg / 1000).toFixed(2));

  // Occupancy rate calculation
  const targetStorages = filters?.coldStorageId
    ? coldStorages.filter((c) => c.id === filters.coldStorageId)
    : coldStorages;

  const totalCapacity = targetStorages.reduce((sum, c) => sum + (c.capacity || 0), 0);
  const occupancyRate = totalCapacity > 0 ? (remainingBags / totalCapacity) * 100 : 0;

  return {
    totalReceivedBags,
    totalDeliveredBags,
    remainingBags,
    remainingKg,
    remainingMt,
    occupancyRate: Number(occupancyRate.toFixed(1)),
    totalStorages: targetStorages.length,
  };
}

export interface DimensionStockSummary {
  id: string;
  label: string;
  code?: string;
  totalReceivedBags: number;
  totalDeliveredBags: number;
  remainingBags: number;
}

export function getStockSummaryByDimension(
  dimension: 'coldStorage' | 'variety' | 'grade' | 'class' | 'potatoType',
  stockTransactions: StockTransaction[],
  deliveryTransactions: DeliveryTransaction[],
  dimensionItems: Array<{ id: string; name: string; code?: string }>,
  filters?: FilterState
): DimensionStockSummary[] {
  return dimensionItems.map((item) => {
    const received = stockTransactions
      .filter((s) => {
        if (filters?.coldStorageId && s.coldStorageId !== filters.coldStorageId) return false;
        if (dimension === 'coldStorage') return s.coldStorageId === item.id;
        if (dimension === 'variety') return s.varietyId === item.id;
        if (dimension === 'grade') return s.gradeId === item.id;
        if (dimension === 'class') return s.classId === item.id;
        if (dimension === 'potatoType') return s.potatoTypeId === item.id;
        return false;
      })
      .reduce((sum, s) => sum + (s.sackQuantity || 0), 0);

    const delivered = deliveryTransactions
      .filter((d) => {
        if (filters?.coldStorageId && d.coldStorageId !== filters.coldStorageId) return false;
        if (dimension === 'coldStorage') return d.coldStorageId === item.id;
        if (dimension === 'variety') return d.varietyId === item.id;
        if (dimension === 'grade') return d.gradeId === item.id;
        if (dimension === 'class') return d.classId === item.id;
        if (dimension === 'potatoType') return d.potatoTypeId === item.id;
        return false;
      })
      .reduce((sum, d) => sum + (d.sackQuantity || 0), 0);

    const remaining = Math.max(0, received - delivered);

    return {
      id: item.id,
      label: item.name,
      code: item.code,
      totalReceivedBags: received,
      totalDeliveredBags: delivered,
      remainingBags: remaining,
    };
  });
}

export interface StockBalanceMatrixItem {
  coldStorageId: string;
  coldStorageName: string;
  varietyId: string;
  varietyName: string;
  classId: string;
  className: string;
  gradeId: string;
  gradeName: string;
  inboundBags: number;
  inboundMt: number;
  deliveredBags: number;
  deliveredMt: number;
  balanceBags: number;
  balanceKg: number;
  balanceMt: number;
}

export function calculateStockBalanceMatrix(
  stockTransactions: StockTransaction[],
  deliveryTransactions: DeliveryTransaction[],
  coldStorages: ColdStorage[],
  varieties: Variety[],
  seedClasses: SeedClass[],
  grades: Grade[]
): StockBalanceMatrixItem[] {
  const lotMap: Record<
    string,
    {
      coldStorageId: string;
      varietyId: string;
      classId: string;
      gradeId: string;
      inboundBags: number;
      inboundKg: number;
      inboundMt: number;
      deliveredBags: number;
      deliveredKg: number;
      deliveredMt: number;
    }
  > = {};

  stockTransactions.forEach((s) => {
    const key = `${s.coldStorageId}_${s.varietyId}_${s.classId}_${s.gradeId}`;
    if (!lotMap[key]) {
      lotMap[key] = {
        coldStorageId: s.coldStorageId,
        varietyId: s.varietyId,
        classId: s.classId,
        gradeId: s.gradeId,
        inboundBags: 0,
        inboundKg: 0,
        inboundMt: 0,
        deliveredBags: 0,
        deliveredKg: 0,
        deliveredMt: 0,
      };
    }
    lotMap[key].inboundBags += s.sackQuantity;
    lotMap[key].inboundKg += s.totalKg;
    lotMap[key].inboundMt += s.totalMt;
  });

  deliveryTransactions.forEach((d) => {
    const key = `${d.coldStorageId}_${d.varietyId}_${d.classId}_${d.gradeId}`;
    if (!lotMap[key]) {
      lotMap[key] = {
        coldStorageId: d.coldStorageId,
        varietyId: d.varietyId,
        classId: d.classId,
        gradeId: d.gradeId,
        inboundBags: 0,
        inboundKg: 0,
        inboundMt: 0,
        deliveredBags: 0,
        deliveredKg: 0,
        deliveredMt: 0,
      };
    }
    lotMap[key].deliveredBags += d.sackQuantity;
    lotMap[key].deliveredKg += d.totalKg;
    lotMap[key].deliveredMt += d.totalMt;
  });

  return Object.values(lotMap).map((lot) => {
    const storage = coldStorages.find((c) => c.id === lot.coldStorageId)?.name || lot.coldStorageId;
    const variety = varieties.find((v) => v.id === lot.varietyId)?.name || lot.varietyId;
    const sClass = seedClasses.find((c) => c.id === lot.classId)?.name || lot.classId;
    const grade = grades.find((g) => g.id === lot.gradeId)?.name || lot.gradeId;

    const balanceBags = Math.max(0, lot.inboundBags - lot.deliveredBags);
    const balanceKg = Math.max(0, lot.inboundKg - lot.deliveredKg);
    const balanceMt = Math.max(0, Number((lot.inboundMt - lot.deliveredMt).toFixed(2)));

    return {
      coldStorageId: lot.coldStorageId,
      coldStorageName: storage,
      varietyId: lot.varietyId,
      varietyName: variety,
      classId: lot.classId,
      className: sClass,
      gradeId: lot.gradeId,
      gradeName: grade,
      inboundBags: lot.inboundBags,
      inboundMt: lot.inboundMt,
      deliveredBags: lot.deliveredBags,
      deliveredMt: lot.deliveredMt,
      balanceBags,
      balanceKg,
      balanceMt,
    };
  });
}

export function calculateInventoryMetrics(
  stockTransactions: StockTransaction[],
  deliveryTransactions: DeliveryTransaction[],
  coldStorages: ColdStorage[],
  coldStorageId?: string
) {
  const filteredStock = coldStorageId
    ? stockTransactions.filter((s) => s.coldStorageId === coldStorageId)
    : stockTransactions;

  const filteredDelivery = coldStorageId
    ? deliveryTransactions.filter((d) => d.coldStorageId === coldStorageId)
    : deliveryTransactions;

  const totalInboundBags = filteredStock.reduce((acc, s) => acc + s.sackQuantity, 0);
  const totalInboundKg = filteredStock.reduce((acc, s) => acc + s.totalKg, 0);
  const totalInboundMt = filteredStock.reduce((acc, s) => acc + s.totalMt, 0);

  const totalDeliveredBags = filteredDelivery.reduce((acc, d) => acc + d.sackQuantity, 0);
  const totalDeliveredKg = filteredDelivery.reduce((acc, d) => acc + d.totalKg, 0);
  const totalDeliveredMt = filteredDelivery.reduce((acc, d) => acc + d.totalMt, 0);

  const balanceBags = Math.max(0, totalInboundBags - totalDeliveredBags);
  const balanceKg = Math.max(0, totalInboundKg - totalDeliveredKg);
  const balanceMt = Math.max(0, Number((totalInboundMt - totalDeliveredMt).toFixed(2)));

  const targetStorages = coldStorageId
    ? coldStorages.filter((c) => c.id === coldStorageId)
    : coldStorages;

  const totalCapacityBags = targetStorages.reduce((acc, c) => acc + c.capacity, 0);
  const occupancyRate = totalCapacityBags > 0 ? (balanceBags / totalCapacityBags) * 100 : 0;

  return {
    totalInboundBags,
    totalInboundKg,
    totalInboundMt,
    totalDeliveredBags,
    totalDeliveredKg,
    totalDeliveredMt,
    balanceBags,
    balanceKg,
    balanceMt,
    occupancyRate,
    activeStorages: targetStorages.length,
    // Aliases matching Dashboard
    totalStockInBags: totalInboundBags,
    totalStockInKg: totalInboundKg,
    totalStockInMt: totalInboundMt,
    totalDeliveryBags: totalDeliveredBags,
    totalDeliveryKg: totalDeliveredKg,
    totalDeliveryMt: totalDeliveredMt,
    currentBalanceBags: balanceBags,
    currentBalanceKg: balanceKg,
    currentBalanceMt: balanceMt,
    overallOccupancyRate: occupancyRate,
    totalCapacityBags,
    activeColdStorages: targetStorages.length,
  };
}

export function getMonthlyTrends(
  stockTransactions: StockTransaction[],
  deliveryTransactions: DeliveryTransaction[]
) {
  const monthMap: Record<
    string,
    { month: string; inbound: number; outbound: number }
  > = {};

  const getMonthKey = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-US', { month: 'short' });
    } catch {
      return 'Jan';
    }
  };

  const defaultMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  defaultMonths.forEach((m) => {
    monthMap[m] = { month: m, inbound: 0, outbound: 0 };
  });

  stockTransactions.forEach((s) => {
    const m = getMonthKey(s.date);
    if (!monthMap[m]) monthMap[m] = { month: m, inbound: 0, outbound: 0 };
    monthMap[m].inbound += s.sackQuantity;
  });

  deliveryTransactions.forEach((d) => {
    const m = getMonthKey(d.date);
    if (!monthMap[m]) monthMap[m] = { month: m, inbound: 0, outbound: 0 };
    monthMap[m].outbound += d.sackQuantity;
  });

  const categories = defaultMonths;
  const inboundArr: number[] = [];
  const deliveredArr: number[] = [];
  const balanceArr: number[] = [];

  let runningBalance = 0;
  defaultMonths.forEach((m) => {
    const item = monthMap[m];
    inboundArr.push(item.inbound);
    deliveredArr.push(item.outbound);
    runningBalance += item.inbound - item.outbound;
    balanceArr.push(Math.max(0, runningBalance));
  });

  return {
    categories,
    inbound: inboundArr,
    delivered: deliveredArr,
    balance: balanceArr,
  };
}

