export type SortDirection = 'asc' | 'desc';

export interface SortState {
  key: string | null;
  direction: SortDirection;
}

/**
 * Robust sorting function supporting numbers, strings (case-insensitive, localized),
 * dates, nested accessor functions, and safe null/undefined handling.
 */
export function sortData<T>(
  data: T[],
  sortKey: string | null,
  direction: SortDirection = 'asc',
  customExtractors?: Record<string, (item: T) => any>
): T[] {
  if (!sortKey || !data || data.length === 0) {
    return data;
  }

  const sorted = [...data].sort((a: any, b: any) => {
    let valA = customExtractors?.[sortKey] ? customExtractors[sortKey](a) : a[sortKey];
    let valB = customExtractors?.[sortKey] ? customExtractors[sortKey](b) : b[sortKey];

    // Handle null or undefined
    if (valA === undefined || valA === null) return direction === 'asc' ? 1 : -1;
    if (valB === undefined || valB === null) return direction === 'asc' ? -1 : 1;

    // Handle string comparison
    if (typeof valA === 'string' && typeof valB === 'string') {
      const cmp = valA.localeCompare(valB, undefined, { numeric: true, sensitivity: 'base' });
      return direction === 'asc' ? cmp : -cmp;
    }

    // Handle numbers
    if (typeof valA === 'number' && typeof valB === 'number') {
      return direction === 'asc' ? valA - valB : valB - valA;
    }

    // Handle Dates or date strings
    const dateA = Date.parse(valA);
    const dateB = Date.parse(valB);
    if (!isNaN(dateA) && !isNaN(dateB)) {
      return direction === 'asc' ? dateA - dateB : dateB - dateA;
    }

    // Fallback comparison
    if (valA < valB) return direction === 'asc' ? -1 : 1;
    if (valA > valB) return direction === 'asc' ? 1 : -1;
    return 0;
  });

  return sorted;
}
