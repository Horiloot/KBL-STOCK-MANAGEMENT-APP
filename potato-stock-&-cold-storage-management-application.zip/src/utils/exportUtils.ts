import ExcelJS from 'exceljs';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { CompanySettings } from '../types';

export interface ExportColumn {
  header: string;
  key: string;
  width?: number;
  align?: 'left' | 'center' | 'right';
  isNumeric?: boolean;
  numFmt?: string;
}

export interface ExcelExportOptions {
  orientation?: 'portrait' | 'landscape';
  sheetName?: string;
  includeSummary?: boolean;
  summaryColumns?: string[];
  accentColor?: string; // ARGB hex string e.g. 'FF0284C7'
  printedBy?: string;
}

/**
 * Formats current date and time cleanly
 */
export function getFormattedPrintDateTime(): string {
  const now = new Date();
  return now.toLocaleString('en-US', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
}

/**
 * EXCEL EXPORT:
 * Generates formatted spreadsheet with Company Name, Document Name,
 * Print Date & Time, Printed By (User Name), Page Setup, Zebra Styling,
 * and Separate Formatting for Header & Total Rows.
 */
export async function exportToExcel(
  data: Record<string, any>[],
  columns: ExportColumn[],
  filename: string,
  title?: string,
  companySettings?: CompanySettings,
  subtitle?: string,
  options?: ExcelExportOptions
): Promise<void> {
  const workbook = new ExcelJS.Workbook();
  const compName = companySettings?.companyName || 'KISAN BOTANIX LTD.';
  const tagline = companySettings?.tagline || companySettings?.companyTagline || 'Potato Seed Stock & Cold Storage ERP';
  const address = companySettings?.address || 'Dhaka / Dinajpur, Bangladesh';
  const printTimeStr = getFormattedPrintDateTime();
  const printedByStr = options?.printedBy || 'Md. Tariqul Islam (System User)';

  workbook.creator = compName;
  workbook.lastModifiedBy = printedByStr;
  workbook.created = new Date();

  const sheetName = options?.sheetName || 'Inventory Report';
  const worksheet = workbook.addWorksheet(sheetName, {
    pageSetup: {
      orientation: options?.orientation || 'landscape',
      paperSize: 9, // A4
      fitToPage: true,
      fitToWidth: 1,
      fitToHeight: 0,
    },
    headerFooter: {
      firstFooter: `&L${compName} | Printed by: ${printedByStr}&RPage &P of &N`,
      oddFooter: `&L${compName} | Printed by: ${printedByStr}&RPage &P of &N`,
    },
  });

  const accentColor = options?.accentColor || 'FF0284C7'; // Sky-600

  // 1. Company Banner Header (Row 1)
  worksheet.addRow([compName.toUpperCase()]);
  const row1 = worksheet.getRow(1);
  row1.font = { name: 'Calibri', size: 16, bold: true, color: { argb: 'FFFFFFFF' } };
  row1.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: accentColor },
  };
  row1.alignment = { horizontal: 'center', vertical: 'middle' };
  row1.height = 32;
  worksheet.mergeCells(1, 1, 1, columns.length);

  // 2. Company Subtitle & Address (Row 2)
  worksheet.addRow([`${tagline} • ${address}`]);
  const row2 = worksheet.getRow(2);
  row2.font = { name: 'Calibri', size: 10, italic: true, color: { argb: 'FFE0F2FE' } };
  row2.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: accentColor },
  };
  row2.alignment = { horizontal: 'center', vertical: 'middle' };
  row2.height = 20;
  worksheet.mergeCells(2, 1, 2, columns.length);

  // 3. Output Document Name / Title Banner (Row 3)
  const repTitle = title ? title.toUpperCase() : 'POTATO INVENTORY REPORT';
  worksheet.addRow([repTitle]);
  const row3 = worksheet.getRow(3);
  row3.font = { name: 'Calibri', size: 13, bold: true, color: { argb: 'FF0F172A' } };
  row3.alignment = { horizontal: 'center', vertical: 'middle' };
  row3.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFF1F5F9' }, // Slate-100
  };
  row3.height = 26;
  worksheet.mergeCells(3, 1, 3, columns.length);

  // 4. Print Metadata Bar (Row 4: Print Date & Time, Printed By, Subtitle/Filters)
  const metaText = `PRINT TIME: ${printTimeStr}  |  PRINTED BY: ${printedByStr.toUpperCase()}  |  RECORDS: ${data.length}${
    subtitle ? `  |  ${subtitle}` : ''
  }`;
  worksheet.addRow([metaText]);
  const row4 = worksheet.getRow(4);
  row4.font = { name: 'Calibri', size: 9, bold: true, color: { argb: 'FF475569' } };
  row4.alignment = { horizontal: 'center', vertical: 'middle' };
  row4.height = 18;
  worksheet.mergeCells(4, 1, 4, columns.length);

  worksheet.addRow([]); // Blank spacer (Row 5)
  worksheet.getRow(5).height = 8;

  // 5. Table Header Row (Row 6) - Slate-900 background, bold white text
  const headerRow = worksheet.addRow(columns.map((c) => c.header.toUpperCase()));
  headerRow.height = 26;
  headerRow.eachCell((cell, colNumber) => {
    cell.font = { name: 'Calibri', size: 10.5, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF0F172A' }, // Slate-900
    };
    const colAlign = columns[colNumber - 1]?.align || (columns[colNumber - 1]?.isNumeric ? 'right' : 'left');
    cell.alignment = { horizontal: colAlign, vertical: 'middle' };
    cell.border = {
      top: { style: 'medium', color: { argb: 'FF0F172A' } },
      bottom: { style: 'medium', color: { argb: 'FF334155' } },
      left: { style: 'thin', color: { argb: 'FF334155' } },
      right: { style: 'thin', color: { argb: 'FF334155' } },
    };
  });

  // 6. Data Rows with Zebra Striping (Alternating White and Slate-50)
  data.forEach((item, rIdx) => {
    const rowValues = columns.map((col) => {
      const val = item[col.key];
      return val !== undefined && val !== null ? val : '';
    });

    const dataRow = worksheet.addRow(rowValues);
    dataRow.height = 20;

    const isEven = rIdx % 2 === 0;
    const rowBgColor = isEven ? 'FFFFFFFF' : 'FFF8FAFC'; // White vs Slate-50

    dataRow.eachCell((cell, colNumber) => {
      const colDef = columns[colNumber - 1];
      const isNum = colDef?.isNumeric || typeof cell.value === 'number';
      const colAlign = colDef?.align || (isNum ? 'right' : 'left');

      cell.font = { name: 'Calibri', size: 10, color: { argb: 'FF1E293B' } };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: rowBgColor },
      };
      cell.alignment = { horizontal: colAlign, vertical: 'middle' };
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        right: { style: 'thin', color: { argb: 'FFE2E8F0' } },
      };

      if (colDef?.numFmt) {
        cell.numFmt = colDef.numFmt;
      }
    });
  });

  // 7. Total Row with Separate Distinct Formatting
  const numericColumns = options?.summaryColumns || columns.filter((c) => c.isNumeric).map((c) => c.key);
  if (options?.includeSummary !== false && numericColumns.length > 0) {
    const summaryRowVals = columns.map((col, idx) => {
      if (idx === 0) return 'TOTAL CONSOLIDATED';
      if (numericColumns.includes(col.key)) {
        const sum = data.reduce((acc, row) => {
          const val = Number(row[col.key]);
          return acc + (isNaN(val) ? 0 : val);
        }, 0);
        return sum;
      }
      return '';
    });

    const sumRow = worksheet.addRow(summaryRowVals);
    sumRow.height = 26;
    sumRow.eachCell((cell, colNumber) => {
      const colDef = columns[colNumber - 1];
      const isNum = typeof cell.value === 'number';
      cell.font = { name: 'Calibri', size: 11, bold: true, color: { argb: 'FF0F172A' } };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE2E8F0' }, // Slate-200 distinct highlight
      };
      cell.alignment = {
        horizontal: colDef?.align || (isNum ? 'right' : 'left'),
        vertical: 'middle',
      };
      cell.border = {
        top: { style: 'medium', color: { argb: 'FF0F172A' } },
        bottom: { style: 'double', color: { argb: 'FF0F172A' } },
        left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
        right: { style: 'thin', color: { argb: 'FFCBD5E1' } },
      };
      if (colDef?.numFmt) {
        cell.numFmt = colDef.numFmt;
      }
    });
  }

  // 8. Set Dynamic Column Widths
  columns.forEach((col, idx) => {
    const worksheetColumn = worksheet.getColumn(idx + 1);
    worksheetColumn.width = col.width ? Math.max(col.width, 12) : 16;
  });

  // Trigger Download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${filename || 'Potato_Inventory_Export'}.xlsx`;
  anchor.click();
  URL.revokeObjectURL(url);
}

/**
 * PDF EXPORT:
 * Generates high-resolution vector PDF with Company Name, Document Name,
 * Print Date & Time, Printed By (User Name), Page X of Y, Zebra Styling,
 * and Separate Formatting for Header & Total Rows.
 */
export function exportToPdf(
  data: Record<string, any>[],
  columns: ExportColumn[],
  filename: string,
  title?: string,
  companySettings?: CompanySettings,
  orientation: 'p' | 'l' = 'l',
  subtitle?: string,
  printedBy?: string
): void {
  const doc = new jsPDF({
    orientation: orientation === 'p' ? 'portrait' : 'landscape',
    unit: 'pt',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 36; // 0.5 inch
  const printTimeStr = getFormattedPrintDateTime();
  const printedByStr = printedBy || 'Md. Tariqul Islam (System User)';

  // Company Letterhead Header
  const compName = companySettings?.companyName || 'KISAN BOTANIX LTD.';
  const tagline = companySettings?.tagline || companySettings?.companyTagline || 'Leading Quality Potato Seed Storage & Distribution';
  const address = companySettings?.address || 'Dhaka / Dinajpur, Bangladesh';

  // Company Name
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42); // Slate-900
  doc.text(compName.toUpperCase(), margin, 42);

  // Company Tagline & Address
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105); // Slate-600
  doc.text(tagline, margin, 54);
  doc.text(`${address} | Phone: ${companySettings?.phone || '+880 1711-XXXXXX'} | Currency: ${companySettings?.currency || 'BDT'}`, margin, 66);

  // Document Title Banner on Right
  const docTitle = title || 'INVENTORY AUDIT REPORT';
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12.5);
  doc.setTextColor(2, 132, 199); // Sky-600
  doc.text(docTitle.toUpperCase(), pageWidth - margin, 42, { align: 'right' });

  if (subtitle) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(subtitle, pageWidth - margin, 54, { align: 'right' });
  }

  // Metadata: Print Date & Time and Printed By
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`Print Time: ${printTimeStr}  |  Printed By: ${printedByStr}`, pageWidth - margin, 66, { align: 'right' });

  // Divider line
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(1);
  doc.line(margin, 74, pageWidth - margin, 74);

  // Prepare table data
  const head = [columns.map((c) => c.header.toUpperCase())];
  const body = data.map((item) =>
    columns.map((col) => {
      const val = item[col.key];
      if (val === undefined || val === null) return '-';
      if (typeof val === 'number') return val.toLocaleString();
      return String(val);
    })
  );

  // Compute Total Row for PDF
  const numericKeys = columns.filter((c) => c.isNumeric).map((c) => c.key);
  const foot =
    data.length > 0 && numericKeys.length > 0
      ? [
          columns.map((col, idx) => {
            if (idx === 0) return 'TOTAL CONSOLIDATED';
            if (numericKeys.includes(col.key)) {
              const sum = data.reduce((acc, row) => {
                const val = Number(row[col.key]);
                return acc + (isNaN(val) ? 0 : val);
              }, 0);
              return sum.toLocaleString();
            }
            return '';
          }),
        ]
      : undefined;

  // Alignments per column
  const columnStyles: Record<number, any> = {};
  columns.forEach((col, idx) => {
    columnStyles[idx] = {
      halign: col.align || (col.isNumeric ? 'right' : 'left'),
    };
  });

  autoTable(doc, {
    startY: 82,
    margin: { left: margin, right: margin, bottom: 40 },
    head,
    body,
    foot,
    theme: 'striped',
    styles: {
      fontSize: 8,
      cellPadding: 4.5,
      overflow: 'linebreak',
    },
    columnStyles,
    headStyles: {
      fillColor: [15, 23, 42], // Slate-900 distinct dark header
      textColor: [255, 255, 255],
      fontSize: 8.5,
      fontStyle: 'bold',
    },
    bodyStyles: {
      textColor: [30, 41, 59],
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252], // Slate-50 zebra styling
    },
    footStyles: {
      fillColor: [226, 232, 240], // Slate-200 distinct total row
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 8.5,
    },
    didDrawPage: (dataInfo) => {
      // Dynamic Footer with Page Numbers, User, and Company Note
      const pageStr = `Page ${dataInfo.pageNumber} of ${doc.getNumberOfPages()} • Printed by: ${printedByStr} • ${compName}`;
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text(pageStr, margin, pageHeight - 14);

      const auditStr = `Electronic System Generated Document • ${printTimeStr}`;
      doc.text(auditStr, pageWidth - margin, pageHeight - 14, { align: 'right' });
    },
  });

  doc.save(`${filename || 'Potato_Inventory_Document'}.pdf`);
}

export interface PrintValidationOptions {
  data: any[];
  reportTitle: string;
  expectedMinRecords?: number;
  databaseCheck?: () => { isConsistent: boolean; reason?: string };
  onValidating?: () => void;
  onSuccess?: () => void;
  onError?: (error: string) => void;
  columns?: ExportColumn[];
  companySettings?: CompanySettings;
  subtitle?: string;
  userName?: string;
}

/**
 * DIRECT HTML PRINT ENGINE:
 * Builds a complete, beautifully formatted printable page inside a temporary iframe
 * and triggers printing. Guaranteed to include Company Name, Document Name,
 * Print Time & Date, Printed By, Page No, Zebra Style, and Header & Total Row Formatting.
 */
export function triggerDirectPrint(options: {
  reportTitle: string;
  data: Record<string, any>[];
  columns: ExportColumn[];
  companySettings?: CompanySettings;
  subtitle?: string;
  userName?: string;
  onSuccess?: () => void;
  onError?: (err: string) => void;
}): void {
  const { reportTitle, data, columns, companySettings, subtitle, userName, onSuccess, onError } = options;

  if (!data || data.length === 0) {
    if (onError) onError('No records available to print.');
    return;
  }

  const compName = companySettings?.companyName || 'KISAN BOTANIX LTD.';
  const tagline = companySettings?.tagline || companySettings?.companyTagline || 'Potato Seed Stock & Cold Storage ERP';
  const address = companySettings?.address || 'Dhaka / Dinajpur, Bangladesh';
  const printTimeStr = getFormattedPrintDateTime();
  const printedByStr = userName || 'Md. Tariqul Islam (System User)';

  // Calculate totals
  const numericColumns = columns.filter((c) => c.isNumeric);
  const totals: Record<string, number> = {};
  numericColumns.forEach((col) => {
    totals[col.key] = data.reduce((acc, row) => {
      const v = Number(row[col.key]);
      return acc + (isNaN(v) ? 0 : v);
    }, 0);
  });

  // Build rows HTML
  const rowsHtml = data
    .map((item, idx) => {
      const isEven = idx % 2 === 0;
      const bg = isEven ? '#ffffff' : '#f8fafc';
      const cells = columns
        .map((col) => {
          const val = item[col.key];
          const isNum = col.isNumeric || typeof val === 'number';
          const align = col.align || (isNum ? 'right' : 'left');
          const formatted =
            val !== undefined && val !== null
              ? isNum
                ? typeof val === 'number'
                  ? val === 0
                    ? '-'
                    : val.toLocaleString()
                  : val
                : String(val)
              : '-';
          return `<td style="padding: 6px 8px; text-align: ${align}; border-bottom: 1px solid #e2e8f0; font-size: 11px;">${formatted}</td>`;
        })
        .join('');

      return `<tr style="background-color: ${bg};"><td style="padding: 6px 8px; text-align: center; border-bottom: 1px solid #e2e8f0; font-size: 10px; color: #94a3b8; font-family: monospace;">${
        idx + 1
      }</td>${cells}</tr>`;
    })
    .join('');

  // Total row HTML
  let totalRowHtml = '';
  if (numericColumns.length > 0) {
    const totalCells = columns
      .map((col, idx) => {
        if (idx === 0) {
          return `<td style="padding: 8px; font-weight: bold; font-size: 11px; text-align: left;">TOTAL CONSOLIDATED</td>`;
        }
        if (col.isNumeric) {
          return `<td style="padding: 8px; font-weight: bold; font-size: 11px; text-align: right;">${totals[
            col.key
          ].toLocaleString()}</td>`;
        }
        return `<td style="padding: 8px;"></td>`;
      })
      .join('');

    totalRowHtml = `
      <tr style="background-color: #e2e8f0; color: #0f172a; border-top: 2px solid #0f172a; border-bottom: 3px double #0f172a;">
        <td style="padding: 8px; text-align: center; font-weight: bold; font-size: 10px;">★</td>
        ${totalCells}
      </tr>
    `;
  }

  // Complete HTML document for print
  const printDocHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>${reportTitle}</title>
        <style>
          @page {
            size: landscape;
            margin: 10mm;
          }
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            color: #0f172a;
            margin: 0;
            padding: 10px;
            background: #ffffff;
            font-size: 12px;
          }
          .header-banner {
            border-bottom: 2px solid #0f172a;
            padding-bottom: 10px;
            margin-bottom: 14px;
          }
          .header-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
          }
          .company-name {
            font-size: 20px;
            font-weight: 900;
            color: #0f172a;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin: 0;
          }
          .company-tagline {
            font-size: 11px;
            color: #475569;
            margin: 2px 0 0 0;
          }
          .company-address {
            font-size: 10px;
            color: #64748b;
            margin: 2px 0 0 0;
          }
          .meta-box {
            text-align: right;
            font-size: 11px;
            color: #334155;
          }
          .doc-badge {
            display: inline-block;
            background: #f1f5f9;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 10px;
            text-transform: uppercase;
            margin-bottom: 4px;
          }
          .title-strip {
            margin-top: 10px;
            padding-top: 8px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
          }
          .doc-title {
            font-size: 14px;
            font-weight: 800;
            text-transform: uppercase;
            color: #0284c7;
            margin: 0;
          }
          .metadata-bar {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 6px 12px;
            margin-bottom: 14px;
            display: flex;
            justify-content: space-between;
            font-size: 10px;
            font-weight: 600;
            color: #475569;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }
          thead th {
            background-color: #0f172a;
            color: #ffffff;
            font-weight: 700;
            font-size: 10.5px;
            padding: 8px;
            text-transform: uppercase;
            border: 1px solid #0f172a;
          }
          .signatures {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #cbd5e1;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            text-align: center;
            font-size: 11px;
          }
          .sig-line {
            border-top: 1px dashed #94a3b8;
            padding-top: 6px;
            font-weight: bold;
            text-transform: uppercase;
          }
          .footer-note {
            margin-top: 20px;
            padding-top: 8px;
            border-top: 1px solid #f1f5f9;
            display: flex;
            justify-content: space-between;
            font-size: 9px;
            color: #94a3b8;
          }
        </style>
      </head>
      <body>
        <div class="header-banner">
          <div class="header-top">
            <div>
              <h1 class="company-name">${compName}</h1>
              <p class="company-tagline">${tagline}</p>
              <p class="company-address">${address} | Phone: ${companySettings?.phone || '+880 1711-XXXXXX'}</p>
            </div>
            <div class="meta-box">
              <span class="doc-badge">Fiscal Year ${companySettings?.fiscalYear || '2024-2025'}</span>
              <div>Date: <strong>${new Date().toLocaleDateString()}</strong></div>
              <div>Printed By: <strong>${printedByStr}</strong></div>
            </div>
          </div>
          <div class="title-strip">
            <h2 class="doc-title">${reportTitle}</h2>
            <div style="font-size: 11px; color: #64748b;">
              Currency: <strong>${companySettings?.currency || 'BDT'}</strong> | Total Records: <strong>${data.length}</strong>
            </div>
          </div>
        </div>

        <div class="metadata-bar">
          <span>PRINT DATE & TIME: ${printTimeStr}</span>
          <span>SYSTEM USER: ${printedByStr.toUpperCase()}</span>
          <span>PAGE: 1 OF 1</span>
          ${subtitle ? `<span>FILTER / SUBTITLE: ${subtitle}</span>` : ''}
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 30px; text-align: center;">#</th>
              ${columns
                .map(
                  (col) =>
                    `<th style="text-align: ${col.align || (col.isNumeric ? 'right' : 'left')}">${col.header.toUpperCase()}</th>`
                )
                .join('')}
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
            ${totalRowHtml}
          </tbody>
        </table>

        <div class="signatures">
          <div>
            <div class="sig-line">Prepared By (${printedByStr.split(' ')[0]})</div>
            <div style="color: #94a3b8; font-size: 9px;">Store Assistant</div>
          </div>
          <div>
            <div class="sig-line">Verified By</div>
            <div style="color: #94a3b8; font-size: 9px;">Store Officer / Accountant</div>
          </div>
          <div>
            <div class="sig-line">Authorized Signatory</div>
            <div style="color: #94a3b8; font-size: 9px;">Managing Director / GM</div>
          </div>
        </div>

        <div class="footer-note">
          <span>${compName} • Potato Seed Stock Management System • Confidential Enterprise Document</span>
          <span>Page 1 of 1</span>
        </div>
      </body>
    </html>
  `;

  try {
    const iframe = document.createElement('iframe');
    iframe.setAttribute('title', 'Document Print Frame');
    iframe.style.position = 'fixed';
    iframe.style.left = '-9999px';
    iframe.style.top = '-9999px';
    iframe.style.width = '1024px';
    iframe.style.height = '768px';
    iframe.style.border = '0';
    iframe.style.opacity = '0';
    iframe.style.pointerEvents = 'none';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (!doc) {
      if (document.body.contains(iframe)) document.body.removeChild(iframe);
      window.print();
      if (onSuccess) onSuccess();
      return;
    }

    doc.open();
    doc.write(printDocHtml);
    doc.close();

    setTimeout(() => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        if (onSuccess) onSuccess();
      } catch (err: any) {
        console.warn('Iframe print intercepted, fallback to parent print:', err);
        window.print();
        if (onSuccess) onSuccess();
      } finally {
        setTimeout(() => {
          if (document.body.contains(iframe)) {
            document.body.removeChild(iframe);
          }
        }, 2000);
      }
    }, 300);
  } catch (error: any) {
    console.error('Print initialization error:', error);
    try {
      window.print();
      if (onSuccess) onSuccess();
    } catch (e: any) {
      if (onError) onError(`Print error: ${e.message || 'Printer initialization failed'}`);
    }
  }
}

/**
 * Universal print trigger that verifies data integrity and executes direct print
 */
export function validateAndTriggerPrint(options: PrintValidationOptions): void {
  const {
    data,
    reportTitle,
    expectedMinRecords = 1,
    databaseCheck,
    onValidating,
    onSuccess,
    onError,
    columns,
    companySettings,
    subtitle,
    userName,
  } = options;

  if (onValidating) onValidating();

  // Basic validation check
  if (!data || data.length < expectedMinRecords) {
    const errorMsg = `Unable to print "${reportTitle}": Data set contains no valid records.`;
    if (onError) onError(errorMsg);
    return;
  }

  // Deep database consistency check if provided
  if (databaseCheck) {
    const result = databaseCheck();
    if (!result.isConsistent) {
      const errorMsg = `Data validation failed for "${reportTitle}": ${result.reason || 'State discrepancy detected.'}`;
      if (onError) onError(errorMsg);
      return;
    }
  }

  // If columns are provided or can be derived, trigger the direct print engine with full formatting
  let resolvedColumns = columns;
  if (!resolvedColumns || resolvedColumns.length === 0) {
    if (data && data.length > 0 && typeof data[0] === 'object') {
      const keys = Object.keys(data[0]).filter(
        (k) => k !== 'id' && k !== 'key' && !k.startsWith('_')
      );
      resolvedColumns = keys.map((k) => ({
        header: k
          .replace(/([A-Z])/g, ' $1')
          .replace(/^./, (str) => str.toUpperCase()),
        key: k,
        isNumeric: typeof data[0][k] === 'number',
      }));
    }
  }

  if (resolvedColumns && resolvedColumns.length > 0) {
    triggerDirectPrint({
      reportTitle,
      data,
      columns: resolvedColumns,
      companySettings,
      subtitle,
      userName,
      onSuccess,
      onError,
    });
    return;
  }

  // Fallback if no records or columns could be determined
  if (onSuccess) onSuccess();
  setTimeout(() => {
    window.print();
  }, 100);
}
